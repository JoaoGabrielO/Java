package EstruturaDeDados.ADO02;

public class Atendente {
    public Atendente() {
    }
}
