package EstruturaDeDados.ADO02;


public class CadastraFila {
    public CadastraFila(){

        Fila fila = new Fila();
        Paciente paciente = new Paciente();

        if(fila.estaVazia()){

        }

    }
}
