package EstruturaDeDados.Aula03;


public class VetorObjeto {

    private Object[] vetor;
    private int tamanho;

    public VetorObjeto(int capacidade) {
        this.vetor = new Object[capacidade];
        this.tamanho = 0;
    }

    public void adiciona(Object elemento) throws Exception {
        this.aumentaCapacidade();
        if (this.tamanho < this.vetor.length) {
            this.vetor[this.tamanho] = elemento;
            this.tamanho++;
        } else {
            throw new Exception("O Vetor já está cheio, "
                    + "não é possível adiconar novos elementos");
        }
    }

    public int tamanho() {
        return this.tamanho;
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("[");

        for (int i = 0; i < this.tamanho - 1; i++) {
            s.append(this.vetor[i]);
            s.append(", ");
        }

        if (this.tamanho > 0) {
            s.append(this.vetor[this.tamanho - 1]);
        }

        s.append("]");

        return s.toString();
    }

    public Object busca(int posicao) throws Exception {
        if (posicao >= 0 && posicao < tamanho) {
            return vetor[posicao];
        } else {
            throw new Exception("Posição Inválida");
        }
    }

    public int busca1(Object elemento) {
        for (int i = 0; i < tamanho; i++) {
            if (vetor[i].equals(elemento)) {
                return i;
            }
        }
        return -1;
    }

    public boolean adicionaInicio(int posicao, Object elemento) throws Exception {
        this.aumentaCapacidade();
        if (posicao >= 0 && posicao < tamanho) {
            for (int i = this.tamanho - 1; i > posicao; i--) {
                this.vetor[i + 1] = this.vetor[i];
            }
            this.vetor[posicao] = elemento;
            this.tamanho++;
        } else {
            throw new Exception("Posição Inválida");
        }

        return true;
    }

    private void aumentaCapacidade() {
        if (this.tamanho == this.vetor.length) {
            Object[] elementosNovos = new Object[this.vetor.length * 2];
            for (int i = 0; i < this.vetor.length; i++) {
                elementosNovos[i] = this.vetor[i];
            }
            this.vetor = elementosNovos;
        }
    }

    public void remove(int posicao) throws Exception {
        if (posicao >= 0 && posicao < tamanho) {
            for (int i = posicao; i < this.tamanho - 1; i++) {
                this.vetor[i] = this.vetor[i + 1];
            }
            this.tamanho--;
        } else {
            throw new Exception("Posição Inválida");
        }
    }
}
