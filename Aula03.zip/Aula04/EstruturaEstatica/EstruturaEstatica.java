package EstruturaDeDados.Aula04.EstruturaEstatica;

import java.util.Stack;

public class EstruturaEstatica<T> {
    public T[] vetor;
    public int tamanho;
    public int tamanhoEstrutura;

    // método construtor com parâmentro
    public EstruturaEstatica(int capacidade){
        this.vetor = (T[]) new Object[capacidade];
        this.tamanho = 0;
    }
    // método Contrutor sem parâmetro
    public EstruturaEstatica(){
        this(10);
    }
    // método para adiconar elemento
    public boolean adiciona(T elemento){
        this.aumentaCapacidade();
        if(this.tamanho < this.vetor.length){
            this.vetor[this.tamanho] = elemento;
            this.tamanho++;
            return true;
        }
        return false;
    }
    // método para adicionar em qualquer posição
    public boolean adiciona(int posicao, T elemento){
        if(!(posicao >=0 && posicao < tamanho)){
            throw new IllegalArgumentException("Posição Inválida");
        }
        this.aumentaCapacidade();
        for(int i=this.tamanho-1; i>=posicao; i--){
            this.vetor[i+1] = this.vetor[i];
        }
        this.vetor[posicao] = elemento;
        this.tamanho++;

        return true;
    }
    // método para aumentar a capidade do vetor
    public void aumentaCapacidade(){
        if(this.tamanho == this.vetor.length){
            T[] elementosNovos = (T[]) new Object[this.vetor.length * 2];
            for (int i=0; i<this.vetor.length; i++){
                elementosNovos[i] = this.vetor[i];
            }
            this.vetor = elementosNovos;
        }
    }

    public int tamanho(){
        return this.tamanho;
    }

    public int tamanhoEstrutura(){
        this.tamanhoEstrutura = this.vetor.length;
        return this.tamanhoEstrutura;
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("[");

        for(int i=0; i<this.tamanho-1; i++){
            s.append(this.vetor[i]);
            s.append(", ");
        }

        if(this.tamanho> 0){
            s.append(this.vetor[this.tamanho-1]);
        }

        s.append("]");

        return s.toString();
    }

    public boolean estaVazia(){
        return this.tamanho == 0;
    }

    public void remove(int posicao){
        if(!(posicao >=0 && posicao < tamanho)){
            throw new IllegalArgumentException("Posição Inválida");
        }
        for (int i=posicao; i<tamanho-1; i++){
            vetor[i] = vetor[i+1];
        }
        tamanho --;
    }
}
