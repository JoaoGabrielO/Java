package EstruturaDeDados.ADO02;


public class Verificacao {
    public boolean verificaPrefencial(int preferencial){
        if(preferencial == 0){
            return true;
        }
        return false;
    }
}
