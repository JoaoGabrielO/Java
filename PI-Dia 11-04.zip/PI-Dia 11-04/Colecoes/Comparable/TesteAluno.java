package PI.Colecoes.Comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class TesteAluno {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno("Orlando", 123);
        Aluno aluno2 = new Aluno("Amanda", 258);
        Aluno aluno3 = new Aluno("Rafael", 456);
        Aluno aluno4 = new Aluno("Bruna", 246);
        Aluno aluno5 = new Aluno("Pedro", 369);
        Aluno aluno6 = new Aluno("Maria", 481);
        Aluno aluno7 = new Aluno("Fernanda", 987);

        ArrayList alunos = new ArrayList();
        alunos.add(aluno1);
        alunos.add(aluno2);
        alunos.add(aluno3);
        alunos.add(aluno4);
        alunos.add(aluno5);
        alunos.add(aluno6);
        alunos.add(aluno7);

        System.out.println("Imprimindo alunos antes da ordenação");
        Iterator iTer1 = alunos.iterator();

        while(iTer1.hasNext()){
            System.out.println(iTer1.next());
            Collections.sort(alunos);
            System.out.println("\nImprimindo alunos depois da ordenação");
            Iterator iTer2 = alunos.iterator();
            while(iTer2.hasNext()){
                System.out.println(iTer2.next());
            }
        }
    }
}
