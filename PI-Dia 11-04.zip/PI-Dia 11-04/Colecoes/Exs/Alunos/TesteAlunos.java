package PI.Colecoes.Exs.Alunos;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class TesteAlunos {
    public static void main(String[] args) {
        ArrayList<Aluno> alunos = new ArrayList<Aluno>();

        int resp = 0;

        while(resp == 0){ // Fazendo repetição caso o usuario deseje continuar cadastrando alunos
            resp = JOptionPane.showConfirmDialog(null,"Deseja cadastrar aluno?");

            String nome = JOptionPane.showInputDialog("Nome: ");
            long RA = Long.parseLong(JOptionPane.showInputDialog("RA: "));
            String curso = JOptionPane.showInputDialog("Curso: ");
            Aluno aluno = new Aluno(nome, RA, curso);
            alunos.add(aluno);
        }
        System.out.println("Imprimindo alunos antes da ordenação");
        Iterator iTer1 = alunos.iterator();
        while(iTer1.hasNext()){ // Navegando pelo array com o iterator
            System.out.println(iTer1.hasNext());
        }
        Collections.sort(alunos); // Ordenando array com Lambda, primeiro ele ordena por ordem do nome, depois do proximo parametro, caso o primeiro seja igual
        System.out.println("Imprimindo alunos depois da ordenação com Lambda");
        alunos.forEach(aluno -> System.out.println(" - " + aluno));//Impressão com Lambda
        int indice = Integer.parseInt(JOptionPane.showInputDialog("Digite o índice do aluno a ser removido: "));

        resp = JOptionPane.showConfirmDialog(null, "Confirma a exclusão do aluno: " + alunos.get(indice));
        if(resp==0)
            System.out.println("\nO Aluno " + alunos.remove(indice) + " foi removido!");
        alunos.forEach(aluno -> System.out.println(" - " + aluno));//Impressão com Lambda
    }
}
