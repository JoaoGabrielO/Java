package PI.Colecoes.HashMap;

public class Pessoa {
    private String nome;
    private String cpf;
    public Pessoa (String nome, String cpf){
        this.nome = nome;
        this.cpf = cpf;
    }
    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String toString(){
        String str = "Nome: " + getNome();
        str += "\nCPF: " + getCpf();

        return str;
    }
    public boolean equals(Object o){
        if (o instanceof Pessoa){
            Pessoa p = (Pessoa) o;
            //Verifica se o CPF das pessoas são iguais
            if (this.getCpf().equals(p.getCpf()))
                return true;
            else
                return false;
        }
        else
            return false;
    }
}