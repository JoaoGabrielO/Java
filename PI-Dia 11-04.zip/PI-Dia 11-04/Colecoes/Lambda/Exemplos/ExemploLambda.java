package PI.Colecoes.Lambda.Exemplos;

import java.util.ArrayList;
import java.util.Collections;

public class ExemploLambda {
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<Integer>();
        numeros.add(5);
        numeros.add(9);
        numeros.add(8);
        numeros.add(1);
        System.out.println("Imprimindo antes da ordenação: ");
        numeros.forEach((n) -> {
            System.out.println(n);
        });
        Collections.sort(numeros);
        numeros.forEach((n) -> {
            System.out.println(n);
        });
    }
}
