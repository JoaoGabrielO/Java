package PI.Colecoes.Lambda.Exs.Produto;

import javax.swing.*;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Set<Produto> produtos = new HashSet<>();

        int resp = 0;

        do {
            String nome = JOptionPane.showInputDialog("Nome: ");
            String categoria = JOptionPane.showInputDialog("Categoria: ");
            double preco = Double.parseDouble(JOptionPane.showInputDialog("Preço: "));
            Produto produto = new Produto(nome, categoria, preco);

            produtos.add(produto);
            resp = JOptionPane.showConfirmDialog(null, "Deseja continuar?");

        } while (resp == 0);

        System.out.println("Lista de produtos ANTES da remoção");
        produtos.forEach(p -> System.out.println("Produto: " + p));

        double preco = Double.parseDouble(JOptionPane.showInputDialog("Digite o preço de corte: "));
        produtos.removeIf(p -> p.getPreco() > preco);
        System.out.println("Lista de produtos DEPOIS da remoção");
        produtos.forEach(p -> System.out.println("Produto: " + p));
    }
}
