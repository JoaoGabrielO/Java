package POO_Java.Senac.Media_Vendas;

import POO_Java.Senac.Media_Vendas.mediaVendas;

import java.util.Scanner;

public class mediaVendasMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o tamanho do periodo em dias, que deseja consultar: ");
        int periodo = sc.nextInt();

        mediaVendas novo = new mediaVendas();
        int vendas[] = new int [periodo];
        int cont = 0;

        for(int i = 0; i < vendas.length; i ++){

            int quantVendas= (int)(Math.random() * 100);
            vendas[i] = quantVendas;

            if(i == 0){
                novo.setMenorVenda(vendas[i]);
            }
            if(novo.getMenorVenda() > vendas[i]){
                novo.setMenorVenda(vendas[i]);
            }
            if(novo.getMaiorVenda() < vendas[i]){
                novo.setMaiorVenda(vendas[i]);
            }
            novo.setTotalVendas(novo.getTotalVendas() + vendas[i]);
        }
        novo.setMediaVendida(novo.getTotalVendas() / vendas.length);
        for(int item : vendas){
            System.out.println(item);
            if(item > novo.getMediaVendida()){
                cont ++;
            }
        }
        System.out.println("Media Vendida: " + novo.getMediaVendida());
        System.out.println("Maior venda no periodo: " + novo.getMaiorVenda());
        System.out.println("Menor venda no periodo: " + novo.getMenorVenda());
        System.out.println("Total vendido no periodo: " + novo.getTotalVendas());
        System.out.println("Dias em que a media vendida foi superada: " + cont);
    }
}
