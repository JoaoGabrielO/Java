package POO_Java.Senac.Media_Vendas;

public class mediaVendas {
    private float menorVenda, maiorVenda, mediaVendida, totalVendas;


    public float getTotalVendas() {
        return totalVendas;
    }

    public void setTotalVendas(float totalVendas) {
        this.totalVendas = totalVendas;
    }

    public float getMenorVenda() {
        return menorVenda;
    }

    public void setMenorVenda(float menorVenda) {
        this.menorVenda = menorVenda;
    }

    public float getMaiorVenda() {
        return maiorVenda;
    }

    public void setMaiorVenda(float maiorVenda) {
        this.maiorVenda = maiorVenda;
    }

    public float getMediaVendida() {
        return mediaVendida;
    }

    public void setMediaVendida(float mediaVendida) {
        this.mediaVendida = mediaVendida;
    }
}
