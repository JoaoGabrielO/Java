import javax.swing.*;

public class Ex_4_String {
    public static void main(String[] args){

        String nome = JOptionPane.showInputDialog("Digite seu nome ");
        String endereco = JOptionPane.showInputDialog("Digite seu endereço ");
        int telefone = Integer.parseInt(JOptionPane.showInputDialog("Digite seu telefone"));
        System.out.println(nome + "\n" + endereco + "\n" + telefone );
    }
}
