import javax.swing.*;

public class Ex_3_String {
    public static void main(String[] args){
    int i=1;
        String nome = JOptionPane.showInputDialog("Digite seu nome");

        do {
            System.out.print("\n" + nome);
            i ++;

    }while ( i < 11);
    }
}
