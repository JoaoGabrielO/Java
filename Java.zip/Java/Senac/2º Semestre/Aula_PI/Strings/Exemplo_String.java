import javax.swing.*;

public class Exemplo_String {

    public static void main(String[] args){

        String nome = JOptionPane.showInputDialog("Digite um nome: ");
        JOptionPane.showInputDialog(null, "Nome Digitado: " + nome);
        nome = JOptionPane.showInputDialog("Digite outro nome: ");
        JOptionPane.showMessageDialog(null, "Nome Digitado: " + nome);
        System.out.println("Cractere na 3° posição: " + nome.charAt(2));
        System.out.println("Nome completo: " + nome.concat(" de Arruda Monteiro"));
        System.out.println("Nome depois das alterações: " + nome);

        if(nome.equals("MARCOS "))//compara diferenciando Maiúsculas e Minúsculas
            System.out.println("Seu nome é MARCOS.");
        if(nome==("Marcos "))//compara diferenciando Maiúsculas e Minúsculas
            System.out.println("Seu nome é MARCOS. Usando ==");
        else if(nome.equalsIgnoreCase("MARCOS"))//compara sem diferenciar Maiusculas
            System.out.println("Seu nome é MARCOS, usando o equalsIgnoreCase ");
        nome += " de Arruda Monteiro";
        System.out.println("Ultima ocorrência do r em nome: " + nome.lastIndexOf("r"));
        System.out.println("Tamanho do nome: " + nome.length());
        System.out.println("Trocando r por y no nome: " + nome.replace("r" , "y"));
        System.out.println("Nome: " + nome);

        if(nome.startsWith("M"))//Verifica se inicia com o(s) caracteres de parâmetro
            System.out.println("Seu nome inicia com M. ");
        if(nome.endsWith("o"))//Verifica se termina com o(s) caracteres de parâmetro
            System.out.println("Seu nome termina com O. ");

        System.out.println("Extraindo os caracteres de 2 a 4: " + nome.substring(1, 5));
        System.out.println("Extraindo todos caracteres a partir do 2: " + nome.substring(1));

    }
}
