package Facul_Tads.Aula_PI;

import javax.swing.*;

public class Ex_1_String{

        public static void main(String[] args) {
            String nome = JOptionPane.showInputDialog("Digite um nome: ");
            System.out.println("Quatro primeiros caracteres " + nome.substring(0, 4));
        }
}


