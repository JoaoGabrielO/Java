package Facul_Tads.Aula_PI;

import javax.swing.*;

public class Ex_2_String {
        public static void main(String[] args){

            String nome = JOptionPane.showInputDialog("Digite um nome: ");
            System.out.println("Nome digitado: " + nome);
            for (int i =0; i<nome.length(); i++)

                if(i %2==1)
                    System.out.println("Os caracteres impares são: " + nome.charAt(i));

        }
    }


