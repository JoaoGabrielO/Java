import javax.swing.*;

public class Ex_5_String {
    public static void main(String[] args){

        String nome = JOptionPane.showInputDialog("Digite seu nome: ");
        String sexo = JOptionPane.showInputDialog("Digite seu sexo: ");
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade: "));


            if (sexo.equalsIgnoreCase("feminino") && idade < 25){

                System.out.println(nome + "\n" + "ACEITA ");

        }
            else {

            System.err.println("NÃO ACEITA ");
        }
    }
}
