package com.company;

import javax.swing.JOptionPane;

    public class Ex_1_JOptionPane_DO {
        public static void main(String[] args) {

            String nome;
            float salario;
            int resp = 0;

            do
            {
                nome = JOptionPane.showInputDialog(null, "Digite seu nome ");
                JOptionPane.showMessageDialog(null, "Seu nome = " + nome);

                salario = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite seu salario "));
                JOptionPane.showMessageDialog(null, "Seu salario " + salario);

                resp = JOptionPane.showConfirmDialog(null, "Deseja Continuar ");
                JOptionPane.showMessageDialog(null, "Sua resposta = " + resp);

            }while(resp == 0);
        }
    }




