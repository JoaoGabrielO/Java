import java.util.Scanner;

public class conversao_Binario_Decimal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um número em binario:");
        String numero = sc.next();

        char vetor[] = new char[numero.length()];
        conversorChar(numero, vetor);
        conversorBinario(vetor);
        imprimirVetor(vetor);

    }
    public static void conversorBinario( char vetor[]) {
        int somaNumeros = 0;

        for (int i = vetor.length; i > 0; i--) {
            if (i == vetor.length && vetor[i] == 1) {
                somaNumeros += 1;

            } else if (i == vetor.length - 1 && vetor[i] == 1) {
                somaNumeros += 2;

            } else {
                somaNumeros += i * i;
            }
        }
    }
        public static void conversorChar (String numero,char vetor[]){
            for (int i = 0; i < numero.length(); i++) {
                vetor[i] = numero.charAt(i);
            }
        }
        public static void imprimirVetor ( char vetor[]){
            for (int i = 0; i < vetor.length; i++) {
                System.out.print("\t" + vetor[i]);
            }
        }
    }

