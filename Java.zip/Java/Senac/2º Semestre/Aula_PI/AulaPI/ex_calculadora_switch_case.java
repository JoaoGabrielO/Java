package Facul_Tads.Aula_PI;

import java.util.Scanner;

public class ex_calculadora_switch_case {

        public static void main(String[] args)
        {
            double a, b;
            String operacaoStr;
            char operacao;

            Scanner entrada = new Scanner(System.in);

            System.out.println("<A>di��o");
            System.out.println("<S>ubtra��o");
            System.out.println("<M>ultiplica��o");
            System.out.println("<D>ivis�o");
            System.out.print("Escolha a opera��o: ");

            operacaoStr = entrada.next();
            operacao = operacaoStr.charAt(0);

            System.out.println("1� operando: ");
            a = entrada.nextDouble();
            System.out.println("2� operando: ");
            b = entrada.nextDouble();
            switch (operacao) {
                case 'a':
                case 'A':
                    System.out.println("Soma: " + (a+b));
                    break;
                case 's':
                case 'S':
                    System.out.println("Diferen�a: " + (a - b));
                    break;
                case 'm':
                case 'M':
                    System.out.println("Diferen�a: " + (a * b));
                    break;
                case 'd':
                case 'D':
                    System.out.println("Diferen�a: " + (a / b));
                    break;

            }
        }
    }