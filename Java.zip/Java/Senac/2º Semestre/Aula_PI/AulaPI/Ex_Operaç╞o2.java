package AulaPI;

import java.util.Scanner;

import static AulaPI.Ex_Operação.*;

    public class Ex_Operação2 {

        public static void main(String[] args){
            int resp = 0;
            double a, b, resultado;

            Scanner sc = new Scanner(System.in);

            do {

                System.out.println("Digite a operação que deseja: \n(1)Soma \n(2)Multiplicação \n(3)Subtração \n(4)Divisão \n(5)Área circulo \n(6)Área triângulo \n(0)Saida");
                int operacao = sc.nextInt();

                switch (operacao) {

                    case 1:
                        System.out.println("Digite o primeiro valor ");
                        a = sc.nextDouble();
                        System.out.println("Digite o segunda valor ");
                        b = sc.nextDouble();

                        resultado = soma(a, b);
                        System.out.println("A soma é: " + resultado);
                        break;

                    case 2:
                        System.out.println("Digite o primeiro valor ");
                        a = sc.nextDouble();
                        System.out.println("Digite o segunda valor ");
                        b = sc.nextDouble();

                        resultado = multiplicacao(a, b);
                        System.out.println("O produto é: " + resultado);
                        break;

                    case 3:
                        System.out.println("Digite o primeiro valor ");
                        a = sc.nextDouble();
                        System.out.println("Digite o segunda valor ");
                        b = sc.nextDouble();

                        resultado = subtracao(a, b);
                        System.out.println("A diferença é: " + resultado);
                        break;

                    case 4:
                        System.out.println("Digite o primeiro valor ");
                        a = sc.nextDouble();
                        System.out.println("Digite o segunda valor ");
                        b = sc.nextDouble();

                        resultado = divisao(a, b);
                        System.out.println("A divisão é: " + resultado);
                        break;

                    case 5:
                        System.out.println("Digite o raio do circulo ");
                        int r = sc.nextInt();
                        resultado = areacirc(r);
                        System.out.println("A aréa do circulo é: " + resultado);
                        break;

                    case 6:
                        System.out.println("Digite o valor da base ");
                        int B = sc.nextInt();
                        System.out.println("Digite a altura ");
                        int A = sc.nextInt();
                        resultado = areatri(B, A);
                        System.out.println("A aréa do triangulo é " + resultado);
                        break;

                    case 0:
                        resp =2;
                        System.err.println("Tchau !! Até a proxima !!");
                        break;

                    default:
                        System.err.println("!!!!!!!!!!!!!!!!!Número Inválido !!!!!!!!!!!!!");
                        resp = 1;
                        break;

                }
            }while (resp == 0);
        }
}
