package com.company;

import javax.swing.*;

public class Ex_1_JOptionPane {
    public static void main(String[] args) {

        String nome;
        float salario;
        int resp = 0;

        while(resp == 0){

            nome = JOptionPane.showInputDialog(null, "Digite seu nome ");
            JOptionPane.showMessageDialog(null, "Seu nome = " + nome);

            salario = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite seu salario "));
            JOptionPane.showMessageDialog(null, "Seu salario " + salario);

            resp = JOptionPane.showConfirmDialog(null, "Deseja Continuar ");
            JOptionPane.showMessageDialog(null, "Sua resposta = " + resp);

        }
    }
}


