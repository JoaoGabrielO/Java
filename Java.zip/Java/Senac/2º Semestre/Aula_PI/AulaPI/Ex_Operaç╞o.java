package AulaPI;

public class Ex_Operação {

        static double soma (double a, double b){

            double Ressoma = 0;
            Ressoma = a + b;
            return (Ressoma);
        }

        static double multiplicacao (double a, double b){
            double Resmulti = 0;
            Resmulti = a * b;
            return (Resmulti);
        }

        static double subtracao (double a, double b){
            double Ressub = 0;
            Ressub = a - b;
            return (Ressub);
        }

        static double divisao (double a, double b){
            double Resdiv = 0;
            Resdiv = a / b;
            return (Resdiv);
        }

        static double areatri (double b, double h){

            return b * h/2;
        }

        static double areacirc (double r){

            return Math.PI * (r * r);
        }

    }

