import javax.swing.*;

public class Calculadora_PI {
    static double soma (double a, double b){

        double Ressoma = 0;
        Ressoma = a + b;
        return (Ressoma);
    }

    static double multiplicacao (double a, double b){
        double Resmulti = 0;
        Resmulti = a * b;
        return (Resmulti);
    }

    static double subtracao (double a, double b){
        double Ressub = 0;
        Ressub = a - b;
        return (Ressub);
    }

    static double divisao (double a, double b){
        double Resdiv = 0;
        Resdiv = a / b;
        return (Resdiv);
    }

    static double raiz (double a){
        double Resraiz = 0;
        Resraiz = Math.sqrt(a);
        return (Resraiz);
    }

    static double potencia (double a, double b){
        double Respot = 0;
        Respot = Math.pow(a, b);
        return (Respot);
    }

    static double pi (double a) {
        double ResPI = 0;
        ResPI = Math.PI;
        return (ResPI);

    }

    static double fatorial (double a) {
        int ResFat = (int) a;

        if (a >= 0) {
            while (a > 1) {
                ResFat = (int) (ResFat * (a - 1));
                a--;

            }
        }
        return ResFat;
    }
    public static void main(String[] args){
        int resp = 0;
        double a, b, resultado;

        do {

            int operacao = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a operação que deseja: \n(1)Soma     \t(2)Multiplicação \n(3)Subtração     \t(4)Divisão \n(5)Raiz      \t(6)Potência \n(7)Valor PI      \t(8)Fatorial \n\n(0)Saida \n"));

            switch (operacao) {

                case 1:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o primeiro valor "));

                    b = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o segundo valor "));

                    resultado = soma(a, b);
                    JOptionPane.showMessageDialog(null, "A soma é: " + resultado);
                    break;


                case 2:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o primeiro valor "));

                    b = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o segundo valor "));

                    resultado = multiplicacao(a, b);
                    JOptionPane.showMessageDialog(null, "O produto é: " + resultado);
                    break;


                case 3:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o primeiro valor "));

                    b = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o segundo valor "));

                    resultado = subtracao(a, b);
                    JOptionPane.showMessageDialog(null, "A diferença é: " + resultado);
                    break;


                case 4:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o primeiro valor "));

                    b = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o segundo valor "));

                    resultado = divisao(a, b);
                    JOptionPane.showMessageDialog(null, "A divisão é: " + resultado);
                    break;


                case 5:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor "));

                    resultado = raiz(a);
                    JOptionPane.showMessageDialog(null, "A Raiz é: " + resultado);
                    break;


                case 6:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o primeiro valor "));

                    b = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o segundo valor "));

                    resultado = potencia(a, b);
                    JOptionPane.showMessageDialog(null, "A Potência é: " + resultado);
                    break;

                case 7:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor "));

                    resultado = pi(a);
                    JOptionPane.showMessageDialog(null, "O valor de PI é: " + resultado);
                    break;

                case 8:
                    a = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor "));

                    resultado = fatorial(a);
                    JOptionPane.showMessageDialog(null, "O resultado de " + a + " em fatorial é: " + resultado);
                    break;

                case 0:
                    resp =2;
                    JOptionPane.showMessageDialog(null, "Tchau !! Até a proxima !!");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "   !!!!!!!!!!!!!!!!!Número Inválido !!!!!!!!!!!!!   1");
                    resp = 1;
                    break;

            }
        }while (resp == 0);
    }
}
