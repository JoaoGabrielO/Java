package com.company;

public class Ex_método_PI4 {
    public static void main(String[] args){
        System.out.println(Math.max(23.53,23));
        System.out.println(Math.max(35.98,-40.8));
        System.out.println(Math.max(Math.max(-650,500),600));

        double PI = Math.PI;
        double E = Math.E;

        System.out.println("Valor de PI: " + PI + "\nValor de E: " + E);
    }
}

