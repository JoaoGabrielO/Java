package com.company;

public class Ex_método_PI {
    public static void main(String[] args){
         System.out.println(Math.abs(23.53));
        System.out.println(Math.abs(35));
        System.out.println(Math.abs(-65));

        double PI = Math.PI;
        double E = Math.E;

        System.out.println("Valor de PI: " + PI + "\nValor de E: " + E);
    }
}
