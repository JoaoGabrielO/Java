package com.company;

import javax.swing.*;

public class Ex_método_PI7 {
    public static void main(String[] args){

        int menor = Integer.parseInt(JOptionPane.
                showInputDialog("Digite o valor do menor número"));
        int maior = Integer.parseInt(JOptionPane.
                showInputDialog("Digite o valor do maior número"));

        for(int i= 0 ; i <10 ; i++)
        {

           System.out.print(" " + Math.round((
                    Math.random() * (maior - (-menor)) + (-menor))));
        }
    }
}
