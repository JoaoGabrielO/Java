package com.company;

public class Ex_método_PI5 {
    public static void main(String[] args){
        System.out.println(Math.min(23.53,23));
        System.out.println(Math.min(35.98,-40.8));
        System.out.println(Math.min(Math.max(-650,500),600));

        double PI = Math.PI;
        double E = Math.E;

        System.out.println("Valor de PI: " + PI + "\nValor de E: " + E);
    }
}



