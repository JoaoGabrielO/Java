package com.company;

public class Ex_método_PI6 {
}
