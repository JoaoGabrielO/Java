public class Teste
{
    public static void main(String[] args)
    {
        System.out.println("Realizando Testes");

        int Matriz1[][] = new int[][]
                {   {11,12,13,14,15},
                        {30,29,28,27,26},
                        {42,42, 0,42,42}};

        testarMaximo(Matriz1, 42);

        int Matriz2[][] = new int[][] {
                {-56,-17,-23,-15},
                {-78,-81,-2,-29},
                {-25,-25,-19,-20}};
        testarMaximo(Matriz2, -2);
    }
    public static void testarMaximo(
            int[][] matriz2D, int valorEsperado){
        if(Matriz_Inteiros.MatrizDeInteiros.maximo(matriz2D)
                !=valorEsperado) {
            System.out.println("Essa não ERRO!!!");
        }else
            System.out.println("Passou no Teste!!!");
    }
}
