package AulaPI;

import javax.swing.*;

public class Array_Vetor {
    public static void main(String[] args) {

        int vetor[] = new int[5];
        String nomes[] = new String[5];

        vetor[0] = 10;
        vetor[1] = 50;
        vetor[2] = 35;
        vetor[3] = 45;
        vetor[4] = 60;

        nomes[0] = "Joao";
        nomes[1] = "Lucas";
        nomes[2] = "Maria";
        nomes[3] = "Pedro";
        nomes[4] = "José";

        for (int i = 0; i < 5; i++)  // laço cadastro
        {
            vetor[i] = Integer.parseInt(JOptionPane.showInputDialog
                    ("Digite um número: "));

            nomes[i] = JOptionPane.showInputDialog
                    ("Digite um nome: ");
        }
        for (int i = 0; i < 5; i++)  //laço de impressão
        {
            System.out.println("Número " + vetor[i] + " Nome: " + nomes[i]);
        }
    }
}