package Java_Inicial.Senac;

public class Vet_Pares {
    public static void main(String[] args) {
        int vetor[] = new int[10];
        int vetor2[] = new int[20];
        int j = 0;

            for (int i = 2; i < 21; i++) {
                if (i % 2 == 0) {
                    vetor2[j] = i;
                    j++;
                }
            }
        for(int i = 0; i < vetor.length; i++){
            System.out.println(vetor2[i] + " ");
        }
    }
}
