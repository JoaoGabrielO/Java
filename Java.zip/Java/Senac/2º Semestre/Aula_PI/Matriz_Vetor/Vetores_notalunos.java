package AulaPI;

import javax.swing.*;

public class Vetores_notalunos {
    public static void main(String[] args) {

        int qtd = Integer.parseInt(JOptionPane.showInputDialog
                ("Digite a quantidade de alunos a cadastrar: "));
        String matriz[][] = new String[qtd][4];//qtd de alunos e as colunas Nome, Nota1, Nota2 e conceito
        //laço de cadastro
        for (int l = 0; l < matriz.length; l++) {//laço de linhas(l)

            for (int c = 0; c < matriz[1].length; c++) {//laço de colunas (c)
                if (c == 0) {//Nome
                    matriz[1][c] = JOptionPane.showInputDialog("Digite o nome do " + (l + 1) + " ° Aluno");

                } else if (c == 1) {//Nota1
                    matriz[1][c] = JOptionPane.showInputDialog("Digite a 1° nota do " + (l + 1) + "° Aluno");
                } else if (c == 2) {//Nota2
                    matriz[1][c] = JOptionPane.showInputDialog("Digite a 2° nota do " + (l + 1) + "° Aluno");
                } else if (c == 3) {//Conceito
                    float media = (Float.parseFloat(matriz[1][1] + Float.parseFloat(matriz[1][2])) / 2);
                    if (media >= 6)
                        matriz[1][c] = "Aprovado ";
                    else
                        matriz[l][c] = "Reprovado";
                }
            }
        }
    }//laço de impressão
}
