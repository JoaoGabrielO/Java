package AulaPI;

import javax.swing.*;

public class Vetores_Aluno {
    public static void main(String[] args) {

        int qtd = Integer.parseInt(JOptionPane.showInputDialog
                ("Digite a quantidade de alunos a cadastrar: "));
        String alunos[] = new String[qtd];
        int nota = 0;
        
        for (int i = 0; i < alunos.length; i++)  // laço cadastro
        {
            alunos[i] = JOptionPane.showInputDialog
                    ("Digite os nomes dos alunos: ");
            
            nota = Integer.parseInt(JOptionPane.showInputDialog
                    ("Digite a nota do aluno: "));
        }

        for (int i = 0; i < alunos.length; i++)  //laço de impressão
        {
            System.err.println("Número " + i + "\n Alunos: " + alunos[i] + "\n Nota: " + nota );

        }
    }
}
