package com.company;

import java.util.Scanner;

public class Exem_Funcao {
    private static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Informe quantos números serão digitados: ");
        int n = entrada.nextInt();

        int vetor[] = new int[n];

        leitura(vetor);
        impressao(vetor);
    }

    public static void leitura(int vetor[])
    {

        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Digite o " + (i + 1) + " o valor: ");
            vetor[i] = entrada.nextInt();
        }
    }
    public static void impressao(int vetor[]) {

        System.out.println("\nValores armazenados: ");
        for (int item : vetor) {
            System.out.println(item);
        }
    }
}