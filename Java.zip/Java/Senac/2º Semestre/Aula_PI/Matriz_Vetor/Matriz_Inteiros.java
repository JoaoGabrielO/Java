import javax.swing.*;

public class Matriz_Inteiros {
    public class MatrizDeInteiros {
        public static void main(String[] args) {
            int matriz[][] = new int[3][3];
            //laço de cadastro
            for(int l=0 ; l<matriz.length ; l++)//laço de linhas(l)
            {
                for(int c=0 ; c<matriz[l].length ; c++)//laço de colunas(c)
                {
                    matriz[l][c] = Integer.parseInt(JOptionPane.showInputDialog
                            ("Digite o " + (l+1) + "º número da " + (c+1) + "ª coluna"));
                }
            }
            //laço de impressão
            for(int l=0 ; l<matriz.length ; l++)//laço de linhas(l)
            {
                for(int c=0 ; c<matriz[l].length ; c++)//laço de colunas(c)
                {
                    System.out.print(matriz[l][c] + "\t");
                }
                System.out.println(); //quebrando linha a cada nova linha
            }
        }

        public static int maximo(int[][] matriz2d)
        {
            int max=-2147483648;
            for(int[]vetor: matriz2d) {
                for(int item:vetor) {
                    if(item>max)
                        max=item;
                }
            }
            return max;
        }
    }

}
