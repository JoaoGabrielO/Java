package POO_Java.Senac.Exs_Pilha;

import javax.swing.*;

public class ExPilha_Cresc {
    public static void main (String [] args){
        Pilha_Cresc pilha = new Pilha_Cresc();
        int resp = 0;
        int tam = 0;

        do{
            String caractere = JOptionPane.showInputDialog("Digite um caracter");
            pilha.push(caractere.charAt(0));
            resp = JOptionPane.showConfirmDialog(null, "Cadastrar outro?");
            tam++;

        } while (resp == 0 && tam < pilha.elementos.length);

        System.out.print(LerPilhaChar(pilha));
    }

    public static String LerPilhaChar (Pilha_Cresc pilha){
        String s = "";
        while(pilha.topo2 < pilha.tam){
            s += pilha.pop();
        }
        return s;
    }
}
