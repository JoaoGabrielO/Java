package POO_Java.Senac.Exs_Pilha;

import javax.swing.*;

public class Pilha_Cresc {
    public int tam = Integer.parseInt(
            JOptionPane.showInputDialog("Digite o tamanho da Pilha")); //vetor da pilha de caracteres

    char elementos[] = new char[tam];

    int topo = -1; //variavel com o topo da pilha, inicialmente a pilha esta vazia
    int topo2 = 0;
    public void push (char c){
        topo++; //sobe o topo
        elementos[topo] = c; //insere o elemento no topo
    }

    public char pop(){
        char c = elementos[topo2];
        topo2++;
        return c;

    }
}
