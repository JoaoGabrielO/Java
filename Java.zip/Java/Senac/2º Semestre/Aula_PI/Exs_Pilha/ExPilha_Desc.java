package POO_Java.Senac.Exs_Pilha;

import javax.swing.JOptionPane;

public class ExPilha_Desc {
    public static void main (String [] args){
        Pilha_Desc pilha = new Pilha_Desc();
        int resp = 0;
        int tam = 0;

        do{
            String caractere = JOptionPane.showInputDialog("Digite um caracter");
            pilha.push(caractere.charAt(0));

            resp = JOptionPane.showConfirmDialog(null, "Cadastrar outro?");
            tam++;

        } while (resp == 0 && tam < pilha.elementos.length);

        System.out.print(LerPilhaChar(pilha));
    }

    public static String LerPilhaChar (Pilha_Desc pilha){
        String s = "";
        while(pilha.topo > -1){
            s += pilha.pop();
        }
        return s;
    }
}