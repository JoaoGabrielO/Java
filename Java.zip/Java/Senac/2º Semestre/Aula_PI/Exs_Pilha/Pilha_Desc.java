package POO_Java.Senac.Exs_Pilha;

import javax.swing.JOptionPane;

public class Pilha_Desc {
    public int tam = Integer.parseInt(
            JOptionPane.showInputDialog("Digite o tamanho da Pilha")); //vetor da pilha de caracteres

    char elementos[] = new char[tam];

    int topo = -1; //variavel com o topo da pilha, inicialmente a pilha esta vazia

    public void push (char c){
        topo++; //sobe o topo
        elementos[topo] = c; //insere o elemento no topo
    }

    public char pop(){
        char c = elementos[topo];
        topo--;
        return c;
    }
}
