package POO_Java.Senac.Ex_Genero_Salario;

import java.util.Scanner;

public class genero_Salario_Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        genero_Salario trabalhador = new genero_Salario();

        System.out.println("Quantos trabalhadores deseja cadastrar ?");
        int qtd = sc.nextInt();

        genero_Salario trabalhadores[] = new genero_Salario[qtd];
        float mediaSalarios = 0;
        float menorSalario = 0;
        int identificador = 0;
        int maiorMil = 0;

        for(int i = 0; i < qtd; i++){
            genero_Salario novo = new genero_Salario();

            System.out.println("======================================");
            System.out.println("Nome do " + (i +1) + "º trabalhador:" );
            String nome = sc.next();
            novo.setNome(nome);
            System.out.println("Genero do trabalhador: \n 'M':Masculino ou 'F':Feminino " );
            char genero = sc.next().charAt(0);
            novo.setGenero(genero);
            System.out.println("Salario do trabalhador:");
            float salario = sc.nextFloat();
            novo.setSalario(salario);

            if(menorSalario == 0){
                menorSalario = novo.getSalario();
            }
            if(menorSalario > novo.getSalario()){
                menorSalario = novo.getSalario();
                identificador = i;
            }
            if(novo.getSalario() > 1000.0f && novo.getGenero() == 'M'){
                maiorMil ++;
            }
            mediaSalarios += novo.getSalario() /qtd;

            trabalhadores[i] = novo;
        }
        System.out.println("============================================");
        for(int i = 0; i < qtd; i++){
            System.out.println(trabalhadores[i]);
            System.out.println("============================================");
        }
        System.out.println("Media salarial da empresa: " + mediaSalarios);
        System.out.println("Menor salario: " + menorSalario);
        System.out.println("============================================");
        System.out.println("Pessoa com menor salario: " + trabalhadores[identificador]);
        System.out.println("============================================");
        System.out.println("Quantidade de homens que ganham salario maior que mil reais: " + maiorMil);
    }
}
