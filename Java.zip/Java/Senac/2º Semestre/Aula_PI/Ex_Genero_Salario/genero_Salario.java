package POO_Java.Senac.Ex_Genero_Salario;

public class genero_Salario {
    private float salario;
    private String nome;
    private char genero;

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }
    public genero_Salario(){
        super();
    }

    @Override
    public String toString(){
    return "Nome: " + nome + "\n Salario: " + salario + "\n Genero: " + genero;
    }
}
