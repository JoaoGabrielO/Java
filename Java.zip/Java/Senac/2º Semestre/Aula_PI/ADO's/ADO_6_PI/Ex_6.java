import java.sql.SQLOutput;
import java.util.Scanner;

public class Ex_6 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int tent = 0;
        int cont = 0;
        int S = 0;

        do {

            System.out.println("\nQual a disciplina de segunda-feira? ");
            System.out.println("\n[A] Algoritmos ");
            System.out.println("[B] Fundamentos Adm ");
            System.out.println("[C] Conceitos de computação ");
            System.out.println("[D] Pts ");
            System.out.println("[E] Matematica ");
            String N = sc.next();

            switch (N) {

                case "A":
                case "a":
                    cont = 3;
                    tent ++;
                    S = 1;
                    System.out.println("Resposta correta ");
                    break;

                case "B":
                case "b":
                    cont ++;
                    tent ++;
                    S = 2;
                    System.out.println("Resposta errada ");
                    break;

                case "C":
                case "c":
                    cont ++;
                    tent ++;
                    S = 2;
                    System.out.println("Resposta errada ");
                    break;

                case "D":
                case "d":
                    cont ++;
                    tent ++;
                    S = 2;
                    System.out.println("Resposta errada ");
                    break;

                case "E":
                case "e":
                    cont ++;
                    tent ++;
                    S = 2;
                    System.out.println("Resposta errada ");
                    break;

            }
        }while (cont < 3);

        if (tent <= 3 & S == 1 ) {
            System.out.println("Resposta correta na " + tent + "° tentativa");

        } else if (tent <= 3 && S == 2) {
            System.out.println("Resposta incorreta nas 3 tentativas ");
        }
    }
}
