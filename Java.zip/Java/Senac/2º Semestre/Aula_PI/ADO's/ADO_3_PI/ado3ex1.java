package AulaPI;

import javax.swing.JOptionPane;

public class ado3ex1 {

	public static void main(String[] args) 
	{
		float desconto; 
		float valor = Integer.parseInt(
				JOptionPane.showInputDialog("Qual o valor da sua compra? "));
	
		if (valor >= 300) {
			 desconto = (float) (valor * 0.20); 
		
			System.out.println("O valor da sua compra deu R$ " + (valor - desconto) + " e o valor do seu desconto foi de R$ " + desconto);
			
		
		} 
		else { 
			 desconto = (float) (valor * 0.15); 
			System.out.println("O valor da sua compra deu R$ " + (valor - desconto) + " e o valor do seu desconto foi de R$ " + desconto);
			
				
			
	
			
				
				

		
		
		}	
	}
}