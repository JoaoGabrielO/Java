package AulaPI;

import javax.swing.JOptionPane;

public class ado3ex3 {

	public static void main(String[] args) 
	{
		float ano = Integer.parseInt(
				JOptionPane.showInputDialog("Digite um ano com quatro digitos "));
		if (ano % 4 ==0 && ano % 100 != 0 || ano % 400 ==0) {
			System.out.println("Esse � um ano bissexto!! ");
			}else 
			{
				System.out.println("Esse n�o � um ano bissexto ");
				
			}
		}
	}


