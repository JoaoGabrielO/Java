package AulaPI;

import java.util.Scanner;

public class ado3ex2 {

	public static void main(String[] args) 
	{
		float a,b,c;
		
		Scanner triangulo = new Scanner(System.in);
		System.out.println("Digite o lado A ");
		a = triangulo.nextFloat();
		System.out.println("Digite o lado B ");
		b = triangulo.nextFloat();		
		System.out.println("Digite o lado C ");
		c = triangulo.nextFloat();
		
		if (a>=b+c || b>=c+a || c>=a+b) {
	       System.out.println("N�o � um tri�ngulo ");
	         }else if 
		 	(a == b && b == c)
	        System.out.println("Triangulo equilatero.");

	          else if (a==b || b==c || c==a)
	        System.out.println("Triangulo isosceles.");

	          else
	        System.out.println("Triangulo escaleno.");
	         

		 
		
		}

	}


