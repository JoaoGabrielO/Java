package Facul_Tads.Aula_PI;

import java.util.Scanner;

public class ADO_10 {
    public static void main(String[] args) {

        double random = Math.random();
        int M = (int) ( 1 + random * (100-1));

        System.out.println(M);
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < 5; i++){
            System.out.println("Digite o número que você acha que irá cair entre 1 e 100 ");
            int N = sc.nextInt();

             if (M == N +1 || M == N-1) {
                 System.out.println("QUENTE !! \n");

             } else if (M != N) {
                 System.out.println("Você errou ");
                 if (M > N) {
                     System.out.println("O valor é maior do que o que você digitou !! \n ");
                 } else if (M < N) {
                     System.out.println("O valor é menor do que o que você digitou !! \n ");
                 }
             } else if (M == N) {
                 System.out.println("PARABÉNS !!! VOCÊ GANHOU O JOGO \n");
                break;
             }
        }
        System.out.println("GAME OVER !!! ");
    }
}
