package Facul_Tads.Aula_PI;

import java.util.Scanner;

public class ado_5_ex1 {
    public static void main(String[] args) {

        int i = 0;
        int loop = 0;

        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("(1) INTRODUÇÕES ");
            System.out.println("(2) JOGAR ");
            System.out.println("(3) CRÉDITOS ");
            System.out.println("(4) SAIR ");
            System.out.print("\nEscolha um número ");
            int operacao = sc.nextInt();
            i++;


            switch (operacao) {

                case '1':
                    loop = 1;
                    System.err.println("\nNúmero digitado:" + operacao);
                    break;

                case '2':
                    loop = 1;
                    System.out.println("\nNúmero digitado:" + operacao);
                    break;

                case '3':
                    loop = 1;
                    System.out.println("\nNúmero digitado:" + operacao);
                    break;

                case '4':
                    loop = 0;
                    System.out.println("\nNúmero digitado: " + operacao);
                    break;

                default:
                    loop = 1;
                    System.err.println("\nNúmero digitado: " + operacao + "\nNúmero invalido !! \nDigite algum dos números apresentados no menu !!");
            }
        }while (loop == 1) ;


    }
}




