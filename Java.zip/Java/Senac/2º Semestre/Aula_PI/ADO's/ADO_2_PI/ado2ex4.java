package AulaPI;



public class ado2ex4 {

	public static void main(String[] args) {
	
		String nome = "String contada";
		System.out.println(nome.length());
	

	}

}
