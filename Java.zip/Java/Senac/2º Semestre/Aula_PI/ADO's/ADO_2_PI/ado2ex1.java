package AulaPI;

import javax.swing.JOptionPane;

public class ado2ex1 {

	public static void main(String[] args) {
		
		float valor1 = Integer.parseInt(
				JOptionPane.showInputDialog("Digite o 1� valor "));
		float valor2 = Integer.parseInt(
				JOptionPane.showInputDialog("Digite o 2� valor "));
		float valor3 = Integer.parseInt(
				JOptionPane.showInputDialog("Digite o 3� valor "));
		System.out.println("O valor do produto desses valores � de : " + (valor1 + valor2 + valor3));
	}

}
