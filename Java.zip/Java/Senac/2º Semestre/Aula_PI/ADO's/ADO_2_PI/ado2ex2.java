package AulaPI;

import javax.swing.JOptionPane;

public class ado2ex2 {

	public static void main(String[] args) {
		int valor = Integer.parseInt(
				JOptionPane.showInputDialog("Digite um valor "));
		for (int i=1 ; i<4 ; i++)
		{
			System.out.println(valor + " X " + i + " = " + (valor*i));
		}
		
	}

}
