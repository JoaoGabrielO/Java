public class Campo_Minado {

        public static void main(String[] args) {
            Jogo jogo = new Jogo();

        }
    }

