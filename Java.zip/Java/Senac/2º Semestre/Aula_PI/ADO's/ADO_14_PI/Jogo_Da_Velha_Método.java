public class Jogo_Da_Velha_Método {

    private String[][] matriz = {{"1", "2", "3"},
            {"4", "5", "6"},
            {"7", "8", "9"}};

    public String Mostrando() {//MOSTRANDO PAINEL DE OPÇÕES DE JOGADA.
        for (int l = 0; l < 3; ++l) {
            for (int c = 0; c < 3; ++c) {
                System.out.printf("   " + matriz[l][c]);

            }
            System.out.println("\n");
        }
        return null;
    }

    public boolean Validador(String posi) {//VALIDAR A JOGADA FEITA(SE É IGAUL A POSIÇAÕ NA MATRIZ)

        for (int l = 0; l < 3; ++l) {
            for (int c = 0; c < 3; ++c) {
                if (matriz[l][c].equals(posi)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void Jogada(String posi, String jogador) {
        if (posi.equals("1")) {
            matriz[0][0] = jogador;
        } else if (posi.equals("2")) {
            matriz[0][1] = jogador;
        } else if (posi.equals("3")) {
            matriz[0][2] = jogador;
        } else if (posi.equals("4")) {
            matriz[1][0] = jogador;
        } else if (posi.equals("5")) {
            matriz[1][1] = jogador;
        } else if (posi.equals("6")) {
            matriz[1][2] = jogador;
        } else if (posi.equals("7")) {
            matriz[2][0] = jogador;
        } else if (posi.equals("8")) {
            matriz[2][1] = jogador;
        } else if (posi.equals("9")) {
            matriz[2][2] = jogador;
        }
    }

    public String Ganhador(int jogadas){
        String[] vetor = new String[8];
        String vencedor = "null";

        if(jogadas == 9){
            vencedor = " EMPATE ";

        }
        vetor[0] = matriz[0][0] + matriz[0][1] + matriz[0][2];
        vetor[1] = matriz[1][0] + matriz[1][1] + matriz[1][2];
        vetor[2] = matriz[2][0] + matriz[2][1] + matriz[2][2];

        vetor[3] = matriz[0][0] + matriz[1][0] + matriz[2][0];
        vetor[4] = matriz[0][1] + matriz[1][1] + matriz[2][1];
        vetor[5] = matriz[0][2] + matriz[1][2] + matriz[2][2];

        vetor[6] = matriz[0][0] + matriz[1][1] + matriz[2][2];
        vetor[7] = matriz[0][2] + matriz[1][1] + matriz[2][0];
        
        for(int i = 0; i < vetor.length; ++ i){
            if(vetor[i].equals("XXX")){
                vencedor = "Jogador 1";
                
            } else if (vetor[i].equals("OOO")){
                vencedor = "Jogador 2";
                
            }
        }
        return vencedor;
    }
}

