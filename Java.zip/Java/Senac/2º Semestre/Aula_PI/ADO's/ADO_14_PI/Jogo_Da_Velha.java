import java.util.Scanner;

public class Jogo_Da_Velha {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        Jogo_Da_Velha_Método jogo = new Jogo_Da_Velha_Método();
        String posicao ;
        int Validar = 0, Jogadas = 0;

        while(true){
            System.out.println("=========== JOGO DA VELHA ===========");
            jogo.Mostrando();

            do{//INICIANDO JOGADOR 1
                System.out.println("Jogador 1. Informe uma posição: ");
                posicao = sc.next();

                while(!jogo.Validador(posicao)){
                    System.out.println("Jogada inválida. Jogue de novo !!");
                    System.out.println("Jogador 1. Informe uma posição: ");
                    posicao = sc.next();
                    Validar = 0;

                }
            jogo.Jogada(posicao, "X");
                Validar = 1;

            }while(Validar == 0);//FIM JOGADOR 1

            ++Jogadas;
            Validar = 0;
            jogo.Mostrando();
            if(!jogo.Ganhador(Jogadas).equals("null")){
                break;

            }
            do{//INICIANDO JOGADOR 2
                System.out.println("Jogador 2. Informe uma posição: ");
                posicao = sc.next();

                while(!jogo.Validador(posicao)){
                    System.out.println("Jogada inválida. Jogue de novo !!");
                    System.out.println("Jogador 2. Informe uma posição: ");
                    posicao = sc.next();
                    Validar = 0;

                }
                jogo.Jogada(posicao, "O");
                Validar = 1;

            }while(Validar == 0);//FIM JOGADOR 2

            ++Jogadas;
            Validar = 0;
            jogo.Mostrando();
            if(!jogo.Ganhador(Jogadas).equals("null")){
                break;

            }
        }
        System.out.println("O " + jogo.Ganhador(Jogadas) + " ganhou !!");
    }
}
