package Facul_Tads.Aula_PI;

import java.util.Scanner;

public class ado_4_e2 {
    public static void main(String[]args) {

        String operacaoStr;
        char operacao;

        Scanner sc = new Scanner(System.in);
        System.err.println("Qual a melhor IDE para Java ? ");
        System.out.println("(A) NetBeans ");
        System.out.println("(B) Eclipse ");
        System.out.println("(C) IntelliJ ");
        System.out.println("(D) Replit ");
        System.out.println("(E) GDB ");

        operacaoStr = sc.next();
        operacao = operacaoStr.charAt(0);

        switch (operacao) {
            case 'A':
            case 'a':
                System.err.println("RESPOSTA ERRADA ");
                break;

            case 'B':
            case 'b':
                System.err.println("RESPOSTA ERRADA ");
                break;

            case 'C':
            case 'c':
                System.out.println("RESPOSTA CERTA ");
                break;

            case 'D':
            case 'd':
                System.err.println("RESPOSTA ERRADA ");
                break;

            case 'E':
            case 'e':
                System.err.println("RESPOSTA ERRADA ");
                break;
            default:
                System.err.println("ALTERNATIVA INVALIDA , DIGITE UMA DAS 5 APRESENTADAS");
        }
    }
}
