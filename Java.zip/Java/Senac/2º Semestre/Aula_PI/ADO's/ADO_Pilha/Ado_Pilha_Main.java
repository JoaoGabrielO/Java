package POO_Java.Senac.ADO_Pilha;

import javax.swing.*;

public class Ado_Pilha_Main {
    public static void main (String [] args){
        Ado_Pilha pilha = new Ado_Pilha();
        int resp = 0;
        int tam = 0;

        do{
            String caractere = JOptionPane.showInputDialog("Digite uma String");
            pilha.conversaoString_Char(caractere);
            System.out.print(LerPilhaChar(pilha));

            resp = JOptionPane.showConfirmDialog(null, "Cadastrar outro?");
            tam += caractere.length();

        } while (resp == 0 && tam < pilha.elementos.length);

    }

    public static String LerPilhaChar (Ado_Pilha pilha){
        String s = "";
        while(pilha.topo > -1){
            s += pilha.pop();
        }
        return s;
    }
}
