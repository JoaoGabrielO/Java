package POO_Java.Senac.ADO_Pilha;

import javax.swing.*;

public class Ado_Pilha {

    public int tam = Integer.parseInt(
            JOptionPane.showInputDialog("Digite o tamanho da Pilha")); //vetor da pilha de caracteres

    char[] elementos = new char[tam];
    int topo = -1; //variavel com o topo da pilha, inicialmente a pilha esta vazia
    public void push(char c){
        topo++; //sobe o topo
        elementos[topo] = c; //insere o elemento no topo
    }

    public char pop(){
        char c = elementos[topo];
        topo--;
        return c;
    }
    public void conversaoString_Char(String nome){
        for(int i = 0; i < nome.length(); i++){
            push(nome.charAt(i));
        }
    }
}
