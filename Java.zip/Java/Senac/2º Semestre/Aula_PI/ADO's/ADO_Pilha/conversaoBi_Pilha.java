package POO_Java.Senac.ADO_Pilha;

public class conversaoBi_Pilha {
    static int topo = -1;

    public static void conversorBinario(int numero, int vetor[]) {
        int i = vetor.length -1;
        int j = i;
        while(numero != 0){
            if (numero % 2 == 0) {
                push(0, vetor);
            } else {
                push(1, vetor);
            }
            numero /= 2;
            i--;
            j--;
            if(i == -1){
                i = 0;
            }
            if(j == -2){
                return;
            }
        }
    }
        public static void push(int c, int vetor[]){
            topo++; //sobe o topo
            vetor[topo] = c; //insere o elemento no topo
        }

        public static int pop(int vetor[]) {
            int c = vetor[topo];
            topo--;
            return c;

    }
    public static void LerPilha(int vetor[]){
        for(int item: vetor){
            System.out.print("\t" + pop(vetor));
        }
    }
}
