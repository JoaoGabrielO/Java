package POO_Java.Senac.ADO_Pilha;

import POO_Java.Senac.ADO_Pilha.conversaoBi_Pilha;

import java.util.Scanner;

public class conversaoBinaria {
    static conversaoBi_Pilha pilha = new conversaoBi_Pilha();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int qtd = 0;

        System.out.println("Digite um número inteiro:");
        int numero = sc.nextInt();
        int numero2 = numero;

        do {
            numero2 = numero2 / 2;
            qtd++;
        } while (numero2 != 0);


        int elementos[] = new int[qtd];

        System.out.println("O correspondente binario deste numero e:");
        pilha.conversorBinario(numero, elementos);
        pilha.LerPilha(elementos);


    }
}
