package Facul_Tads.Aula_PI;

import java.util.Scanner;

public class ADO_7 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int cont0 = 0, cont1 = 0, cont2 = 0, cont3 = 0, cont4 = 0, resp = 0;
        int random;

        String vetor[] = {"[A] Algoritmos ", "[B] Fundamentos Adm ", "[C] Conceitos de computação ", "[D] Pts ", "[E] Matematica "};

        for (int i = 0; resp != 2; ++i) {
            System.out.println("\nQual a disciplina de segunda-feira? ");
            sc.reset();

            for (int j = 0; j < 100; ++j) {
                random = (int) (Math.random() * 5);

                if (vetor[random] != vetor[random +1]) {
                    System.out.println(vetor[random]);
                }

               /* if (vetor[random] == vetor[0]) {
                    cont0 = 1;

                } else if (vetor[random] == vetor[1]) {
                    cont1 = 1;

                } else if (vetor[random] == vetor[2]) {
                    cont2 = 1;

                } else if (vetor[random] == vetor[3]) {
                    cont3 = 1;

                } else if (vetor[random] == vetor[4]) {
                    cont4 = 1;
                }
                if (cont0 == 1 && cont1 == 1 && cont2 == 1 && cont3 == 1 && cont4 == 1){
                    System.out.println(vetor[random]);

               */
                sc.reset();

            }
            String N = sc.next();

            switch (N) {

                case "A":
                case "a":
                    resp = 2;
                    System.out.println("Resposta correta ");

                    break;

                case "B":
                case "b":
                    System.out.println("Resposta errada ");

                case "C":
                case "c":
                    System.out.println("Resposta errada ");

                case "D":
                case "d":
                    System.out.println("Resposta errada ");

                case "E":
                case "e":
                    System.out.println("Resposta errada ");

            }
        }
    }
}