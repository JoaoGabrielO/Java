import javax.swing.JOptionPane;
    public class OrdenaParInsercao {
        public static void main(String[] args) {
            int tam = Integer.parseInt(JOptionPane.showInputDialog(
                    "Digite o tamanho do vetor:"));
            int vetor[] = new int[tam];
            for(int i=0 ; i<vetor.length ; i++)		{
                vetor[i] = (int)(Math.random()*20);
            }
            System.out.println("Antes da ordenação:");
            for(int i=0 ; i<vetor.length ; i++)		{
                System.out.print(vetor[i] + " ");
            }
            ordenarPorInsercao(vetor);
            System.out.println("\nAgora os pares primeiro:");
            for(int i=0 ; i<vetor.length ; i++)		{
                System.out.print(vetor[i] + " ");
            }
        }
        public static void ordenarPorInsercao (int [] v) {
            for (int i = 1; i < v.length; i++){
                int j = i;
                int x = v[j];
                while (j > 0 && (v[j-1]%2==1)) {
                    v[j] = v[j-1];
                    j--;
                }
                v[j] = x;
            }

        }
    }

