
import java.util.Scanner;
import javax.swing.JOptionPane;
public class OrdenarPorInsercao {
    public static void main(String[] args) {
        int vetor[] = {3, 5, 7, 9, 11, 15, 17, 19, 6};
        System.out.println("Antes da ordenação:");
        imprimirVetor(vetor);

        ordenarPorInsercao(vetor);
        System.out.println("\nDepois da ordenação:");
        imprimirVetor(vetor);
    }

    public static void ordenarPorInsercao (int [] v) {
        int contaPassos = 0;
        for (int i = 1; i < v.length; i++){
            int j = i;
            int x = v[j];
            while (j > 0 && x < v[j-1]) {
                v[j] = v[j-1];
                j--;
                contaPassos++;
            }
            v[j] = x;
        }
        System.out.println("Passos: " + contaPassos);
    }

    private static void imprimirVetor(int[] vetor) {
        for(int i=0 ; i<vetor.length ; i++)		{
            System.out.print(vetor[i] + " ");
        }
    }
}

