import java.util.Scanner;

public class ex02 {
        static int[] ordenacao(int vetor[]) {
            int aux = 0;
            for (int i = 0; i < vetor.length; i++) {
                for (int j = 0 + i; j < vetor.length; j++) {
                    if (vetor[i] % 2 == 1) {
                        aux = vetor[i];
                        vetor[i] = vetor[j];
                        vetor[j] = aux;
                    }
                }
            }
            return vetor;
        }
        public static int[] numero(int []vetor, int numero){
            int cont = 0;
            for(int i = 0; i < vetor.length; i++){
                if(numero == vetor[i]){
                    cont = 1;
                    System.out.println("Número encontrado na posição: " + (i +1));
                }
            }
            if(cont != 1){
                System.out.println("Número não encontrado !");
            }

            return vetor;
        }
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Digite um número: ");
            int numero = sc.nextInt();
            int vetor[] = {2, 0, 3, 5, 1, 9};
            int aux = 0;


            for (int i = 0; i < vetor.length; i++) {
                for (int j = i + 1; j < vetor.length; j++) {
                    if (vetor[i] % 2 == 0) {
                        if (vetor[i] > vetor[j]) {
                            aux = vetor[i];
                            vetor[i] = vetor[j];
                            vetor[j] = aux;
                        }
                    }
                    if (vetor[i] % 2 == 1) {
                        if (vetor[i] < vetor[j]) {
                            aux = vetor[i];
                            vetor[i] = vetor[j];
                            vetor[j] = aux;
                        }
                    }
                }
            }

            vetor = ordenacao(vetor);
            numero(vetor, numero);
            System.out.println("Vetor ordenado:");
            for (int elemento : vetor) {
                System.out.printf("\t" + elemento);

        }
    }
}

