import java.util.Scanner;

public class Vetor_Random_Foreach {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o número que deseja procurar no vetor: ");
        int numero = sc.nextInt();
        System.out.println("Digite o tamanho que deseja para o vetor");
        int qtd = sc.nextInt();
        int cont = 0;

        int vetor[] = new int[qtd];

        for(int i = 0; i < vetor.length; i++){ //ATRIBUINDO A CADA POSIÇÃO DO VETOR UM NÚMERO ALEATÓRIO
            vetor[i] = (int)(Math.random() * 100);

        }
        for (int num : vetor){ //PERCORRENDO VETOR COM FOREACH PARA VERIFICAR SE HÁ O NÚMERO NO VETOR
            if(num == numero){
                cont = 1; //SE O NÚMERO FOR ENCONTRADO O CONT VALERÁ 1
            }
        }
        if(cont >= 1){
            System.out.println("Número localizado no vetor !!"); //SE O CONT FOR 1 OU MAIOR ELE IRÁ IMRPIMIR A MENSAGEM (PARA QUE ELE NÃO IMPRIMIR A MENSAGEM VARIAS VEZES DENTRO DO FOR
        }
        for(int i = 0; i < vetor.length; i++){
            System.out.print(vetor[i] + "\t");
        }
    }
}
