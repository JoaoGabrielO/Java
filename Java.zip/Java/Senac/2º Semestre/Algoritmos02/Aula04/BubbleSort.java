import java.util.Scanner;

public class BubbleSort {
    static Scanner sc = new Scanner(System.in);
    public static int[] BubbleSort (int[] vetor) {
        int aux = 0;
        //Fase de Ordenação
        for (int i = 0; (i < (vetor.length - 1)); i++) {
            for (int j = 0; (j < (vetor.length - i - 1)); j++) {
                //Troca dos elementos
                if (vetor[j] > vetor[j + 1]) {
                    aux = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = aux;
                }
            }
        }
        return vetor;
    }
}


