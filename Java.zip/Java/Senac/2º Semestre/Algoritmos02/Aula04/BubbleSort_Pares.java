import java.util.Scanner;

public class BubbleSort_Pares {
    public static int[] BubbleSort(int[] vetor) {
        int aux = 0;

        for(int i = 0; i < vetor.length -1; i++){
            for(int j = 0; j < vetor.length -1; j++){
                if(vetor[j] > vetor[j +1]) {
                    aux = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = aux;
                }
            }
        }
        for(int i = 0; i < vetor.length -1; i++) {
            for (int j = 0; j < vetor.length - 1; j++) {
                if (vetor[j] % 2 == 1) {
                    aux = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = aux;

                }
            }
        }
        return vetor;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o tamanho que deseja para  o vetor: ");
        int qtd = sc.nextInt();

        int vetor[] = new int[qtd];

        for(int i = 0; i < vetor.length; i++){
            vetor[i] = (int)(Math.random() *20);
        }
        vetor = BubbleSort(vetor);

        for(int i = 0; i < vetor.length; i++){
            System.out.print(vetor[i] + "\t");
        }
    }
}


