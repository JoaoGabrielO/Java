public class ExercicioMergeSort {
    private int vetor[];
    private int length;
    private int[] aux;

    public void ordenar(int vetorEntrada[]) {
        this.vetor = vetorEntrada;
        this.length = vetorEntrada.length;
        this.aux = new int[length];
        mergeSort(0, length - 1);
    }

    private void mergeSort(int menorIndice, int maiorIndice) {
        if (menorIndice < maiorIndice) {
            int meio = menorIndice + (maiorIndice - menorIndice) / 2;
            mergeSort(menorIndice, meio);//ordena lado esquerdo
            mergeSort(meio + 1, maiorIndice);//ordena lado direito
            intercala(menorIndice, meio, maiorIndice);//Intercala ambos lados
        }
    }

    private void intercala(int menorIndice, int meio, int maiorIndice) {
        for (int i = menorIndice; i <= maiorIndice; i++) {
            aux[i] = vetor[i];
        }
        int i = menorIndice;
        int j = meio + 1;
        int k = menorIndice;
        while (i <= meio && j <= maiorIndice) {
            if (aux[i] < aux[j]) {
                vetor[k] = aux[i];
                i++;
            } else {
                vetor[k] = aux[j];
                j++;
            }
            k++;
        }
        while (i <= meio) {
            vetor[k] = aux[i];
            k++;
            i++;
        }
    }

    private static void imprimirVetor(int[] vetor) {
        for (int i = 0; i < vetor.length; i++) {
            System.out.print(vetor[i]);
            if(i != vetor.length-1){
                System.out.print(", ");
            }
        }
        System.out.println("\n");
    }
}
