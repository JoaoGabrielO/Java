import java.util.Scanner;

public class Ex_07_Quadrado_Magico {
    public static boolean qua(int [][] matriz){
        int soma = 0, soma2;

        //SOMAR PRIMEIRA LINHA
        for(int l = 0; l < matriz[0].length; l++) {
            soma += matriz[0][l];
        }
        //SOMAR PROXIMAS LINHAS
            for(int l = 1; l < matriz.length; l++){
                soma2 = 0;
                for(int c = 0; c < matriz[l].length; c++){
                    soma2 += matriz[l][c];
                }
                if(soma2 != soma){
                    return false;
                }
        }
            //SOMAR COLUNAS
        for(int c = 0; c < matriz.length; c++){
            soma2 = 0;
            for(int l = 0; l < matriz.length; l++){
                soma2 += matriz[l][c];
            }
            if(soma2 != soma){
                return false;
            }
        }
        //SOMAR DIAGONAL PRINCIPAL
        soma2 = 0;
        for(int l = 0; l < matriz.length; l++){
            soma2 += matriz[l][l];
        }
        if(soma2 != soma){
            return false;
        }
        //SOMAR DIAGONAL SECUNDARIA
        soma2 = 0;
        int l = 0;
        for(int c = matriz.length -1 ; c >= 0; c--){
            soma2 += matriz[l][c];
            l++;

        }
        if(soma2 != soma){
            return false;
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int matriz [][] = new int [3][3];

        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                System.out.println("Digite o " + (c +1) + " elemento da " + (l +1) + " linha da matriz");
                matriz[l][c] = sc.nextInt();
            }
        }
        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                System.out.print(matriz[l][c] + " \t");
            }
            System.out.println("");
        }
        if(qua(matriz)){
            System.out.println("É um quadrado magico");
        }else{
            System.out.println("Não é um quadrado magico");
        }
    }
}
