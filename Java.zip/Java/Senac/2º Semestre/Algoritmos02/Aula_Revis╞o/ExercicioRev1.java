import javax.swing.JOptionPane;
    public class ExercicioRev1 {
        public static void main(String[] args) {
            int qtd = Integer.parseInt(JOptionPane.showInputDialog
                    ("Digite o tamanho do vetor:"));
            int vetor[] = new int[qtd];
            int localizou = -1;
            //preenchendo o vetor  com números de 0 a vinte
            for(int i=0 ; i<vetor.length ; i++)		{
                vetor[i] = (int)(Math.random()*20);
                System.out.print(vetor[i] + " ");
            }
            int num=Integer.parseInt(JOptionPane.showInputDialog
                    ("Digite o número a pesquisar:"));;
            for(int i=0 ; i<vetor.length ; i++)		{
                if(num==vetor[i])			{
                    localizou =i;
                    break;
                }
            }

            if(localizou != -1)
            {
                System.out.print("\nNúmero localizado no índice: " + localizou);
            }
            else
                System.out.print("\nNúmero não localizado no vetor!!!");
        }
    }

