import java.util.Scanner;

public class vetor_soma30 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int vetor[] = new int[8];
        int cont = 0;
        int soma30 = 0;
        int soma = 0;

        for(int i = 0; i < vetor.length; i++){
            System.out.println("Digite o " + (i +1) + "° elemento do vetor");
            vetor[i] = sc.nextInt();
            if(vetor[i] > 30){
                cont ++;
                soma30 += vetor[i];
            }
            soma += vetor[i];
        }
        System.out.println(cont + " são maiores que 30");
        System.out.println("A soma dos valores maiores que 30 é: " + soma30);
        System.out.println("A soma de todos os elementos no vetor é: " + soma);
    }
}
