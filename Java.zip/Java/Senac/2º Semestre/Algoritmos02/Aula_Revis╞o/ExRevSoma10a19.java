import javax.swing.JOptionPane;
    public class ExRevSoma10a19 {
        public static void main(String[] args) {
            int vetor[] = new int[8];
            int somaTudo=0, somaMaior30=0;
            for(int i=0 ; i<vetor.length ; i++)		{
                vetor[i] = (int)(Math.random()*100);
                somaTudo += vetor[i];
                if(vetor[i] > 30)
                    somaMaior30 += vetor[i];
                System.out.print(vetor[i] + " ");
            }
            System.out.print("\nA soma de todos os números = " + somaTudo);
            System.out.print("\nA soma dos > 30 = " + somaMaior30);
        }
    }

