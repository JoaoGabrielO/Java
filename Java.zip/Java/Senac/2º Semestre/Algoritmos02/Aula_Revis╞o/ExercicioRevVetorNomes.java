import javax.swing.JOptionPane;
public class ExercicioRevVetorNomes {
    public static void main(String[] args) {String vetor[] = new String[3];
        for(int i=0 ; i<vetor.length ; i++)		{
            do {
                vetor[i] = JOptionPane.showInputDialog
                            ("Digite um nome com no máximo 20 letras:");
                if(vetor[i].length() > 20){
                    JOptionPane.showMessageDialog(null,"Esse nome tem mais de 20 caracteres, escreva outro");
                }
            }while(vetor[i].length()>20);
                System.out.println(vetor[i] + " ");
        }
    }
}

