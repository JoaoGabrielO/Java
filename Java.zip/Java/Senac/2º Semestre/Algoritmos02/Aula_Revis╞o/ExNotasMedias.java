import javax.swing.JOptionPane;
    public class ExNotasMedias {
        static int menor = Integer.MAX_VALUE;
        public static void main(String[] args) {
            int tam = Integer.parseInt(JOptionPane.showInputDialog
                    ("Digite o tamanho do vetor:"));
            int vetor[] = new int[tam];
            preencherVetor(vetor);//preenche o vetor
            imprimirVetor(vetor);//imprime o vetro
            System.out.println();
            System.out.println(contarMultiplos5(vetor) +
                    " números são múltiplos de 5.");
            System.out.println(obterMenorNumero(vetor) +
                    " é o menor número do vetor.");
        }
        private static int obterMenorNumero(int[] vetor) {
            for(int i=0 ; i<vetor.length ; i++)		{
                if(vetor[i] < menor)
                    menor = vetor[i];
            }
            return menor;
        }

        private static int contarMultiplos5(int[] vetor) {
            int total=0;
            for(int i=0 ; i<vetor.length ; i++)		{
                if(vetor[i]%5 == 0)
                    total++;
            }
            return total;
        }

        private static void imprimirVetor(int[] vetor) {
            for(int i=0 ; i<vetor.length ; i++)
                System.out.print(vetor[i] + " ");
        }

        private static int[] preencherVetor(int[] vetor) {
            for(int i=0 ; i<vetor.length ; i++)		{
                vetor[i] = (int)(Math.random()*50);
            }
            return vetor;
        }
    }



