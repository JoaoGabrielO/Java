package Java_Inicial.Senac;

import javax.swing.*;

public class Busca_Binaria {
    private static int buscaBinaria(int[] v, int n) {
        int i, m, f;
        i = 0;
        f = v.length-1;
        System.out.println(f);

        while (i <= f)
        {
            m = (i + f) / 2;
            if (v[m] == n)
                return m;
            if (n < v[m]) // esquerda
                f = m - 1;
            else // x > v[m] - direita
                i = m + 1;
        }
        return -1;
    }
        public static void main(String[] args) {
            int vetor[] = new int[100];
            int min = 0;
            int max = 100;
            int range = max - min + 1;
            int aux;
            boolean controle;

        for(int i = 0; i < vetor.length; i++){
            int random = (int)(Math.random() * range) + min;
            vetor[i] = random;
        }

        for(int i =0; i < vetor.length; ++i) {
            controle = true;
            for (int j = 0; j < (vetor.length -1); ++j) {
                if (vetor[j] > vetor[j +1]) {
                    aux = vetor[j];
                    vetor[j] = vetor[j +1];
                    vetor[j +1] = aux;
                    controle = false;
                }
            }
            if (controle) {
                break;
            }
        }
        for(int i = 0; i < vetor.length; i++){
            System.out.println(vetor[i]);

        }
            int n = Integer.parseInt(JOptionPane.showInputDialog(
                    "Digite o número a ser localizado"));
            int valor = buscaBinaria(vetor, n);

            if(valor==-1)
                System.out.println("Número não encontrado no vetor!!!: ");
            else
                System.out.println("Número encontrado no índice: " + valor );
        }
}


