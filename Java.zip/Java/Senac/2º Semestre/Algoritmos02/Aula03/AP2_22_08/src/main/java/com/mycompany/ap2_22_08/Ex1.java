/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ap2_22_08;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author lucas.rmuraoka
 */
public class Ex1 {

    
    // FIlereader
    public static void main(String[] args) throws IOException {
        FileReader arquivo = null;
        try{
            arquivo = new FileReader("nota.txt");
        }
        catch (FileNotFoundException e){
            System.out.println("Arquivo não encontrado!!!");
        }
            BufferedReader leBufferizado = new BufferedReader(arquivo);
            String linha = "";
            linha = leBufferizado.readLine();
            System.out.println(linha);
            leBufferizado.close();
            arquivo.close();
    }
}
