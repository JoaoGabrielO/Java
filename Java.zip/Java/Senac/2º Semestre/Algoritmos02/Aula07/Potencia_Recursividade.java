import java.util.Scanner;

public class Potencia_Recursividade {
    public static int potencia (int base, int expoente){
        if(expoente == 0){
            return 1;
        } else if (expoente == 1){
            return base;
        } else{
            return base * potencia(base, expoente -1);
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a base:");
        int base = sc.nextInt();
        System.out.println("Digite o expoente:");
        int expoente = sc.nextInt();

        System.out.println(potencia(base, expoente));

    }
}
