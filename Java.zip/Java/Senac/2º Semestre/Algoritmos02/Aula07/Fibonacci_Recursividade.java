import java.util.Scanner;

public class Fibonacci_Recursividade {
    public static int Fibonacci(int num){

        if(num == 0 ){
            return 0;

        } else if(num == 1) {
            return 1;

        }else {
            return (Fibonacci(num - 1)) + (Fibonacci(num - 2));
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o número para a sequencia de Fibonacci:");
        int num = sc.nextInt();

        for(int i = 0; i <= num; i++){
            System.out.println(Fibonacci(i));

        }
    }
}
