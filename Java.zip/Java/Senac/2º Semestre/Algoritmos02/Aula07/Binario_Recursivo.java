import javax.swing.*;

public class Binario_Recursivo {
    public static void main(String[] args) {
        int num = Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
        System.out.println(gerarBinario(num)+ "");
    }
    public static int gerarBinario(int num){
        int binario;
        if (num == 0){
            return 0;
        } else{
            return(binario = num %2 + 10 * (gerarBinario(num /2)));
        }
    }
}
