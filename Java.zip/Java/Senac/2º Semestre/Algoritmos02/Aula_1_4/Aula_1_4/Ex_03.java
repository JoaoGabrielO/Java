package Aula_1_4;

public class Ex_03 {
    public static int[][] mat(){
        int matriz[][] = new int[4][4];
        int traco = 0;

        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                matriz[l][c] = c;
                if(l == c) {
                    traco += matriz[l][l];
                }
            }
        }
        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                System.out.print(matriz[l][c] + "\t");
            }
            System.out.println("");
        }
        System.out.println("Traço:" + traco);
        return matriz;
    }
    public static void main(String[] args) {
        mat();

    }
}
