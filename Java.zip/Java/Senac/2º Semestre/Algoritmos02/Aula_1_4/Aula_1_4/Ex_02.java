package Aula_1_4;

import java.util.Scanner;

public class Ex_02 {
    public static int[][] mat(int lin, int col){

        int matriz[][] = new int[lin][col];
        int maior = Integer.MIN_VALUE;

        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                matriz[l][c] = c;
                if(maior < c){
                    maior = c;
                }
            }
        }
        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                System.out.print(matriz[l][c] + "\t");
            }
            System.out.println("");
        }

        System.out.println("Maior número: " + maior );
        return matriz;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        mat(5, 5);
    }
}
