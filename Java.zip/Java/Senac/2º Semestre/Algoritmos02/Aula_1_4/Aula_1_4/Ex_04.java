package Aula_1_4;

public class Ex_04 {
    public static boolean sim(int lin, int col){
        int matriz[][] = new int[lin][col];
        int contL = 0;
        int contC = 0;

        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                matriz[l][c] = c;
                    contC += 1;
            }
            contL += 1;
            System.out.println(contC + " L " + contL);
        }
        for(int l = 0; l < matriz.length; l++){
            for(int c = 0; c < matriz[l].length; c++){
                System.out.print(matriz[l][c] + "\t");

            }
            System.out.println("");
        }
        if(contC /contL == contL){
            System.out.println("A matriz é simétrica ?");
            return true;
        }
        return false;
    }
    public static void main(String[] args) {
        System.out.println(sim(2,6));
    }
}
