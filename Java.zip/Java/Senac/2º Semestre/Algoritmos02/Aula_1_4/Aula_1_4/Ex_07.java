package Java_Inicial.Senac;

public class Ex_07 {
    public static boolean sim(){

        int[][] matriz = {{8, 0, 7,
                           4, 5, 6,
                           3, 10, 2 }};
    int somaD1 = 0;
    int somaD2 = 0;
    int somaL = 0;
    int somaC[] = new int[3];
    int somaC2 = 0;

        for(int l = 0; l < matriz.length -1; l++){
        for(int c = 0; c < matriz[l].length -1; c++){

            if(l >= 0){
                somaL += matriz[l][c];
            }
            somaC[l] += matriz[c][l];
            if(l == c) {
                somaD1 += matriz[l][l];
            }
        }
    }
        for(int i = 0; i < somaC.length; i++){
            System.out.println(somaC[i]);
        }
        System.out.println(somaC2);
        for(int l = 0; l < matriz.length; l++){
        for(int c = 0; c < matriz[l].length; c++){
            System.out.print(matriz[l][c] + "\t");
        }
        System.out.println(" ");
    }

        return false;
}
    public static void main(String[] args) {
        sim();

    }
}
