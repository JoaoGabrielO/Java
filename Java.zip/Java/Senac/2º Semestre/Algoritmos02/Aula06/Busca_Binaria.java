import java.util.Scanner;

public class Busca_Binaria {
    static Scanner sc = new Scanner (System.in);

    static int buscabinaria(int vetor[], int parametro){
        int inicio, meio, fim;
        inicio = 0;
        fim = vetor.length-1;
        System.out.println();
        System.out.println("Posições do Vetor: " + (fim +1));
        while (inicio <= fim){
            meio = (inicio + fim) / 2;
            if (vetor[meio] == parametro)
                return meio;
            if (parametro < vetor[meio]) //esquerda
                fim = meio - 1;
            else // x > vetor[m] - direita
                inicio = meio + 1;
        }
        return -1;
    }

    public static void main (String [] args) {
        System.out.println("\nInsira o tamanho do Vetor");
        int quant = sc.nextInt();

        System.out.println("\nInsira o número para ser verificado");
        int parametro = sc.nextInt();

        int vetor[] = new int [quant];

        System.out.println("\n------VETOR------");

        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Informe o " + (i + 1) + "º numero: ");
            vetor[i] = sc.nextInt();
        }

        for (int i = 0; i < vetor.length; i++) {
            for (int j = 0 + i; j < vetor.length; j++){
                int aux = 0;
                if (vetor[i] > vetor[j]){
                    aux = vetor[i];
                    vetor[i] = vetor[j];
                    vetor[j] = aux;
                }
            }
        }

        System.out.println("\n------VETOR------");

        for (int i = 0; i < vetor.length; i++){
            System.out.printf(vetor[i]+"\t");
        }

        System.out.println();

        int valor = buscabinaria(vetor,parametro);

        System.out.println();

        if (valor == -1){
            System.out.println("Número não encontrado no vetor!");
        } else {
            System.out.println("Número encontrado no índice: " + (valor + 1));

        }
    }
}


