import javax.swing.*;

public class funcao_recursiva {
    public static void main(String[] args) {
        int base = Integer.parseInt(JOptionPane.showInputDialog(
                "Digite a  base: "));
        int expoente = Integer.parseInt(JOptionPane.showInputDialog(
                "Digite o expoente: "));

        System.out.println(base + " elevado a  " + expoente  + " = " +
                fatorial(base, expoente));
    }
    public static int fatorial(int num, int  e) {
        if(e == 1)
            return num;
        else return num * fatorial(num, e -1);



    }
}
