import javax.swing.*;

public class fatorial_recursao {
    public static void main(String[] args) {
        int num = Integer.parseInt(JOptionPane.showInputDialog("Digite um número: "));

        System.out.println("Fatorial: " + fatorial(num));
    }
    public static int fatorial(int n){

        if (n == 0){
            return 1;
        }else{
            return n * fatorial(n -1);
        }
    }
}
