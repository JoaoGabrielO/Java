import javax.swing.*;

public class Recursividade {
    public static void imprimirSequencia(int n) {
        if (n == 0) //BASE DA RECURSÃO (condição parada)
            return;
            System.out.print(n + " ");
            imprimirSequencia(n - 1);//CHAMADA RECURSIVA

    }
    public static void main(String[] args) {
        imprimirSequencia(Integer.parseInt(JOptionPane.showInputDialog("Digite um número maior que 0")));
    }
}

