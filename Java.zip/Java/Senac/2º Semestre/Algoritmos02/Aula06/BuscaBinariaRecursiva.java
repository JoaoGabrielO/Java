import java.util.Scanner;
import javax.swing.JOptionPane;
    public class BuscaBinariaRecursiva {
        public static void main(String[] args) {
            int vetor[] = { 10, 45, 5, 7, 9, 1, 34 ,2 ,88};
            int num = Integer.parseInt(JOptionPane.showInputDialog(
                    "Digite o número a ser localizado"));
            int i = 0;
            int f = vetor.length-1;

            ordenar_vetor(vetor);
            System.out.println("---------------  VETOR ORDENADO  --------------- ");
            for (int item:
                 vetor) {
                System.out.print(item + "\t");

            }
            int valor = buscaBinaria(vetor, num,  i ,  f);

            if(valor==-1)
                System.out.println("\n Número não encontrado no vetor!!! ");
            else
                System.out.println("\n Número encontrado no índice: " + valor );
        }
        public static int []ordenar_vetor(int vetor[]){
            int aux = 0;

            for(int i = 0; i < vetor.length -1; i++){
                for(int j = 0; j < vetor.length -1; j++){
                    if(vetor[j] > vetor[j +1]){
                        aux = vetor[j];
                        vetor[j] = vetor[j +1];
                        vetor[j +1]= aux;

                    }
                }
            }
            return vetor;
        }
        public static int buscaBinaria(int[] vetor, int n, int i, int f) {
            int m;
            m = (i + f) / 2;

            if (i > f)
                return -1;

           if (vetor[m] < n) {
                return buscaBinaria(vetor, n, m +1, f);

            }else if (vetor[m] > n) {
                return buscaBinaria(vetor, n, m -1, f -1);

            }else {
               return m;
           }
        }
    }