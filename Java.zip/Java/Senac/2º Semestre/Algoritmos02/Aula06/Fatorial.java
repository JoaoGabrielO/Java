import javax.swing.*;

public class Fatorial {
        public static void main(String[] args) {
            int num = Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));

            System.out.println("Fatorial de " + num + " = " + fatorial(num));
        }

        public static int fatorial(int n){
            int fatorial = 1;
            for(int termo = 1; termo <= n; termo++){
                fatorial = fatorial * termo;
            }
            return fatorial;
        }
}
