package POO;

import javax.swing.*;

public class Atividade01{
    public static void main(String[] args) {

        int quant = Integer.parseInt(JOptionPane.showInputDialog("Digite quantas contas deseja cadastrar: "));
        Banco banco[] = new Banco[quant];



        for(int i = 0; i < banco.length; i++) {
            int agencia = Integer.parseInt(JOptionPane.showInputDialog("Agência: "));
            int conta = Integer.parseInt(JOptionPane.showInputDialog("Conta: "));
            int saldo = Integer.parseInt(JOptionPane.showInputDialog("Saldo: "));
            Banco banco1 = new Banco(agencia, conta, saldo);
            banco[i] = banco1;
        }

        for(int i = 0; i < banco.length; i++){
            JOptionPane.showMessageDialog(null,banco[i].extratoConta());
        }
    }
}
