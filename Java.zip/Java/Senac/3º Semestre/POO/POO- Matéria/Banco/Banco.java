package POO;

public class Banco {
    private int agencia, conta;
    private double saldo;

    public Banco(int agencia, int conta, double saldo){
        this.agencia = agencia;
        this.conta = conta;
        this.saldo = saldo;
    }
    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public int getConta() {
        return conta;
    }

    public void setConta(int conta) {
        this.conta = conta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }


    public String extratoConta() {
        return "Banco{ \n" +
                "agencia=" + agencia +
                " \nconta=" + conta +
                " \nsaldo=" + saldo + "\n" +
                '}';
    }
}
