package Senac.POO.ADO01Encapsulamento;

public class BancoDeDados {
    final String senha = "1234";
    final String nome = "Joao";
    public BancoDeDados() {

    }
    public String getNome() {
        return nome;
    }
    public String getSenha() {
        return senha;
    }
}
