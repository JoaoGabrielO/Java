package Senac.POO.ADO01Encapsulamento;

import javax.swing.*;

public class CorrentistaNivel02 {
    public CorrentistaNivel02() {
        int i = 0;

        while (i == 0) {

            int escolha = Integer.parseInt(JOptionPane.showInputDialog(
                    "Hierarquia de nivel 2" +
                    "\nEssas são suas ações: " +
                    "\n[1] Fazer Transferencia: \t" +
                    "         [2] Resgatar quantia: \t" +
                    "\n[3] Fechar Conta: \t" +
                    "                      [4] Abrir Conta: \t" +
                    "\n[5] Voltando ao inicio do sistema..."));
            switch (escolha) {
                case 1:
                    TransferirValor();
                    break;

                case 2:
                    ResgatarQuantia();
                    break;

                case 3:
                    FecharConta();
                    break;

                case 4:
                    AbrirConta();
                    break;

                case 5:
                    JOptionPane.showMessageDialog(null,"Saindo do sistema...");
                    i = 0;
                    return;
            }
        }
    }

    public void ResgatarQuantia(){
        JOptionPane.showMessageDialog(null,"Resgatando quantia...");
    }
    public void TransferirValor(){
        JOptionPane.showMessageDialog(null,"Transferindo valor...");
    }
    public void FecharConta(){
        JOptionPane.showMessageDialog(null,"Fechando conta...");
    }
    public void AbrirConta(){
        JOptionPane.showMessageDialog(null,"Abrindo conta...");
    }

}
