package Senac.POO.ADO01Encapsulamento;

import javax.swing.*;

public class Login {
    BancoDeDados bd = new BancoDeDados(); // Instanciando um objeto  da classe Banco de dados. Ela está com o username e senha corretos para entrada no sistema.
    Tela tela = new Tela(); // Chamando a classe tela que está com a interface que irá solicitar ao cliente os dados de entrada no sistema.
    //Obs: Ela irá iniciar automaticamente pois seus processos estão dentro do construtor.

    public Login() {
        int i = 4;
        while(equals(tela) || i > 1) { // O loop irá se repetir até que a comparação retorne uma resposta positiva(os obejtos comparados são iguais OU
            // O i seja menor do que 1 (que representa o número de tentativas incorretas)

        if(equals(tela)){ // Fazendo a comparação dos dados Recolhidos do Banco de Dados com os dados digitados pelo cliente.
            // Através do método de comparação EQUALS sobrescrito.
            JOptionPane.showMessageDialog(null,"Entrada no sistema realizada com sucesso!!");
            JOptionPane.showMessageDialog(null,"Bem vindo correntista: " + tela.getNome());
            Hierarquia hierarquia = new Hierarquia(); // Chamando a classe hierarquia caso os dados sejam iguais.
            return;
        }
        else{ // Caso os dados sejam diferentes, serão mostradas as mensagens abaixo, e em seguida a opção de tentar de novo.
                JOptionPane.showMessageDialog(null, "Nome ou senha incorretos. Insira-os novamente:");
                JOptionPane.showMessageDialog(null, "Lhe restam mais " + (i -1) + " tentativas antes do bloqueio ao acesso!");
                tela.setNome(JOptionPane.showInputDialog("Digite seu nome de Correntista:"));
                tela.setSenha(JOptionPane.showInputDialog("Digite sua senha: "));


            }
            i--;
        if(i <= 1){
            JOptionPane.showMessageDialog(null,"Seu número de tentativas de acesso foi excedido e portanto sua conta foi bloqueada. ");
        }
        }
    }

    @Override
    public boolean equals(Object correntista){ // Comparando os atributos dos dois objetos instaciados através do método EQUALS sobrescrito.
        if(bd.getNome().equals(((Tela)correntista).getNome()) && bd.getSenha().equals(((Tela)correntista).getSenha()))
        {
            return true;
        }
        return false;
    }

}