package Senac.POO.ADO01Encapsulamento;

import javax.swing.*;

public class Hierarquia {
    public Hierarquia() { //Classe onde

        int i = 0;

        while (i == 0) {

            JOptionPane.showMessageDialog(null, "Você entrou com uma conta de correntista nivel 1");
            int escolha = Integer.parseInt(JOptionPane.showInputDialog("Essas são suas ações: " +
                    "\n[1] Fazer Transferencia: \t" +
                    "      [2] Resgatar quantia: \t" +
                    "\n[3] Mais opções: \t" +
                    "                    [4] Encerrar seção e sair do sistema..."));

            switch (escolha) {
                case 1:
                    JOptionPane.showMessageDialog(null, "Realizando tranferencia...");
                    break;

                case 2:
                    JOptionPane.showMessageDialog(null, "Resgatando quantia...");
                    break;

                case 3:
                    JOptionPane.showMessageDialog(null,"O seu nivel de acesso é 1. Para realizar mais acões insira credenciais de acesso superior." );
                    String senha = JOptionPane.showInputDialog("Senha de acesso: ");

                        if(senha.equalsIgnoreCase("12345")){
                            JOptionPane.showMessageDialog(null, "Credenciais corretas. Subindo de hierarquia... ");
                            CorrentistaNivel02 correntistaNivel02 = new CorrentistaNivel02();

                        } else if (senha.equalsIgnoreCase("56789")){
                            JOptionPane.showMessageDialog(null, "Credenciais corretas. Subindo de hierarquia... ");
                            CorrentistaNivel03 correntistaNivel03 = new CorrentistaNivel03();

                        }else{
                                JOptionPane.showMessageDialog(null, "Credenciais invalidas. Revise-as e tente de novo.");
                    }
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null,"Saindo do sistema...");
                    return;

                default:
                    JOptionPane.showMessageDialog(null,"Opção invalida, selecione outra.");
                    break;
            }
        }
    }
}
