package Senac.POO.ADO01Encapsulamento;

public class SistemaDeControle {
    public static void main(String[] args) {
        Login login = new Login(); // Instanciando a classe login que irá chamar tds as outras.
        //Obs: Ela irá se iniciar sozinha pois os métodos estão dentro do construtor.--


    }
}
