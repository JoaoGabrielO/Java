package POO.Heranca;

public class App {

    public static void main(String[] args) {
// TODO Auto-generated method stub
        String nome = "Joaquim Jose da Silva Xavier";
        Funcionariomensalista funcm = new Funcionariomensalista(nome);
    }

}