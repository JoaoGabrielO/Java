package POO.Heranca;

public class Funcionariomensalista extends Funcionario {
    public Funcionariomensalista (String nome) {
        super(nome);
        System.out.println("metodo construtor Funcionariomensalista");
    }
}