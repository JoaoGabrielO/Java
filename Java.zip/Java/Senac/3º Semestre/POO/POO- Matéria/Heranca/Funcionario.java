package POO.Heranca;
public class Funcionario {
    public String nome;
    private String depto;
    private String funcao;
    private String endereco;
    public Funcionario () {
        System.out.println("Chamou o metodo construtor Funcionario");
    }
    public Funcionario (String nome) {
        System.out.println("Bem vindo: "+nome);
    }
}