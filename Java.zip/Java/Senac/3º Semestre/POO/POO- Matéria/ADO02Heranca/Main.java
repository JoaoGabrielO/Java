package Senac.POO.ADO02Heranca;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
       Tela tela = new Tela();
    }

}
