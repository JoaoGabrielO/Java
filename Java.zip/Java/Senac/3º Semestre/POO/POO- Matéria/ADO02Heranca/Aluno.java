package Senac.POO.ADO02Heranca;

public class Aluno extends Pessoa{

    public Aluno(String nome, String funcao) {
        super(nome, funcao);
    }

    @Override
    public void mandaEmail() {
        super.mandaEmail();
        System.out.println(" solicita a sua presença na secretaria!");
    }
}
