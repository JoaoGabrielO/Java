package Senac.POO.ADO02Heranca;

public class Professor extends Pessoa {

    public Professor(String nome, String funcao) {
        super(nome, funcao);
    }

    @Override
    public void mandaEmail() {
        super.mandaEmail();
        System.out.println(" informa sobre o seu periodo de férias!!");

    }
}
