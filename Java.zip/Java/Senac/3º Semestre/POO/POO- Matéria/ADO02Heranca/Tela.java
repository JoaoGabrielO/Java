package Senac.POO.ADO02Heranca;

import java.util.Scanner;

public class Tela {
    public Tela() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Função: ");
        String funcao  = sc.next();
        System.out.println("Nome: ");
        String nome = sc.next();

        if(funcao.equalsIgnoreCase("aluno")){
            Aluno aluno = new Aluno(nome, funcao);
            aluno.mandaEmail();

        } else if (funcao.equalsIgnoreCase("professor")) {
            Pessoa pessoa = new Professor(nome,funcao);
            pessoa.mandaEmail();
        }else{
            Pessoa pessoa = new Funcionario(nome,funcao);
            pessoa.mandaEmail();
        }


    }
}
