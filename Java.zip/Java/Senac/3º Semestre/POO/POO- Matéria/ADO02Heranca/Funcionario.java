package Senac.POO.ADO02Heranca;

public class Funcionario extends Pessoa{
    public Funcionario(String nome, String funcao) {
        super(nome, funcao);

    }
    @Override
    public void mandaEmail() {
        super.mandaEmail();
        System.out.println(" o convoca para fazer um exame médico!");

    }
}
