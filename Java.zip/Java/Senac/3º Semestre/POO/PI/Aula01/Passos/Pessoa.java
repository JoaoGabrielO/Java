package Aula01.Passos;

import java.util.Scanner;

public class Pessoa {
    private String nome;
    private int idade, passos;


    public String getNome(){
        return this.nome;
    }
    public void setNome(String Nome){
        this.nome = Nome;
    }
    public int getIdade(){
        return this.idade;
    }
    public void setIdade(int Idade){
        this.idade = Idade;
    }

    public int getPassos() {
        return passos;
    }

    public void setPassos(int passos) {
        this.passos = passos;
    }

    public void andar(){
        Scanner sc = new Scanner(System.in);

        int Passos;
        System.out.println("Quantos passos desejar dar? ");
        Passos = sc.nextInt();
        setPassos(Passos);

    }
    public String dadosPessoa(){
        return "Pessoa={ " +
                "\n" +
                "Nome= " + this.nome + "\n" +
                "Idade= " + this.idade + "\n" +
                "Aula01.Passos Dados= " + this.passos + "\n" +
                "}";

    }
}
