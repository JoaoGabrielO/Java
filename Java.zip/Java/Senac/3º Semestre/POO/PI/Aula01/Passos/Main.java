package Aula01.Passos;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Pessoa p = new Pessoa();

        System.out.println("Digite seu nome: ");
        String nome = sc.next();
        p.setNome(nome);

        System.out.println("Digite sua idade: ");
        int idade = sc.nextInt();
        p.setIdade(idade);
        p.andar();

        System.out.println(p.dadosPessoa());

    }
}
