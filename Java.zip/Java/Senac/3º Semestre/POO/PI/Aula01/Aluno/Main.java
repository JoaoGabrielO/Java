package Aula01.Aluno;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Aluno a = new Aluno();

        System.out.println("Digite seu nome: ");
        String nome = sc.next();
        a.setNome(nome);
        System.out.println("Digite seu RA: ");
        String ra = sc.next();
        a.setRa(ra);
        System.out.println("Nota 1: ");
        float nota1 = sc.nextFloat();
        a.setNota1(nota1);
        System.out.println("Nota 2: ");
        float nota2 = sc.nextFloat();
        a.setNota2(nota2);

        System.out.println(a.imprimirDados());
    }
}