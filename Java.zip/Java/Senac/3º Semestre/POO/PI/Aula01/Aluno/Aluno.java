package Aula01.Aluno;

public class Aluno {
    private String nome, ra;
    private float nota1, nota2;

    public float getNota1(){
        return nota1;
    }
    public void setNota1(float nota1){
        this.nota1 = nota1;
    }
    public float getNota2(){
        return nota2;
    }
    public void setNota2(float nota2){
        this.nota2 = nota2;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }
    public float calcularMédia(float nota1, float nota2){
        return (nota1 + nota2) /2;
    }
    public String imprimirDados() {
        return "Aula01.Aula01.Passos.Aluno{" +
                "\n" +
                "Nome= " + nome + '\n' +
                " RA= " + ra + '\n' +
                "Nota 1= " + nota1 + '\n' +
                "Nota 2= " + nota2 + '\n' +
                "Média= " + calcularMédia(getNota1(), getNota2()) +
                "\n" +
                '}';
    }
}
