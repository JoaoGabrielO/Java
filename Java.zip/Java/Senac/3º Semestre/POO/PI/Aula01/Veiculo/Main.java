package Aula01.Veiculo;

public class Main {
    public static void main(String[] args) {
        Carro c = new Carro();

        c.ligar();
        c.setVelocidade(40);
        c.marchaAuto();
        System.out.println(c.toString());
    }
}
