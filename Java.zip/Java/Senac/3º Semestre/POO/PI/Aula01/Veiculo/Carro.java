package Aula01.Veiculo;

public class Carro {
    private String marca, modelo, anoFab, numChassi;
    private int marcha, velocidade;
    private boolean ligado;


    public void ligar(){
        this.ligado = true;
        System.out.println("Ligando carro!");
    }
    public void desligar(){
        this.ligado = false;
        System.out.println("Desligando carro!");
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        if(getLigado()){
            this.velocidade = velocidade;
        } else{
            System.out.println("Carro esta desligado");
            this.velocidade = 0;
        }

    }

    public int getMarcha() {
        return marcha;
    }

    public void setMarcha(int marcha) {
        this.marcha = marcha;
    }

    public boolean getLigado() {
        return ligado;
    }

    public void setLigado(boolean ligado) {
        this.ligado = ligado;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAnoFab() {
        return anoFab;
    }

    public void setAnoFab(String anoFab) {
        this.anoFab = anoFab;
    }

    public String getNumChassi() {
        return numChassi;
    }

    public void setNumChassi(String numChassi) {
        this.numChassi = numChassi;
    }

    public void marchaAuto(){
        if(getLigado()) {

            if (getVelocidade() < 11) {
                setMarcha(1);
            } else if (getVelocidade() < 21) {
                setMarcha(2);
            } else if (getVelocidade() < 41) {
                setMarcha(3);
            } else if (getVelocidade() < 61) {
                setMarcha(4);
            } else {
                setMarcha(5);
            }

        } else{
            System.out.println("Carro desligado!");
        }
    }

    @Override
    public String toString() {
        return "Carro{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", anoFab='" + anoFab + '\'' +
                ", numChassi='" + numChassi + '\'' +
                ", marcha=" + marcha +
                ", velocidade=" + velocidade +
                ", ligado=" + ligado +
                '}';
    }
}
