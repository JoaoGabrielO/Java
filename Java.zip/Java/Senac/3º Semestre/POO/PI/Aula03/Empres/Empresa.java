package PI.Empres;

import java.util.Arrays;

public class Empresa {
    private Departamento[] departamentos;
    private String nome;
    public Departamento[] getDepartamentos() {
        return departamentos;
    }
    public void setDepartamentos(Departamento[] departamentos) {
        this.departamentos = departamentos;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    @Override
    public String toString() {
        return "Empresa " + nome +
                "\nDepartamentos=" + Arrays.toString(departamentos);
    }
}

//Departamento.java
class Departamento{
    private Empresa empresa;
    private String nomeDepartamento;
    public String getNomeDepartamento() {
        return nomeDepartamento;
    }
    public void setNomeDepartamento(String nomeDepartamento) {
        this.nomeDepartamento = nomeDepartamento;
    }
    @Override
    public String toString() {
        return "Departamento " + nomeDepartamento + "]";
    }
    public Empresa getEmpresa() {
        return empresa;
    }
    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }
}


