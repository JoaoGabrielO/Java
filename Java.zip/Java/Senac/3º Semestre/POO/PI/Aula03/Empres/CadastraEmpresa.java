package PI.Empres;

import PI.Empres.Departamento;
import PI.Empres.Empresa;

import javax.swing.*;

public class CadastraEmpresa {
    public static void main(String[] args) {
        int resp = 0;
        do {
            Empresa empresa = new Empresa();
            empresa.setNome(JOptionPane.showInputDialog("Digite o nome da Empresa."));

            int qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de Departamentos."));
            Departamento departamentos[] = new Departamento[qtd];

            for (int i = 0; resp == 0; i++) {
                departamentos[i] = new Departamento();
                departamentos[i].setEmpresa(empresa);
                departamentos[i++].setNomeDepartamento(
                        JOptionPane.showInputDialog("Digite o nome do Departamento."));
                resp = JOptionPane.showConfirmDialog(null, "Cadastrar outro Departamento?");
            }
            empresa.setDepartamentos(departamentos);
            System.out.println(empresa);
            resp = JOptionPane.showConfirmDialog(null, "Cadastrar outra Empresa?");
        } while (resp == 0);
    }
}
