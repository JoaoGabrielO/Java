package PI.Calendar;

import PI.Pessoa.Pessoa;

import java.util.Calendar;
import java.util.Scanner;

public class IdadePessoa {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite seu nome:");
        String nome= sc.next();
        System.out.println("Digite seu ano de nascimento:");
        int ano = sc.nextInt();

        Calendar c = Calendar.getInstance();
        Pessoa pessoa = new Pessoa(nome, "11 976559007", 1, c.get(Calendar.YEAR) - ano);

        System.out.println(pessoa.toString());
    }
}
