package PI.Pessoa;

public class TesteFinal {
    private final int num = 350;
    public int getNum(){
        return this.num;
    }

    public static void main(String[] args) {
        TesteFinal tf = new TesteFinal();
        // tf.num; VAI DAR ERRO, POIS SÓ PODE SER ESTANCIADA UMA VEZ
        System.out.println(tf.getNum());


    }
}
