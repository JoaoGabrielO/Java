package PI.Pessoa;

public class Pessoa {
    private String nome, telefone;
    private int sexo, idade;



    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getSexo() {
        return sexo;
    }

    public static int MASCULINO = 1;
    public static int FEMININO = 2;

    public void setSexo(int s){
        sexo = s;
    }

    public Pessoa(String nome, String telefone, int sexo, int idade) {
        this.nome = nome;
        this.telefone = telefone;
        this.sexo = sexo;
        this.idade = idade;
    }

    @Override
    public String toString() {
        return "Pessoa{" +
                "nome='" + nome + '\'' +
                ", telefone='" + telefone + '\'' +
                ", sexo=" + sexo +
                ", idade=" + idade +
                '}';
    }
}
