package PI.Pessoa;

public class TestePessoa {
    public static void main(String[] args) {
        Pessoa joao = new Pessoa("joao", "11222", 2, 12);

        joao.setSexo(Pessoa.MASCULINO);

        System.out.println(joao.getSexo());


    }
}
