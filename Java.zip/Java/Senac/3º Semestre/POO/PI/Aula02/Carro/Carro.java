package Carro;

public class Carro {
    protected int litrosNoTanque;
    protected boolean carroLigado;

    public void encherTanque(int litros){
        setLitrosNoTanque(litros);
    }
    public int getLitrosNoTanque() {
        return litrosNoTanque;
    }

    public void setLitrosNoTanque(int litrosNoTanque) {
        this.litrosNoTanque = litrosNoTanque;
    }

    public boolean getCarroLigado() {
        return carroLigado;
    }

    public void setCarroLigado(boolean carroLigado) {
        this.carroLigado = carroLigado;
    }

    public String dadosCarro() {
        return "Carro{" +
                "Litros No Tanque= " + litrosNoTanque + "\n" +
                 " Carro Ligado= " + carroLigado + "\n" +
                '}';
    }
}
