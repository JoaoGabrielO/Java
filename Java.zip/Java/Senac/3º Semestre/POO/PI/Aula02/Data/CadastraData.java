package Data;

import java.util.Scanner;

public class CadastraData {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o ano: ");
        int ano = sc.nextInt();
        System.out.println("Digite o mes: ");
        byte mes = sc.nextByte();
        System.out.println("Digite o dia: ");
        byte dia = sc.nextByte();

        Data data = new Data(ano, mes, dia);

        System.out.println(data.getAno() + " - " + (data.isAnoBissexto() ? "Bissexto " : "Não bissexto" ));
    }
}
