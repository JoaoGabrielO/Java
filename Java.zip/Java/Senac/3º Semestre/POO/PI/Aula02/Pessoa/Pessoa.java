package Pessoa;

public class Pessoa {
    private String nome, endereco;
    private int idade;

    public void andar(){

    }
    public void informalidade(){

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Pessoa(String nome, int idade, String endereco){
        this.nome = nome;
        this.idade = idade;
        this.endereco = endereco;
    }
    public Pessoa(){

    }
    public String dadosPessoa() {
        return "Pessoa.Pessoa{" +
                "\n nome='" + nome + '\'' +
                ", \n endereco='" + endereco + '\'' +
                ", \n idade=" + idade + "\n" +
                '}';
    }
}
