package Pessoa;

import java.sql.SQLOutput;
import java.util.Scanner;

public class CadastraPessoa {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);



        System.out.println("Quantas pessoas deseja cadastrar?");
        int quant = sc.nextInt();
        Pessoa p[] = new Pessoa[quant];

        for(int i = 0; i < p.length; i++) {


            System.out.println("Digite o nome da " + (i+1) + "° pessoa: ");
            String nome = sc.next();

            System.out.println("Digite a idade da " + (i+1) + "° pessoa: ");
            int idade = sc.nextInt();

            System.out.println("Digite o endereco da " + (i+1) + "° pessoa: ");
            String endereco = sc.next();

            Pessoa pessoa = new Pessoa(nome, idade, endereco);
            p[i] = pessoa;

        }
        for(int i = 0; i < p.length; i++){
            System.out.println(p[i].dadosPessoa());
        }

    }
}
