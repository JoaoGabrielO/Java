package AnosBissextos;

import java.util.Scanner;

public class Anos {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o ano que deseja: ");
        int ano = sc.nextInt();

        AnosBissextos a = new AnosBissextos(ano);


        System.out.println(a.totalAnos());
    }
}
