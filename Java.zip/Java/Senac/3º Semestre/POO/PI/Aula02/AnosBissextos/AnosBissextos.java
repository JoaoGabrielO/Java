package AnosBissextos;

public class AnosBissextos {
    private int ano, cont;

    public void calcAnos(int anoDesej){
        for(int i = 0; i < anoDesej; i++){
            if(((i %4 == 0) &&  (i %100 != 0)) || (i %400 == 0)){
                setCont(getCont() +1);
            }
        }
    }
    public void imprimeAnos(int anoAtual){
        for(int i = 0; i < anoAtual; i++){
            if(((i %4 == 0) &&  (i %100 != 0)) || (i %400 == 0)){
                System.out.println(i);
            }
        }
    }
    public String totalAnos(){
       return "O total de anos bissextos até a data escolhida é: " + getCont();
    }
    public AnosBissextos(int ano) {
        this.ano = ano;
    }

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
}
