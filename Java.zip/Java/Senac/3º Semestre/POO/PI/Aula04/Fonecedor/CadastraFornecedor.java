package PI.Fonecedor;

import javax.swing.*;

public class CadastraFornecedor {
    public static void main(String[] args) {
        int tipo = Integer.parseInt(JOptionPane.showInputDialog("Qual tipo de fornecedor deseja cadastrar?" +
                "\n[1]Pessoa \t    " + "     [2]Empresa"));
        int quant = Integer.parseInt(JOptionPane.showInputDialog("Quantos fornecedores deseja cadastrar?"));
        Fornecedor vetor[] = new Fornecedor[quant];

        switch (tipo){
            case 1:

                for(int i = 0; i < vetor.length; i++){
                    FonecedorPessoa pessoa = new FonecedorPessoa();
                    pessoa.setNome(JOptionPane.showInputDialog("Nome fornecedor:"));
                    pessoa.setFone(JOptionPane.showInputDialog("Telefone fornecedor:"));
                    pessoa.setRG(JOptionPane.showInputDialog("RG fornecedor:"));
                    pessoa.setCPF(JOptionPane.showInputDialog("CPF fornecedor: "));
                    vetor[i] = pessoa;
                }
                break;

            case 2:
                for(int i = 0; i < vetor.length; i++){
                    FornecedorEmpresa empresa = new FornecedorEmpresa();
                    empresa.setNome(JOptionPane.showInputDialog("Nome fornecedor:"));
                    empresa.setFone(JOptionPane.showInputDialog("Telefone fornecedor:"));
                    empresa.setCNPJ(JOptionPane.showInputDialog("CNPJ fornecedor:"));
                    empresa.setIE(JOptionPane.showInputDialog("IE forncedor"));
                    vetor[i] = empresa;

                }
                break;
        }
        for(int i = 0; i < vetor.length; i++){
            if(vetor[i] instanceof FonecedorPessoa){
                FonecedorPessoa pessoa = (FonecedorPessoa) vetor[i];
                System.out.println(pessoa);
            } else if (vetor[i] instanceof FornecedorEmpresa) {
                FornecedorEmpresa empresa = (FornecedorEmpresa) vetor[i];
                System.out.println(empresa);

            }
        }
    }
}
