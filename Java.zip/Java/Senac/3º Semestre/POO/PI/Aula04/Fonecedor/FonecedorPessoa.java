package PI.Fonecedor;

public class FonecedorPessoa extends Fornecedor {
    private String RG, CPF;

    public FonecedorPessoa(String nome, String fone) {
        super(nome, fone);
    }

    public FonecedorPessoa() {
    }

    public FonecedorPessoa(String nome, String fone, String RG, String CPF) {
        super(nome, fone);
        this.RG = RG;
        this.CPF = CPF;
    }

    public String getRG() {
        return RG;
    }

    public void setRG(String RG) {
        this.RG = RG;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    @Override
    public String toString() {
        return super.toString()  +
                "RG='" + RG + '\'' +
                ", CPF='" + CPF + '\'';
    }
}
