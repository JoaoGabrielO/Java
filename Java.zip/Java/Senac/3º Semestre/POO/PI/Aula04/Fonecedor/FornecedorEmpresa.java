package PI.Fonecedor;

public class FornecedorEmpresa extends Fornecedor{
    private String IE, CNPJ;

    public FornecedorEmpresa() {
    }

    public FornecedorEmpresa(String IE, String CNPJ) {
        super();
        this.IE = IE;
        this.CNPJ = CNPJ;
    }

    public String getIE() {
        return IE;
    }

    public void setIE(String IE) {
        this.IE = IE;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    @Override
    public String toString() {
        return super.toString() +
                "IE='" + IE + '\'' +
                ", CNPJ='" + CNPJ + '\'';
    }
}
