package PI.Bicho;

public class Gato extends Bicho{
    public void fala(){
        System.out.println("Miau");
    }

}
