package PI.Bicho;

public class Bicho {
    public void fala(){

    }
}
