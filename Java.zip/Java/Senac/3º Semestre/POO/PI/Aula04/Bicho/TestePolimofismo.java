package PI.Bicho;

import javax.swing.*;

public class TestePolimofismo {
    public static void main(String[] args) {
        String bicho = JOptionPane.showInputDialog("Digite a raça do bicho:");

        Bicho b;
        if(bicho.equalsIgnoreCase("cachorro")){
            b = new Cachorro();

        }else{
            b = new Gato();
        }
        b.fala();
    }
}
