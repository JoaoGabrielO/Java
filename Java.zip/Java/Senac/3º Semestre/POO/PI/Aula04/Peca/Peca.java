package PI.Peca;

import javax.swing.*;

public class Peca {
    public String nome;
    protected int comprimento;
    private int durabilidade;

    Peca(){

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getComprimento() {
        return comprimento;
    }

    public void setComprimento(int comprimento) {
        if(comprimento >= 0 && comprimento < 181){
            this.comprimento = comprimento;
        }else{
            JOptionPane.showMessageDialog(null,"Comprimento não atende aos paramentros. Deve estar entre 0 e 180");
        }

    }

    public int getDurabilidade() {
        return durabilidade;
    }

    public void setDurabilidade(int durabilidade) {
        if(durabilidade >= 0 && durabilidade < 26){
            this.durabilidade = durabilidade;
        }else{
            JOptionPane.showMessageDialog(null,"Durabilidade não atende aos paramentros. Deve estar entre 0 e 25");
        }
    }

    @Override
    public String toString() {
        return  "º Peca:\n" +
                " Nome:'" + nome + '\'' +
                " \nComprimento:" + comprimento +
                " \nDurabilidade:" + durabilidade ;
    }
}
