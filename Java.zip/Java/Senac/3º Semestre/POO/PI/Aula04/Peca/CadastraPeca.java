package PI.Peca;

import javax.swing.*;

public class CadastraPeca {
    public static void main(String[] args) {
        int quant = Integer.parseInt(JOptionPane.showInputDialog("Quantas peças deseja cadastrar? "));

        Peca cadastro[] = new Peca[quant];

        for(int i = 0; i < cadastro.length; i++){
            cadastro[i] = new Peca();

            cadastro[i].nome = JOptionPane.showInputDialog("Nome da peça: ");
            cadastro[i].setComprimento(Integer.parseInt(JOptionPane.showInputDialog("Comprimento: ")));
            cadastro[i].setDurabilidade(Integer.parseInt(JOptionPane.showInputDialog("Durabilidade: ")));

        }
        for(int i = 0; i < cadastro.length; i++){
            JOptionPane.showMessageDialog(null,(i+1) +""+ cadastro[i]);
        }
    }
}
