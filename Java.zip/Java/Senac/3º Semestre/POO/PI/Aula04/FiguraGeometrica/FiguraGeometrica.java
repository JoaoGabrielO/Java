package PI.FiguraGeometrica;

public class FiguraGeometrica {
    protected double area;

    public void Area(){

    }
}
