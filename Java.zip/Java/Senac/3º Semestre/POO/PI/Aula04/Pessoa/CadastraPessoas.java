package PI.Pessoa;

import java.util.Calendar;
import javax.swing.JOptionPane;
    public class CadastraPessoas {
        public static void main(String[] args) {

            int quant = Integer.parseInt(JOptionPane.showInputDialog("Quantas pessoas deseja cadastrar? "));

            Pessoa vetor[] = new Pessoa[quant];

            for(int i = 0; i < vetor.length; i++) {

                Pessoa pessoa = new Pessoa();
                vetor[i] = pessoa;

                pessoa.setNome(JOptionPane.showInputDialog(
                        "Digite o nome da pessoa."));
                int anoNasc = Integer.parseInt(JOptionPane.showInputDialog(
                        "Digite o ano de seu nascimento."));
                Calendar calendar = Calendar.getInstance();
                System.out.println(calendar.get(Calendar.YEAR));
                pessoa.setIdade(calendar.get(Calendar.YEAR) - anoNasc);

            }
            for(int i = 0; i < vetor.length; i++){
                System.out.println(vetor[i].toString());
            }
        }
    }

