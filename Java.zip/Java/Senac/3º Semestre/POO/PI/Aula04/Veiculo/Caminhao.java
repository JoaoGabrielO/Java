package PI.Veiculo;

public class Caminhao extends Veiculo{
    private double pesoCarga;

    public Caminhao(String placa, int ano, double pesoCarga) {
        super(placa, ano);
        this.pesoCarga = pesoCarga;
    }

    public double getPesoCarga() {
        return pesoCarga;
    }

    public void setPesoCarga(float pesoCarga) {
        this.pesoCarga = pesoCarga;
    }

    public String mostrarDados() {
        return  "Caminhão: \n" + "Peso Carga=" + pesoCarga;
    }
}
