package PI.Veiculo;

import javax.swing.*;

public class CadastraVeiculo {
    public static void main(String[] args) {
        int qtd = Integer.parseInt(JOptionPane.showInputDialog(
                "Digite a quantidade de veículos a cadastrar:"));
        for (int i = 0; i < qtd; i++) {
            int escolha = Integer.parseInt(JOptionPane.showInputDialog(
                    "Digite: \n1-Ônibus \n2-Caminhão:"));
            String placa = JOptionPane.showInputDialog("Digite a placa:");
            int ano = Integer.parseInt(JOptionPane.showInputDialog(
                    "Digite o ano de fabricação:"));
            Veiculo novo = null;
            if (escolha == 1) {
                int passageiros = Integer.parseInt(JOptionPane.showInputDialog(
                        "Digite a quantidade de passageiros:"));
                novo = new Onibus(placa, ano, passageiros);
            } else if (escolha == 2) {
                double carga = Integer.parseInt(JOptionPane.showInputDialog(
                        "Digite a quantidade de passageiros:"));
                novo = new Caminhao(placa, ano, carga);
            }
            novo.mostrarDados();
        }
    }
}
