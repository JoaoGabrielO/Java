package EstruturaDeDados.Aula02;

public class Teste {
    public static void main(String[] args) throws Exception {
        Vetor vetor = new Vetor(5);

        try{
            vetor.adiciona("Tads");
            vetor.adiciona("TI");
            vetor.adiciona("Estrutura de dados");

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("O tamanho do vetor é: " + vetor.tamanho());
        System.out.println(vetor.toString());
        System.out.println(vetor.busca(2 ));
        System.out.println(vetor.busca1("ti"));
        System.out.println(vetor.adicionaInicio(2, "TI"));
    }
}
