package EstruturaDeDados.Aula01;

import java.util.Scanner;

public class MediaTemperatura {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite quantos dias deseja calcular: ");
        int dias = sc.nextInt();
        System.out.println("Digite a temperatura maxima: ");
        int maxTemp = sc.nextInt();

        float vetor[] = new float[dias];
        int contAcima = 0, contAbaixo = 0;
        float somaDias = 0, mediaTemp = 0;
        
        
        for(int i = 0; i < vetor.length; i++){
          vetor[i] = (float) (Math.random() * maxTemp);
            System.out.println(vetor[i]);

            somaDias += vetor[i];
        }
        mediaTemp = somaDias /dias;

        for(int i = 0; i < vetor.length; i++){
            if(vetor[i] > mediaTemp){
                contAcima ++;
            }
            if(vetor[i] < mediaTemp){
                contAbaixo ++;
            }
        }

        System.out.println("Periodo: " + dias + " dias");
        System.out.println("Temperatura média do periodo: " + mediaTemp);
        System.out.println("Em " + contAcima + " dias a temperatura ficou acima da média.");
        System.out.println("Em " + contAbaixo + " dias a temperatura ficou abaixo da média.");

    }
}
