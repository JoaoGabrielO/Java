package EstruturaDeDados.Aula04;

public class Teste {
    public static void main(String[] args) {
        Pilha<Integer> pilha = new Pilha<Integer>();

        System.out.println("Verifica se a Pilha está vazia: " + pilha.estaVazia());

        System.out.println(pilha); //Exibe
        System.out.println("O tamanho Real da pilha: ");

        for(int i = 1; i <= 25; i++){
            pilha.empilha(i);
        }
        System.out.println(pilha);
        System.out.println("Tamanho da Pilha " + pilha.tamanho());
    }
}
