package com.SpringBoot.demo.Servicos;

import com.SpringBoot.demo.Entidades.Postagem;
import com.SpringBoot.demo.RepositorioPostagem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicoPostagem {
    @Autowired
    private RepositorioPostagem repo;

    public List<Postagem> buscarTodos(){
        return repo.findAll();
    }

    public Postagem buscar(int id){
        Optional<Postagem> obj = repo.findById(id);
        return obj.orElseThrow(() -> new ObjetoNaoEncontrado(
                "Objeto não emcontrado! ID: " + id + ", Tipo: " + Postagem.class.getName()));

    }
    public Postagem  salvar(Postagem obj){
        obj.setId(null);
        return repo.save(obj);
    }
    public void deletar (int id){
        buscar(id); //ou existe, ou irá gerar exception
        repo.deleteById(id);
    }
    public Postagem editar(Postagem obj){
        Postagem newObj = buscar(obj.getId());
        modificar(newObj, obj);
        return repo.save(newObj);

    }
    private void modificar(Postagem newObj, Postagem obj){
        newObj.setAutor(obj.getAutor());
        newObj.setComentarios(obj.getComentarios());
        newObj.setTexto(obj.getTexto());
        newObj.setTitulo(obj.getTitulo());
    }

}
