package com.SpringBoot.demo.Entidades;

public class Comentario {
}
