package com.SpringBoot.demo.Repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.SpringBoot.demo.Entidades.Postagem;
@Repository
public interface RepositorioPostagem extends JpaRepository<Postagem, Integer> {
}
