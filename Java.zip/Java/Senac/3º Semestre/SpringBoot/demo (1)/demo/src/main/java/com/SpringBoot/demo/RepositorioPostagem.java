package com.SpringBoot.demo;

import com.SpringBoot.demo.Entidades.Postagem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioPostagem extends JpaRepository<Postagem, Integer > {
}
