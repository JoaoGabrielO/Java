package com.SpringBoot.demo.Recurso;

public class RecursoAutor {
}
