package com.SpringBoot.demo.Entidades;

public class Autor {
}
