package Facul_Tads.Aula_Algoritmos;

import java.util.Scanner;

public class Funcao_matriz_Prova {
    static int[][] mat(int lin, int col) {
        Scanner sc = new Scanner(System.in);

        int matriz[][] = new int[lin][col];

        for (int l = 0; l < matriz.length; ++l) {
            for (int c = 0; c < matriz[l].length; ++c) {
                System.out.println("Digite o " + (c + 1) + "º elemento da " + (l + 1) + "º linha da matriz");
                matriz[l][c] = sc.nextInt();
            }
        }
        for (int l = 0; l < matriz.length; ++l) {
            for (int c = 0; c < matriz[l].length; ++c) {
                System.out.print(matriz[l][c] + "\t");
            }
            System.out.println();
        }
        return matriz;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a quantidade de linhas para a matriz: ");
        int l = sc.nextInt();
        System.out.println("Digite a quantidade de coluas para a matriz: ");
        int c = sc.nextInt();

        mat(l,c);

    }
}