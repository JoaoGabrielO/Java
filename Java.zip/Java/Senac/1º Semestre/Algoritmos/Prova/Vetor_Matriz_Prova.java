package Facul_Tads.Aula_Algoritmos;

public class Vetor_Matriz_Prova {
    public static void main(String[] args) {
        int[] vetor = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
        int matriz[][] = new int[6][3];
        int contador = 0;

        for (int l = 0; l < matriz.length; ++l) {
            for (int c = 0; c < matriz[l].length; ++c) {
                matriz[l][c] = vetor[contador];
                contador ++;

            }
        }
        for (int l = 0; l < matriz.length; ++l) {
            for (int c = 0; c < matriz[l].length; ++c) {
                System.out.print(matriz[l][c] + "\t");

            }
            System.out.println();
        }
    }
}
