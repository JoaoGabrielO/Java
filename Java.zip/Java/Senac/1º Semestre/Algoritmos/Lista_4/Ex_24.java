package Facul_Tads.Aula_Algoritmos.Lista_4;

import java.util.Scanner;

public class Ex_24 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite quantas linhas deseja para a matriz");
        int qtdL = sc.nextInt();
        System.out.println("Digite quantas colunas deseja para a matriz");
        int qtdC = sc.nextInt();
        sc.close();

        int matriz [][] = new int[qtdL][qtdC];

        for(int l = 0; l < matriz.length; ++l) {

            for (int c = 0; c < matriz[l].length; ++c) {

                if ((c + 1) % 2 == 1) {
                    matriz[l][c] = 7;

                } else if ((c + 1) % 2 == 0) {
                    matriz[l][c] = 4;

                }
            }
        }
        for(int l = 0; l < matriz.length; ++l){//Laço de impressão das linhas
            for(int c = 0; c < matriz[l].length; ++c){//Laço de impressão das colunas
                System.out.print(matriz[l][c] + "\t");
            }
            System.out.println(); //Quebrar linha a cada nova linha
        }
    }
}



