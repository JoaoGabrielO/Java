package Facul_Tads.Aula_Algoritmos.Lista_4;

import java.util.Scanner;

public class Ex_18 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        float vetor[] = {40, 33, 101, 205, 87, 7};

        System.out.println("Digite o número que quer verificar ");
        float N = sc.nextInt();

        for (int i = 0; i < vetor.length; i++) {

            if (N == vetor[i]) {
                System.out.println("Número esta presente no vetor\nNa " + (i + 1) + "° posição ");
                break;

            } else if (N != vetor[i] && i == 5 ) {
                System.out.println("Esse número não se encontra no vetor ");
            }
        }
    }
}


