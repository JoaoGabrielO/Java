package Facul_Tads.Aula_Algoritmos.Lista_4;

import java.util.Scanner;

public class Ex_25 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a quantidade de linha que deseja para a matriz");
        int qtdL = sc.nextInt();
        System.out.println("Digite a quantidade de colunas que deseja para a amtriz");
        int qtdC = sc.nextInt();
        sc.close();

        int matriz [][] = new int[qtdL][qtdC];

        for(int l = 0; l < matriz.length; ++l){
            for(int c = 0; c < matriz[l].length; ++c){
                matriz[l][c] = l +1;
            }
        }
        for(int l = 0; l < matriz.length; ++l){//Laço de impressão das linhas
            for(int c = 0; c < matriz[l].length; ++c){//Laço de impressão das colunas
                System.out.print(matriz[l][c] + "\t");

            }
            System.out.println();//Quebrar linha a cada nova linha
        }
    }
}
