package Facul_Tads.Aula_Algoritmos.Lista_4;

import java.util.Scanner;

public class Ex_22 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a quantidade de linhas que deseja para a matriz ");
        int qtdL = sc.nextInt();
        System.out.println("Digite a quantidade de colunas que deseja para a matriz ");
        int qtdC = sc.nextInt();
        sc.close();

        int matriz[][] = new int[qtdL][qtdC];

        for (int l = 0; l < matriz.length; l++) { //Laço das linhas(l)

            for (int c = 0; c < matriz[l].length; c++) { //Laço das colunas(c)

                matriz[l][c] = 20;

            }
        }
        for (int l = 0; l < matriz.length; l++) { //Laço de impressão das linhas
            for (int c = 0; c < matriz[l].length; c++){ //Laço de impressão das colunas
                System.out.print(matriz[l][c] + "\t");
            }
            System.out.println(); //Quebrando linha a cada nova linha
        }
    }
}
