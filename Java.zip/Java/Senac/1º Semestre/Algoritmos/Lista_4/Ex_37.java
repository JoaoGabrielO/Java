package Facul_Tads.Aula_Algoritmos.Lista_4;

import java.util.Scanner;

    public class Ex_37 {
        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);

            int contL = 0, contC = 0, somaL = 0, somaC = 0;

            System.out.println("Digite a quantidade de linha que deseja para a matriz");
            int qtdL = sc.nextInt();
            System.out.println("Digite a quantidade de colunas que deseja para a amtriz");
            int qtdC = sc.nextInt();

            int matriz[][] = new int[qtdL][qtdC];

            for (int l = 0; l < matriz.length; ++l) {
                for (int c = 0; c < matriz[l].length; ++c) {
                    System.out.println("\nDigite o " + (c + 1) + "º elemento da " + (l + 1) + "º linha ");
                    matriz[l][c] = sc.nextInt();

                    //SOMAR LINHAS
                    somaL += matriz[l][c];

                    //VERIFICAR SE AS LINHAS SÃO NULAS
                    if (somaL == 0 && (c + 1) == matriz[c].length) {
                        contL++;

                    }
                }
                somaL = 0;
            }
            for (int c = 0; c < matriz.length; ++c) {
                for (int l = 0; l < matriz[c].length; ++l) {

                    //SOMAR COLUNAS
                    somaC += matriz[l][c];

                    //VERIFICAR SE AS COLUNAS SÃO NULAS
                    if (somaC == 0 && (l + 1) == matriz[l].length) {
                        contC++;

                    }
                }
                somaC = 0;
            }
            for (int l = 0; l < matriz.length; ++l) {//Laço de impressão das linhas
                for (int c = 0; c < matriz[l].length; ++c) {//Laço de impressão das colunas
                    System.out.print(matriz[l][c] + "\t");

                }
                System.out.println();//Quebrar linha a cada nova linha
            }
            System.out.println("Linhas nulas: " + contL);
            System.out.println("Colunas nulas: " + contC);

        }
    }