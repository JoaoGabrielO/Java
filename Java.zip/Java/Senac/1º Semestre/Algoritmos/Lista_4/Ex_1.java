package Facul_Tads.Aula_Algoritmos.Lista_4;

public class Ex_1 {
    public static void main(String[] args){

        int vetor [] = {2, 3, 4, 5, 6, 7};

        for (int i = 0; i < vetor.length; i++) {
            System.out.println(vetor[i]);

        }
    }
}
