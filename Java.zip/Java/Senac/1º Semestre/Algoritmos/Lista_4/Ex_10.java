package Facul_Tads.Aula_Algoritmos.Lista_4;

import java.util.Scanner;

public class Ex_10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        float result = 0;
        float Soma = 0;


        System.out.println("Insira o tamanho do vetor que deseja ");
        int qtd = sc.nextInt();

        float []vetorA = new float[qtd];

        System.out.println("Digite o multiplicador dos elementos do vetor ");
        float N = sc.nextFloat();
        for(int i = 0; i < qtd; ++i) {
            System.out.println("Insira o " + (i +1) + "º valor do vetor A");
            vetorA[i] = sc.nextFloat();
            if ((i +1) %2 ==1) {
                System.out.println("O resultado de " + vetorA[i] + " X " + N +  " = " + (vetorA[i] * N));
                Soma = (vetorA[i] * N);
                result = Soma + result;
            }
            sc.reset();
        }
        System.out.println("O resultado final de todas as multiplicações é " + result);
        sc.close();
    }
}
