package Facul_Tads.Aula_Algoritmos.Lista_4;

import javax.swing.*;

public class TesteM {
    public static void main(String[] args) {

        int matriz[][] = new int[3][3];
//laço cadastro
        for (int l = 0; l < matriz.length; l++)//laço lihas(1)
        {
            for (int c = 0; c < matriz[l].length; c++)//laço colunas(c)
            {
                matriz[l][c] = Integer.parseInt(JOptionPane.showInputDialog
                        ("Digite o " + (l + 1) + " °número da " + (c + 1) + " ªcoluna "));
            }
        }
        //laço de impressão
        for (int l = 0; l < matriz.length; l++){//laço linhas(1)

            for (int c = 0; c < matriz[l].length; c++){//laço colunas(c)
                System.out.print(matriz[l][c] + "\t");
            }
            System.out.println();//quebrando linha a cada nova linha
        }
    }
}




