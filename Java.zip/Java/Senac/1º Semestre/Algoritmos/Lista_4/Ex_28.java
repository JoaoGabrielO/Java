package Facul_Tads.Aula_Algoritmos.Lista_4;

import java.util.Scanner;

public class Ex_28 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        int soma = 0, soma1 = 0;

        System.out.println("Digite a quantidade de linha que deseja para a matriz");
        int qtdL = sc.nextInt();
        System.out.println("Digite a quantidade de colunas que deseja para a amtriz");
        int qtdC = sc.nextInt();

        int matriz [][] = new int[qtdL][qtdC];

        for(int l = 0; l < matriz.length; ++l) {
            for (int c = 0; c < matriz[l].length; ++c) {
                if (l == 0) {
                    System.out.println("\nDigite o " + (c + 1) + "º elemento da " + (l + 1) + "º linha ");
                    matriz[l][c] = sc.nextInt();

                    soma += matriz[l][c];
                    System.out.println("A soma dos elementos da " + (l + 1) + "º linha é: " + soma);

                }
                if (l > 0) {
                    System.out.println("\nDigite o " + (c + 1) + "º elemento da " + (l + 1) + "º linha ");
                    matriz[l][c] = sc.nextInt();

                    soma1 += matriz[l][c];
                    System.out.println("A soma dos elementos da " + (l + 1) + "º linha é: " + soma1);

                }
            }
            soma1 = 0;
        }
        for(int l = 0; l < matriz.length; ++l){//Laço de impressão das linhas
            for(int c = 0; c < matriz[l].length; ++c){//Laço de impressão das colunas
                System.out.print(matriz[l][c] + "\t");

            }
            System.out.println();//Quebrar linha a cada nova linha
        }
    }
}


