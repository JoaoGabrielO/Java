package Facul_Tads.Aula_Algoritmos.ADO_8;

import java.util.Scanner;

public class Ex_1 {

    static int quant = 3;

    static int [] funcao (int [] numero) {

        int numero2 [] = new int [quant];

        for (int cont = 0; cont < numero2.length; cont++) {
            numero2 [cont] = numero [cont];
        }
        return numero2;
    }

    public static void main(String[] args) {

        int numero [] = new int [quant];
        int numero2 [] = new int [quant];

        Scanner sc = new Scanner (System.in);

        for (int cont = 0; cont < numero.length; cont++){
            System.out.println("Informe o " + (cont + 1) + "º numero: ");
            numero [cont] = sc.nextInt();
        }

        numero2 = funcao (numero);
        System.out.println("\nNúmeros copiados: ");

        for(int cont = 0; cont < quant; cont++){
            System.out.println("-> " +numero2 [cont]);

        }
    }
}
