package Facul_Tads.Aula_Algoritmos.ADO_8;

import java.util.Scanner;

public class Ex_3 {

    static int quant = 2;
    static int quant2= 4;
    
    static int [] funcao (int [] numero1, int [] numero2, int [] numero3) {
        for (int cont = 0; cont < numero3.length; cont++) {
            if (cont == 0) {
                numero3 [cont] = numero1 [cont];
                
            } else if (cont == 1) {
                numero3 [cont] = numero2 [cont -1];
                
            } else if (cont % 2 == 0) {
                numero3 [cont] = numero1 [cont -1];
                
            } else if (cont % 2 == 1) {
                numero3 [cont] = numero2 [cont -2];
            }
        }
        return numero3;
    }
    
    public static void main(String[] args) {

        int numero1[] = new int[quant];
        int numero2[] = new int[quant];
        int numero3[] = new int[quant2];

        Scanner sc = new Scanner(System.in);

        for (int cont = 0; cont < numero1.length; cont++) {
            System.out.println("Informe o " + (cont + 1) + " º número do primeiro vetor ");
            numero1[cont] = sc.nextInt();

        }
        for (int cont = 0; cont < numero2.length; cont++) {
            System.out.println("Informe o " + (cont + 1) + " º número do segundo vetor ");
            numero2[cont] = sc.nextInt();

        }
        numero3 = funcao(numero1, numero2, numero3);
        System.out.println("A união dos dois vetores em um terceiro vetor: ");


        for (int contador = 0; contador < numero3.length; contador++) {
            System.out.println("-> " + numero3[contador]);

        }
    }
}
