package Facul_Tads.Aula_Algoritmos.ADO_8;

import java.util.Scanner;

public class Ex_2 {

    static int quant = 3;

    static int [] funcao (int soma1, int soma2) {

        int somat [] = new int [1];

        for(int cont = 0; cont < somat.length; cont++){
            somat [cont] = soma1 + soma2;

        }
        return somat;
    }

    public static void main (String [] args) {

        int numero [] = new int [quant];
        int numero2 [] = new int [quant];
        int soma1 = 0;
        int soma2 = 0;
        int somat [] = new int [1];

        Scanner sc = new Scanner(System.in);

        for(int cont = 0; cont < numero.length; cont++){
            System.out.println("Informe o " +(cont + 1)+ "º número do primeiro vetor");
            numero [cont] = sc.nextInt();
            soma1 = soma1 + numero[cont];

        }
        System.out.println();

        for(int cont = 0; cont < numero2.length; cont++){
            System.out.println("Informe o " +(cont + 1)+ "º número do segundo vetor");
            numero2 [cont] = sc.nextInt();
            soma2 = soma2 + numero2[cont];
        }

        System.out.println("\nA soma dos números do primeiro vetor é: " +soma1);
        System.out.println("\nA soma dos números do segundo vetor é: " +soma2);

        somat = funcao (soma1, soma2);
        int cont = 0;
        System.out.println("\nO resultado da soma dos dois vetores é: " +somat[cont]);

    }
}
