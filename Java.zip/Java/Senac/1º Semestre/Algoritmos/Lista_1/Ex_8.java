package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_8 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite n�mero 1 ");
        float N1 = leitor.nextFloat();
        System.out.println("Digite n�mero 2 ");
        float N2 = leitor.nextFloat();
        System.out.println("Digite n�mero 3 ");
        float N3 = leitor.nextFloat();
        System.out.println("Digite n�mero 4 ");
        float N4 = leitor.nextFloat();

        float media = (N1 + N2 + N3 + N4) /4;
        System.out.println("Sua m�dia aritim�tica � :" + media);

    }
}
