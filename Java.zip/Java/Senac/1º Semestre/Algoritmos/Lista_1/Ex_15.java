package Facul_Tads.Aula_Algoritmos.Lista_1;

import javax.swing.*;

public class Ex_15 {

    public static void main(String[] args) {

        float a = Float.parseFloat(JOptionPane.showInputDialog("Informe o n�mero A: "));
        float b = Float.parseFloat(JOptionPane.showInputDialog("Informe o n�mero B: "));
        float c = Float.parseFloat(JOptionPane.showInputDialog("Informe o n�mero C: "));

        float X1, X2, bhaskara1, bhaskara2, divisao = 0;

        bhaskara1 =  (float) ((b * -1) + (Math.sqrt(Math.pow(b, b) - 4 * a * c)));
        divisao = 2 * a;

        if (bhaskara1 < 0 || divisao == 0) {
            JOptionPane.showMessageDialog(null, "Impossivel calcular!");

        } else {
            bhaskara2 = (float) (( b * -1) - (Math.sqrt(Math.pow(bhaskara1,  b) - 4 * a * c)));
            X1 = bhaskara1 /divisao;
            X2 = bhaskara1 /divisao;
            JOptionPane.showMessageDialog(null, "O resultado de x1 �: " + X1 + "\n O resultado de X2 �: " + X2);

        }
    }
}
