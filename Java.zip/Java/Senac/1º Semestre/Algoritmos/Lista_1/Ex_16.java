package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_16 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o horario inicial do jogo: ");
        int horI = sc.nextInt();
        System.out.println("Digite o horario final do jogo: ");
        int horF = sc.nextInt();
        int dura = 0;

        if (horI > horF) {
            dura = (horI - 24) + (horF * -1);
            System.out.println("A durac�o do jogo total foi de: " + (dura * -1) + " hora(s).");

        } else if (horI < horF) {
            dura = horI - horF;
            System.out.println("A durac�o do jogo total foi de: " + (dura * -1) + " hora(s).");

        } else
            dura = 24;
        System.out.println("A durac�o do jogo total foi de: " + dura + " hora(s).");

    }
}
