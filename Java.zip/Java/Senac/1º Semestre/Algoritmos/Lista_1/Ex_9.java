package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_9 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite seu n�mero de cadastro ");
        float c = leitor.nextFloat();
        System.out.println("Digite seu n�mero de horas trabalhadas por dia ");
        float h = leitor.nextFloat();
        System.out.println("Qual valor recebe por hora? ");
        float vh = leitor.nextFloat();
        System.out.println("Digite o n�mero de dias trabalhados no mes ");
        float dm = leitor.nextFloat();

        System.out.println("O seu n�mero de cadastro � : " + c + ". Seus sal�rio por dia � R$ " + (h * vh) + ". E seu sal�rio por mes � de R$" + (h * vh * dm));

    }
}
