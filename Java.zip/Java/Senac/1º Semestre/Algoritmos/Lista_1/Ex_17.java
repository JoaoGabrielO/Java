package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_17 {

    public static void main(String[] args) {

        int A, B, C, D;
        int soma1, soma2;

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o valor de A ");
        A = sc.nextInt();
        System.out.println("Digite o valor de B ");
        B = sc.nextInt();
        System.out.println("Digite o valor de C ");
        C = sc.nextInt();
        System.out.println("Digite o valor de D ");
        D = sc.nextInt();

        soma1 = (C + D);
        soma2 = (A + B);

        if (B> C && D > A && soma1 > soma2 && C > 0 && D > 0 && A % 2 == 0) {
            System.out.println("Valores aceitos");

        } else
            System.out.println("Valores n�o aceitos ");

    }
}
