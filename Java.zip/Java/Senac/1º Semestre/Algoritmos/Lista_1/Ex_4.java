package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_4 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite o primeiro número ");
        int i = leitor.nextInt();
        System.out.println("Digite o segundo número ");
        int j = leitor.nextInt();

        System.out.println("Os numeros consecutivos s�o " + (i+1) + " e " + (j+1));

    }
}
