package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_11 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite um n�mero  ");
        float N1 = leitor.nextFloat();

        if (N1 <0) {
            System.out.println("N�mero negativo");

        } else
            System.out.println("N�mero positivo");

    }
}
