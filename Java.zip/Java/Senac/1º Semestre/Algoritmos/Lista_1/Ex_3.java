package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_3 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite o primeiro n�mero ");
        float N1 = leitor.nextFloat();
        System.out.println("Digite o segundo n�emro ");
        float N2 = leitor.nextFloat();
        System.out.println("O resultado da soma � :" + (N1 * N1 + N2 * N2));

    }
}
