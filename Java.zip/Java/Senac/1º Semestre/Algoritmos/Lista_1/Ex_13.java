package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_13 {

    public static void main(String[] args) {

        int n1 = 0;
        int n2 = 0;
        int n3 = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o primeiro n�mero ");
        n1 = sc.nextInt();

        System.out.println("Digite o segundo n�mero");
        n2 = sc.nextInt();

        System.out.println("Digite o terceiro n�mero");
        n3 = sc.nextInt();

        if (n1 > n2 && n1 > n3) {
            System.out.println("O primeiro n�mero � maior: " + n1);

        } else if (n2 > n1 && n2 > n3) {
            System.out.println("O segundo n�mero � maior: " + n2);

        } else if (n3 > n1 && n3 > n2) {
            System.out.println("O terceiro n�mero � maior: " + n3);

        }
    }
}
