package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_1 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite o 1� n�mero ");
        float N1 = leitor.nextFloat();
        System.out.println("Digite o 2� n�mero ");
        float N2 = leitor.nextFloat();

        float multip = (N1 * N2);
        System.out.println("O resultado do produto � " + multip);

    }
}
