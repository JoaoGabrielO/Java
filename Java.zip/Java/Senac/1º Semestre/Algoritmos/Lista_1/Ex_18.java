package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_18 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite os valores em ordem decrescente ");
        System.out.println("Digite o valor de A ");
        float a = sc.nextFloat();
        System.out.println("Digite o valor de B ");
        float b = sc.nextFloat();
        System.out.println("Digite o valor de C ");
        float c = sc.nextFloat();

        if (a >= b + c) {
            System.out.println("N�o forma tri�ngulo ");

        } else if (a * a == b * b + c * c) {
            System.out.println("TRIANGULO RETANGULO ");

        } else if (a * a > b * b + c * c) {
            System.out.println("TRIANGULO OBSANGULO ");

        } else if (a * a < b + c * c) {
            System.out.println("TRIANGULO ACUT�NGULO ");

        } else if (a == b && b == c) {
            System.out.println("TRIANGULO EQUILATERO ");

        } else if (a == b || b == c || a == c) {
            System.out.println("TRIANGULO ISOCELES ");

        }
    }
}
