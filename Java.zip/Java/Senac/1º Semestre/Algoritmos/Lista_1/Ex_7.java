package Facul_Tads.Aula_Algoritmos.Lista_1;

import java.util.Scanner;

public class Ex_7 {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite A ");
        float a = leitor.nextFloat();
        System.out.println("Digite B ");
        float b = leitor.nextFloat();

        double hipotenusa = Math.sqrt((a * a) + (b * b));
        System.out.println("A hipotenusa desse triangulo retangulo � de : " + hipotenusa);

    }
}
