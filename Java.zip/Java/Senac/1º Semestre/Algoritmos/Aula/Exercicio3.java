package AulaAlgoritmos;
import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		Scanner Imc = new Scanner(System.in);
		System.out.println("Digite seu peso ");
		float P = Imc.nextFloat();
		System.out.println("Digite sua altura ");
		float A = Imc.nextFloat();
		float M = (P/(A * A));
		System.out.println("Seu IMC � de " + M);
		if (M < 26) {
			System.out.println("Seu grau de obesidade � normal " );
		}
		else if ((M >= 26) && (M <30)) {
			System.out.println("Seu grau de obesidade � Obeso " );
		} 
	
		else if (M >= 30) {
			System.out.println("Seu grau de obesidade � Obeso m�rbido ");
		}
		
		
	}
}
