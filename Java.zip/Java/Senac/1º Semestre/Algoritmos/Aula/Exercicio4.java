package AulaAlgoritmos;
import java.util.Scanner;
public class Exercicio4 {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		System.out.println("Insira o Kw consumido ");
		float KW = leitor.nextFloat();
		 if (KW < 150) {
		 double cons = (KW * 0.20 + 11.90);
		 System.out.println("O valor da sua conta � de " + cons);
	} else if ((KW >= 150 ) && (KW < 500)){
		double cons = (KW * 0.25 + 11.90);
		 System.out.println("O valor da sua conta � de " + cons);
	} else {
		double cons = (KW * 0.30 + 11.90);
		 System.out.println("O valor da sua conta � de " + cons);
	}
		
		 
		
		
		
		
	}

}
