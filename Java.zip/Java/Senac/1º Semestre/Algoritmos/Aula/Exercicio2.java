package AulaAlgoritmos;
import java.util.Scanner;

public class Exercicio2 {
	
	public static void main(String[] args) {
		Scanner leitor = new
	    Scanner(System.in);
		System.out.println("Digite o primeiro n�mero ");
		float N1 = leitor.nextFloat();
		System.out.print("Digite o segunda n�mero ");
		float N2 = leitor.nextFloat();
		if (N1 % N2 == 0) {
			System.out.println("A divis�o do n�mero " + N1 + " por " + N2 + " � exata ! ");
	} else {
		System.out.println("A divis�o do n�mero " + N1 + " por " + N2 + " n�o � exata ! ");
	
	}

}
}
