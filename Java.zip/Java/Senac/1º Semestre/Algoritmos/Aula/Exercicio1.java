package AulaAlgoritmos;
import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Scanner numero = new Scanner(System.in); {
			System.out.println("Digite um n�mero ");
			int n1 = numero.nextInt();
			if (n1>100) {
				System.out.println(n1 + 150);}
				else  {
				System.out.println("Esse foi o n�mero que voce digitou "+ n1);
				}
			
				
			
		}
		
		}



	}
	