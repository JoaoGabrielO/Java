import java.util.Scanner;

public class Ado_Calculadora {

    static double soma (double a, double b){

        double Ressoma = 0;
        Ressoma = a + b;
        return (Ressoma);
    }

    static double multiplicacao (double a, double b){
        double Resmulti = 0;
        Resmulti = a * b;
        return (Resmulti);
    }

    static double subtracao (double a, double b){
        double Ressub = 0;
        Ressub = a - b;
        return (Ressub);
    }

    static double divisao (double a, double b){
        double Resdiv = 0;
        Resdiv = a / b;
        return (Resdiv);
    }

    static double raiz (double a){
        double Resraiz = 0;
        Resraiz = Math.sqrt(a);
        return (Resraiz);
    }

    static double potencia (double a, double b){
        double Respot = 0;
        Respot = Math.pow(a, b);
        return (Respot);
    }

    public static void main(String[] args){
        int resp = 0;
        double a, b, resultado;

        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Digite o primeiro valor ");
            a = sc.nextDouble();

            System.out.println("Digite o segunda valor ");
            b = sc.nextDouble();

            System.out.println("Digite a operação que deseja: \n(1)Soma \n(2)Multiplicação \n(3)Subtração \n(4)Divisão \n(5)Raiz \n(6)Potência \n(0)Saida");
            int operacao = sc.nextInt();

            switch (operacao) {

                case 1:
                    resultado = soma(a, b);
                    System.out.println("A soma é: " + resultado);
                    break;


                case 2:
                    resultado = multiplicacao(a, b);
                    System.out.println("O produto é: " + resultado);
                    break;


                case 3:
                    resultado = subtracao(a, b);
                    System.out.println("A diferença é: " + resultado);
                    break;


                case 4:
                    resultado = divisao(a, b);
                    System.out.println("A divisão é: " + resultado);
                    break;


                case 5:
                    resultado = raiz(a);
                    System.out.println("A Raiz é: " + resultado);
                    break;


                case 6:
                    resultado = potencia(a, b);
                    System.out.println("A Potência é: " + resultado);
                    break;


                case 0:
                    resp =2;
                    System.err.println("Tchau !! Até a proxima !!");
                    break;

                default:
                    System.err.println("!!!!!!!!!!!!!!!!!Número Inválido !!!!!!!!!!!!!");
                    resp = 1;
                    break;

            }
        }while (resp == 0);
    }
}

