package Facul_Tads.Aula_Algoritmos.Lista_2;

import java.util.Scanner;

public class Ex_16 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int N, X;

        System.out.println("Digite um valor ");
        N = sc.nextInt();

        for (int i=0; i < N; i++) {
            X = sc.nextInt();

            if (X == 0) {
                System.out.println("Nulo");
            }
            else {
                if (X % 2 == 0) {
                    System.out.print("Par ");
                }
                else {
                    System.out.print("Impar ");
                }
                if (X > 0) {
                    System.out.println("Positivo");
                }
                else {
                    System.out.println("Negativo");
                }
            }
        }
    }
}
