package Facul_Tads.Aula_Algoritmos.Lista_2;

public class Ex_10 {

    public static void main(String[] args) {

        int s = 1;
        float d = 2;
        float result = 1;


            while (d < 21) {

                System.out.println(result);
                result = result + (s / d);
                d++;

            }
    }
}