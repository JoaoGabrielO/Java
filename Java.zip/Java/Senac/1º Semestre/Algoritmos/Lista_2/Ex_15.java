package Facul_Tads.Aula_Algoritmos.Lista_2;

import java.util.Scanner;

public class Ex_15 {

    public static void main (String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um número para fatorar ");
        double N = sc.nextDouble();

        double f = N;
        while (N > 1){
            f = f *(N-1);
            N--;

            System.out.println(f);
        }
    }
}
