package Facul_Tads.Aula_Algoritmos.Lista_2;

import java.util.Scanner;

public class Ex_11 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int s = 1;
        float d = 2;
        float result = 1;{

            System.out.println("Digite um valor limite ");
            int N = sc.nextInt();

            while (d < N){

                System.out.println(result);
                result = result - (s/d)  ;
                d ++;

            }
        }
    }
}
