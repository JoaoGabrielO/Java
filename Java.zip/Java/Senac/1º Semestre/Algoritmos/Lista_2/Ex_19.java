package Facul_Tads.Aula_Algoritmos.Lista_2;

import java.util.Scanner;

public class Ex_19 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int senha = 0;
        int i = 0;

        for (i = 0; senha != 2002; i++) {

            System.out.print("Digite a senha ");
            senha = sc.nextInt();

            if (senha != 2002) {
                System.err.println("SENHA INVALIDA !!");

            }else {
                System.err.println("SENHA CORRETA !! ");

            }
        }
    }
}
