package Facul_Tads.Aula_Algoritmos.Lista_2;

public class Ex_1 {

    public static void main(String[] args) {

        int i = 0 ;

        while (i < 51){
            System.out.println(i);
            i = i + 1;

        }
    }
}
