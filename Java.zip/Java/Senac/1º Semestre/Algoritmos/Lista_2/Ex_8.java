package Facul_Tads.Aula_Algoritmos.Lista_2;

public class Ex_8 {

    public static void main (String [] args){

        int i;
        int n = 0;
        float media = (float) 0.0;

        for (i = 14; i < 73; i++) {

            if (i % 2 == 0) {
                media = media + i;
                n++;

            }
        }
        media = media / n;
        System.out.println("A Média Aritmética é: " +media);
    }
}
