package Facul_Tads.Aula_Algoritmos.Lista_2;

import java.util.Scanner;

public class Ex_13 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int t = 1;
        int s = 2;
        float u = 1;
        float d = 3;
        float result = 1;
        float contad = 2;

        System.out.println("Digite um valor limite ");
        int N = sc.nextInt();


            while (d < N || s < N) {

                System.out.println(result);
                result = (t * s) / (u * d);
                d = contad + d;
                u = contad + u;
                s++;
                t++;

            }
    }
}
