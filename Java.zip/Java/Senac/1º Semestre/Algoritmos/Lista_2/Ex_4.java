package Facul_Tads.Aula_Algoritmos.Lista_2;

public class Ex_4 {

    public static void main (String [] args){

        int i;

        for (i = 10; i <= 1000; i = i + 10){
            System.out.println(i);
        }
    }
}
