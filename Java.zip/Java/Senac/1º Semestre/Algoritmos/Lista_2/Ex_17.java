package Facul_Tads.Aula_Algoritmos.Lista_2;

import java.util.Scanner;

public class Ex_17 {

    public static void main(String[] args){

        Scanner sc =new Scanner(System.in);

        System.out.println("Digite o valor ");
        int num= sc.nextInt();

        for (int divisor = 1; divisor <= num; divisor++) {

            if (num % divisor !=0) {

            } else {
                System.out.println("Divisor de " + num + ": " + divisor);

            }
        }
    }
}
