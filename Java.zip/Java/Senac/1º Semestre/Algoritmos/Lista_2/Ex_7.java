package Facul_Tads.Aula_Algoritmos.Lista_2;

public class Ex_7 {

    public static void main (String [] args){

        int numero = 7;
        int i = 0;

        System.out.println("Os Múltiplos de 7 menores que 200 são: ");

        while (i <= 27) {

            i++;
            System.out.println(numero * i);

        }
    }
}


