package Facul_Tads.Aula_Algoritmos.Lista_2;

import java.util.Scanner;

public class Ex_3 {

    public static void main (String [] args){

        int i;
        int numero = 0;
        int numeromaior = 0;

        Scanner sc = new Scanner(System.in);

        for (i = 1; i < 11; i++) {
            System.out.println("Informe os Números: ");
            numero = sc.nextInt();
            if (numero > numeromaior) {
                numeromaior = numero;
            }
        }
        System.out.println("O Maior Número é: " +numeromaior);
    }
}
