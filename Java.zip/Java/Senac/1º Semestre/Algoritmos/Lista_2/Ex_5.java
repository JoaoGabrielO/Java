package Facul_Tads.Aula_Algoritmos.Lista_2;

public class Ex_5 {

    public static void main (String [] args){

        int n1 = 0;
        int i;

        for (i = 100; i > n1; i--) {

            if (i % 2 == 0) {
                System.out.println(i);

            }
        }
    }
}
