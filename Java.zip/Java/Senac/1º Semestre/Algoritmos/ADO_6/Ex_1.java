package Facul_Tads.Aula_Algoritmos.ADO_6;

public class Ex_1 {

    public static void main(String[] args) {

        int i=0;
        while (i<101) {
            System.out.println(i);
            i= i+2;

        }
    }
}

