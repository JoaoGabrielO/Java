package Facul_Tads.Aula_Algoritmos.ADO_6;

public class Ex_3 {

    public static void main(String[] args) {

        int x;

        for( x= 100; x> -1;) {
            System.out.println(x);
            x = x-5;

        }
    }
}
