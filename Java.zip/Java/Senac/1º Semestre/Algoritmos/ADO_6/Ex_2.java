package Facul_Tads.Aula_Algoritmos.ADO_6;

public class Ex_2 {

    public static void main(String[] args) {

        int x;
        for (x=1;x<110;) {
            System.out.println(x);
            x=x+2;

        }
    }
}
