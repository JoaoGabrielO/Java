package Facul_Tads.Aula_Algoritmos.ADO_6;

import java.util.Scanner;

public class Ex_4 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int contador = 0;
        int somapositivo = 0;
        float media = 0;

        while (contador <6) {
            System.out.println(" Digite um valor ");
            int valor = sc.nextInt();

            if (valor > -1) {

                somapositivo = somapositivo + valor;
                media = somapositivo/ 6;

            }
            contador ++;

        }

        System.out.println("Soma de todos os valores positivos: " + somapositivo);
        System.out.println("Valores positivos digitados " + contador);
        System.out.println("Média decimal dos valores positivos " + media);

    }
}
