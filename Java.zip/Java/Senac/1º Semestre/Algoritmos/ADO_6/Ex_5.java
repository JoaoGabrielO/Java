package Facul_Tads.Aula_Algoritmos.ADO_6;

import java.util.Scanner;

public class Ex_5 {

    public static void main(String[] args) {

        int N;
        int result;
        int cont=1;

        Scanner Numero = new  Scanner(System.in);
        System.out.println("Digite um valor ");
        N= Numero.nextInt();

        do {
            result = N * cont;
            System.out.println(cont + "X" + N + "=" + result);
            cont++;

        } while(cont<11);
    }
}
