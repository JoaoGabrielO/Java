package Java_Inicial.DIO;

import java.util.Scanner;

public class Emprestimo {

    public static double emprestimo(double val, double taxa, double parc){

        taxa *= parc;
        double valf = val * taxa;

        return valf;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o valor do emprestimo: ");
        double val = sc.nextDouble();
        System.out.println("Digite qual a taxa de juros: ");
        double taxa = sc.nextDouble();
        System.out.println("Digite a quantidade de parcelas: ");
        double parc = sc.nextDouble();

        System.out.println("O valor final do emprestimo foi de: " + emprestimo(val, taxa, parc));
    }
}
