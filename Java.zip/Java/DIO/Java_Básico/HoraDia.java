package Java_Inicial.DIO;

import java.util.Scanner;

public class HoraDia {
    public static void dia(int hora){
        if(hora > 18.00 || hora < 6.00){
            System.out.println("Boa noite !");
        }else if(hora >= 6.00 && hora < 13.00 ){
            System.out.println("Bom dia !");
        }else{
            System.out.println("Boa tarde !");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a hora do dia:");
        int n = sc.nextInt();

        dia(n);

    }
}
