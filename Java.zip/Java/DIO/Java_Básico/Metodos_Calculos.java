package Java_Inicial.DIO;

import java.util.Scanner;

public class Metodos_Calculos {
    public static double soma(double a, double b){
        double resultado = a + b;

        return resultado;
    }
    public static double subtracao(double a, double b) {
        double resultado = a - b;

        return resultado;
    }
    public static double divisao(double a, double b){
        double resultado = a /b;

        return resultado;
    }
    public static double multiplicacao(double a, double b){
        double resultado = a * b;

        return resultado;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Escolha a operação que deseja realizar: ");
        System.out.println("[A] SOMA");
        System.out.println("[B] SUBTRAÇÃO");
        System.out.println("[C] DIVISÃO");
        System.out.println("[D] MULTIPLICAÇÃO");
        String n = sc.next();

        System.out.println("1º Valor:");
        int a = sc.nextInt();
        System.out.println("2º Valor:");
        int b = sc.nextInt();


        switch (n){

            case "A":
            case "a":
                System.out.println("O resultado da operação é: " + soma(a, b));

            case "B":
            case "b":
                System.out.println("O resultado da operação é: " + subtracao(a, b));

            case "C":
            case "c":
                System.out.println("O resultado da operação é: " + divisao(a, b));

            case "D":
            case "d":
                System.out.println("O resultado da operação é: " + multiplicacao(a, b));

        }
    }
}
