package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_Vetor_5 {
    static void CincoVetores(){

        int qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho que deseja para os vetores"));

        int []vetor1 = new int[qtd];
        int []vetor2 = new int[qtd];
        int []vetor3 = new int[qtd];
        int []vetor4 = new int[qtd];
        int []vetor5 = new int[qtd];

        System.out.println("================= 1º VETOR ================= ");
        for(int i = 0; i < vetor1.length; ++i){
            vetor1[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + (i +1) + "º elemento do vetor: "));
            
        }
        System.out.println("================= 2º VETOR ================= ");
        for(int j = 0; j < vetor2.length; ++j){
            vetor2[j] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + (j +1) + "º elemento do vetor: "));

        }// 3º VETOR
        for(int i = 0; i < vetor3.length; ++i){
            vetor3[i] = vetor1[i] - vetor2[i];

        }// 4ºVETOR
        for(int j = 0; j < vetor4.length; ++j){
            vetor4[j] = vetor1[j] + vetor2[j];

        }// 5º VETOR
        for(int m = 0; m < vetor5.length; ++m){
            vetor5[m] = vetor1[m] * vetor2[m];

        }// LEITURA 1º VETOR
        System.out.println("================ 1º VETOR ================");
        for(int i = 0; i < vetor1.length; ++i){
            System.out.print(vetor1[i] + "\t");

        }// LEITURA 2º VETOR
        System.out.println("\n================ 2º VETOR ================");
        for(int i = 0; i < vetor2.length; ++i){
            System.out.print(vetor2[i] + "\t");

        }// LEITURA 3º VETOR
        System.out.println("\n================ 3º VETOR ================");
        System.out.println("================ VETOR DA DIFERENÇA DOS VETORES ================");
        for(int i = 0; i < vetor3.length; ++i){
            System.out.print(vetor3[i] + "\t");

        }// LEITURA 4º VETOR
        System.out.println("\n================ 4º VETOR ================");
        System.out.println("================ VETOR DA SOMA DOS VETORES ================");
        for(int i = 0; i < vetor4.length; ++i){
            System.out.print(vetor4[i] + "\t");

        }// LEITURA 5º VETOR
        System.out.println("\n6================ 5º VETOR ================");
        System.out.println("================ VETOR MULTIPLICAÇÃO ================");
        for(int i = 0; i < vetor5.length; ++i){
            System.out.print(vetor5[i] + "\t");

        }
    }
    public static void main(String[] args){

        CincoVetores();
    }
}
