package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_Vetor_1 {
    public static void main(String[] args){

        int qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho que deseja para o vetor"));

        int [] vetor = new int[qtd];
        String vetor1 = "\t";

        for(int i = 0; i < vetor.length; ++i){ //PEDINDO PARA O USUARIO ATRIBUIR O VALOR DE CADA ELEMENTO DO VETOR
            vetor[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + (i +1) + "º elemento do vetor"));
            vetor1 += vetor[i];
        }
        JOptionPane.showMessageDialog(null, vetor1);

        JOptionPane.showMessageDialog(null, "=============== VETOR NO 1º SENTIDO =============== ");
        for(int i = 0; i < vetor.length; ++i){ //IMPRIMINDO O VETOR NA TELA NA ORDEM
            JOptionPane.showMessageDialog(null, vetor[i]);
        }

        JOptionPane.showMessageDialog(null, "=============== VETOR NO 2º SENTIDO =============== ");
        for(int i = qtd; i > 0 ; --i){ //IMPRIEMINDO O VETOR NA TELA NA ORDEM CONTRÁRIA
            JOptionPane.showMessageDialog(null, vetor[i -1]);
        }
    }
}
