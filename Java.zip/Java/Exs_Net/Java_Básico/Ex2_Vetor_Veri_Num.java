package Java_Inicial.Exs_Net;

import java.util.Scanner;

public class Ex2_Vetor_Veri_Num {
    public static boolean cont(int[] vetor, int num){
        for(int n : vetor){
            if(num == n ){
                return true;

            }
        }
        return false;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o número que deseja buscar no vetor: ");
        int n = sc.nextInt();

        int [] vetor = new int[10];

        for(int i = 0; i < vetor.length; i++){
            vetor[i] = i;
        }
        for(int i : vetor){
            System.out.println((i +1) + "º elemento do vetor: " + vetor[i]);
        }
        System.out.println("Numero encontrado no vetor? " + cont(vetor, n));
    }
}
