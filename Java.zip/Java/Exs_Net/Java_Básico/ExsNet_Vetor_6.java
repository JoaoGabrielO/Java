package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_Vetor_6 {
    static void Nums() {

        int qtd = Integer.parseInt(JOptionPane.showInputDialog("Quantos números deseja armazenar ?"));

        int[] vetor1 = new int[qtd];
        int aux;
        boolean controle;

        for (int i = 0; i < vetor1.length; ++i) {
            vetor1[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + (i + 1) + "º número"));
        }
        for (int i = 0; i < vetor1.length; ++i) {
            for (int j = 0; j < (vetor1.length - 1); ++j) {

                if (vetor1[j] % 2 == 0) {
                    if (vetor1[j] < vetor1[j + 1]) {
                        aux = vetor1[j];
                        vetor1[j] = vetor1[j + 1];
                        vetor1[j + 1] = aux;
                    }
                }
                if (vetor1[j] % 2 == 1) {
                    if (vetor1[j] > vetor1[j + 1]) {
                        aux = vetor1[j];
                        vetor1[j] = vetor1[j + 1];
                        vetor1[j + 1] = aux;
                    }
                }
            }
        }
            for (int i = 0; i < vetor1.length; ++i) {
                System.out.println(vetor1[i] + "");
            }
        }
    public static void main(String[] args){
            Nums();

    }
}
