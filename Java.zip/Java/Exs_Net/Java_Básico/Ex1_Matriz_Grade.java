package Java_Inicial.Exs_Net;

public class Ex1_Matriz_Grade {
    public static void main(String[] args) {
        String matriz[][] = new String[10][10];

        for (int l = 0; l < matriz.length; l++) {
            for (int c = 0; c < matriz[l].length; c++) {
                matriz[l][c] = "_";
            }
        }
        for (int l = 0; l < matriz.length; l++) {
            for (int c = 0; c < matriz[l].length; c++) {
                System.out.print(matriz[l][c] + " \t");
            }
            System.out.println("");
        }
    }
}
