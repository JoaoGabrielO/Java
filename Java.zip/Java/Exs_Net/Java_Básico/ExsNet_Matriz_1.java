package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_Matriz_1 {
    public static void main(String[] args){

        int matriz[][] = new int[10][15];
        int somaL = 0, somaC = 0;

        for(int l = 0; l < 10; ++l) {
            for (int c = 0; c < 15; ++c) {
                matriz[l][c] = (int) ( 1 + Math.random() * (21-1));

            }
        }//IMPRESSÃO MATRIZ
            for(int l = 0; l < 10; ++l){
                for(int c = 0; c < 15; ++c){
                    System.out.print(matriz[l][c] + "\t");

                }
                System.out.println("");
            }
        //SOMA LINHAS
        for(int l = 0; l < 10; ++l){
            for(int c = 0; c < 15; ++c) {
                somaL += matriz[l][c];

            }
            System.out.println("Soma " + (l +1) + "º linha: " + somaL);
            if(somaL %2 == 0){
                System.out.println("A soma de linhas é par ");

            }else {
                System.out.println("A soma de linhas é ímpar ");

                somaL = 0;
            }
        }
        //SOMA COLUNAS
        for(int c = 0; c < 15; ++c){
            for(int l = 0; l < 10; ++l){
                somaC += matriz[l][c];

            }
            System.out.println("Soma " + (c +1) + "º coluna: " + somaC);
            if(somaC %2 == 0){
                System.out.println("A soma de colunas é par ");

            }else{
                System.out.println("A soma de colunas é ímpar ");

            }
            somaC = 0;
        }
    }
}
