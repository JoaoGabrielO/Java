package Exs_Aleatórios_Java;

public class ExsNet_Matriz_2 {
    public static void main(String[] args){

        int matriz[][] = new int[10][10];
        int []vetor = new int[50];

        for(int l = 0; l < matriz.length; ++l){
            for(int c = 0; c < matriz.length; ++c){
                matriz[l][c] = (int) ( 1 + Math.random() * (21-1));

            }
        }
        for(int l = 0; l < matriz.length; ++l){
            for(int c = 0; c < matriz.length; ++c){
                System.out.print(matriz[l][c] + "\t");
            }
            System.out.println();
        }
        System.out.println();
        System.out.println("Diagonal principal ");
        for(int l = 0; l < matriz.length; ++l) {
            vetor[l] = matriz[l][l];
            System.out.print(matriz[l][l] + "\t");
        }
        System.out.println();
        System.out.println("=================== VETOR =================== ");
        for(int l = 0; l < matriz.length; ++l) {
            System.out.println(vetor[l] + "\t");
        }
        System.out.println();
    }
}
