package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_Vetor_3 {
    static void vetor(){

        int qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite um tamanho para o vetor"));

        int [] vetor1 = new int[qtd];
        int [] vetor2 = new int[qtd];

        for(int i = 0; i < vetor1.length; ++i){

            vetor1[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + (i +1) + "º elemento do vetor"));

            if(i %2 == 0){
                vetor2[i] = vetor1[i] /2;

            }else if(i %2 == 1){
                vetor2[i] = vetor1[i] * 3;

            }
        }
        System.err.println("=============== PRIMEIRO VETOR =============== ");
        for(int i = 0; i < vetor1.length; ++i){
            System.out.print("\t" + vetor1[i]);
        }
        System.out.println("\n=============== SEGUNDO VETOR =============== ");
        for(int j = 0; j < vetor2.length; ++j){
            System.out.print("\t" + vetor2[j]);
        }
    }
    public static void main(String[] args){

        vetor();
    }
}
