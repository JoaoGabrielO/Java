package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_Vetor_4 {
    static void nomes() {


        int qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor"));

        String[] vetor = new String[qtd];

        for(int i = 0; i < vetor.length; ++i) {
            vetor[i] =JOptionPane.showInputDialog("Insira o " + (i +1) + "º nome do vetor ");

        }
        String N = JOptionPane.showInputDialog("Digite o nome que deseja encontar no vetor: ");
        int cont = 0;

        for(int j = 0; j < vetor.length; ++j){
            System.out.print(vetor[j] + ",\t");

            if(N.equalsIgnoreCase(vetor[j])){
                cont ++;
                JOptionPane.showMessageDialog(null, "ACHEI !!" + "\n Na " + (cont) + "º posição");

            }else {
                JOptionPane.showMessageDialog(null, "NÃO ACHEI !!");

            }

        }
    }
    public static void main(String[] args){
        nomes();


    }
}
