package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_1_HotPao {
    static void Padaria(){

        int pao = Integer.parseInt(JOptionPane.showInputDialog("Digite quantos pães você vendeu hoje:"));
        double Vpao = Double.parseDouble(JOptionPane.showInputDialog("Qual o valor do seu pão ?"));

        int broa = Integer.parseInt(JOptionPane.showInputDialog("Digite quantas broas você vendeu hoje:"));
        double Vbroa = Double.parseDouble(JOptionPane.showInputDialog("Qual o valor da sua broa ?"));

        double tP = pao * Vpao;
        JOptionPane.showMessageDialog(null, "Total arrecadado somente com os pães: " + tP + "R$");
        double tB = broa * Vbroa;
        JOptionPane.showMessageDialog(null, "Total arrecada somente com as broas: " + tB + "R$");

        double tD = tB + tP;
        JOptionPane.showMessageDialog(null, "Total arrecadado do dia: " + tD + "R$");

        int poup = Integer.parseInt(JOptionPane.showInputDialog("Quantos por cento desse total arrecadado voce deseja guardar na poupança ?"));
        double Vpoup = (tD/ 100) * poup;

        JOptionPane.showMessageDialog(null, "O valor guardado na poupança foi de: " + Vpoup + "R$");

    }
    public static void main(String[] args){

        Padaria();
    }
}
