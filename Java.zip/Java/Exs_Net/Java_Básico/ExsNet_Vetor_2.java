package Exs_Aleatórios_Java;

import javax.swing.*;

public class ExsNet_Vetor_2 {
    static void Dvetores() {

        int qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho para o vetor"));

        int [] vetor = new int [qtd];
        int [] vetor2 = new int [qtd];

        for(int i = 0; i < vetor.length; ++i){ //ATRIBUIÇÃO DOS VALORES DO PRIMEIRO VETOR
            vetor[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + (i +1) + "º elemento do vetor"));

        }
            for (int j = 0; j < vetor.length; ++j) { //ATRIBUIÇÃO DOS VALORES DO SEGUNDO VETOR
                vetor2[j] = vetor[qtd -1];
                qtd --;

            }

        System.out.println("============ PRIMEIRO VETOR ============");

        for(int i = 0; i < vetor.length; ++i){ //IMPRIMINDO PRIMEIRO VETOR
            System.out.println(vetor[i] + "\t");
        }
        System.out.println("============ SEGUNDO VETOR ============");

        for(int j = 0; j < vetor2.length; ++j){ //IMPRIMINDO SEGUNDO VETOR
            System.out.println(vetor2[j] + "\t");

        }
    }
    public static void main(String[] args){
        Dvetores();

    }
}
