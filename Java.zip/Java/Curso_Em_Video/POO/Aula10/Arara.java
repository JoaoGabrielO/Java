package POO_Java.Curso_Em_Video.Aula10;

public class Arara extends Ave{
}
