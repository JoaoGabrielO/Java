package POO_Java.Curso_Em_Video.Aula10;

public class Canguru extends Mamifero{
    public void usarBolsa(){
        System.out.println("Usando bolsa!");
    }
    @Override
    public void locomover(){
        System.out.println("Saltando!");
    }
}
