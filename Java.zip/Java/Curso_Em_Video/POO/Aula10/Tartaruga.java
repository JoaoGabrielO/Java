package POO_Java.Curso_Em_Video.Aula10;

public class Tartaruga extends Reptil{
    @Override
    public void locomover() {
        System.out.println("Andando beeeeeeem devagar!");
    }
}
