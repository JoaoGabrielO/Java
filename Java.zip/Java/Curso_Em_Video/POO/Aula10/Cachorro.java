package POO_Java.Curso_Em_Video.Aula10;

public class Cachorro extends Lobo{

    public void enterrarOsso(){
        System.out.println("Enterrando osso!");
    }
    public void abanarRabo(){
        System.out.println("Abanando o Rabo!");
    }

    @Override
    public void emitirSom(){
        System.out.println("Au! Au! Au!");
    }

}
