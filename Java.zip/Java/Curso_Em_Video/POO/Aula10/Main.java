package POO_Java.Curso_Em_Video.Aula10;

public class Main {


    public static void main(String[] args) {
        Mamifero m = new Mamifero();
        Reptil r = new Reptil();
        Peixe p = new Peixe();
        Ave a = new Ave();
        Canguru c = new Canguru();
        Cachorro k = new Cachorro();

        System.out.println("================== MAMIFÉRO ==================");

        m.setPeso(85.3f);
        m.setIdade(2);
        m.setMembros(4);
        m.locomover();
        m.alimentar();
        m.emitirSom();

        System.out.println("================== PEIXE ==================");

        p.setPeso(0.35f);
        p.setIdade(1);
        p.setMembros(0);
        p.locomover();
        p.alimentar();
        p.emitirSom();
        p.soltarBolha();

        System.out.println("================== AVE ==================");

        a.setPeso(0.89f);
        a.setIdade(2);
        a.setMembros(2);
        a.locomover();
        a.alimentar();
        a.emitirSom();
        a.fazerNinho();

        System.out.println("================== CANGURU ==================");

        c.setPeso(55.30f);
        c.setIdade(3);
        c.setMembros(4);
        c.locomover();
        c.alimentar();
        c.emitirSom();
        c.usarBolsa();

        System.out.println("================== CACHORRO ==================");

        k.setPeso(85.3f);
        k.setIdade(2);
        k.setMembros(4);
        k.locomover();
        k.alimentar();
        k.emitirSom();
    }
}
