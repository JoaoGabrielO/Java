package POO_Java.Curso_Em_Video.Aula09;

public class Visitante extends Pessoa{

}
