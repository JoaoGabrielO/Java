package POO_Java.Curso_Em_Video.Aula09;

public class Main {
    public static void main(String[] args) {
        Visitante v1 = new Visitante();
        Aluno a1 = new Aluno();
        Bolsista b1 = new Bolsista();
        Professor p1 = new Professor();
        Tecnico t1 = new Tecnico();  

        v1.setNome("Juvenal");
        v1.setIdade(22);
        v1.setSexo("M");
        System.out.println(v1.toString());

        System.out.println();

        a1.setNome("Claúdio");
        a1.setMatricula(1111);
        a1.setCurso("Informatica");
        a1.setIdade(16);
        a1.setSexo("M");
        a1.pagarMensal();
        System.out.println(a1.toString());

        System.out.println();

        b1.setMatricula(2222);
        b1.setNome("Jubileu");
        b1.setBolsa(12.5f);
        b1.setSexo("M");
        b1.pagarMensal();
        System.out.println(b1.toString());

        System.out.println();


    }
}

