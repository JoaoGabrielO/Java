package POO_Java.Curso_Em_Video.Exs.ProjetoLivro;

import POO_Java.Curso_Em_Video.Exs.ProjetoLivro.Pessoa;
import POO_Java.Curso_Em_Video.Exs.ProjetoLivro.Publicacao;

public class Livro implements Publicacao {
    private String titulo, autor;
    private int totalPags, pagAtual;
    private boolean aberto;
    private Pessoa leitor;

    //@Override
    public String detalhes() { // ESSE SERIA O MÉTODO TO STRING
        return "Livro{ " +
                "\n titulo= '" + titulo + '\'' +
                ", \n autor= '" + autor + '\'' +
                ", \n totalPags= " + totalPags +
                ", \n pagAtual= " + pagAtual +
                ", \n aberto= " + aberto +
                ", \n leitor= " + leitor.getNome() +
                ", \n idade= " + leitor.getIdade() +
                ", \n sexo= " + leitor.getSexo() + "\n" +
                '}';
    }

    public Livro(String titulo, String autor, int totalPags, Pessoa leitor) {
        setTitulo(titulo);
        setAutor(autor);
        setTotalPags(totalPags);
        setAberto(false);
        setPagAtual(0);
        setLeitor(leitor);
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Pessoa getLeitor() {
        return leitor;
    }

    public void setLeitor(Pessoa leitor) {
        this.leitor = leitor;
    }

    public int getTotalPags() {
        return totalPags;
    }

    public void setTotalPags(int totalPags) {
        this.totalPags = totalPags;
    }

    public int getPagAtual() {
        return pagAtual;
    }

    public void setPagAtual(int pagAtual) {
        this.pagAtual = pagAtual;
    }

    public boolean getAberto() {
        return aberto;
    }

    public void setAberto(boolean aberto) {
        this.aberto = aberto;
    }

    @Override
    public void abrir() {
        setAberto(true);
    }

    @Override
    public void fechar() {
        setAberto(false);
    }

    @Override
    public void folhear(int pag) {
        if(pag > getTotalPags()){
            setPagAtual(0);
        } else{
            setPagAtual(pag);
        }
    }

    @Override
    public void avancarPag() {
        setPagAtual(+1);
    }

    @Override
    public void voltarPag() {
        setPagAtual(-1);
    }
}
