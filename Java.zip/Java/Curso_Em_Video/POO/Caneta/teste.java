package POO_Java.Curso_Em_Video;

public class teste {
    public String cor;
    public String modelo;
    private float ponta;
    protected int carga;
    private boolean tampada;

//ALT + INSERT

}
