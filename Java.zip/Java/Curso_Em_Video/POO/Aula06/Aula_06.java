package POO_Java.Curso_Em_Video.Aula06;

public class Aula_06 {
    public static void main(String[] args) {
        ControleRemoto c1 = new ControleRemoto();

        c1.ligar();
        c1.maisVolume(2);
        c1.abrirMenu();
        c1.fecharMenu();


    }
}
