package POO_Java.Curso_Em_Video.Aula06;

public class ControleRemoto implements Controlador{

    //ATRIBUTOS
    private int Volume;
    private boolean Ligado;
    private boolean Tocando;

    //MÉTODOS ESPECIAIS
    public ControleRemoto() { //MÉTODO CONSTRUTOR
        this.Volume = 50;
        this.Ligado = true;
        this.Tocando = false;
    }

    private int getVolume(){
        return this.Volume;
    }
    private boolean getLigado(){
        return this.Ligado;
    }
    private boolean getTocando(){
        return this.Tocando;
    }

    private void setVolume(int v){
        this.Volume = v;
    }
    private void setLigado(boolean l){
        this.Ligado = l;
    }
    private void setTocando(boolean t){
        this.Tocando = t;
    }

    //METODOS ABSTRATOS
    @Override
    public void ligar() {
        this.setLigado(true);
    }

    @Override
    public void desligar() {
        this.setLigado(false);
    }

    @Override
    public void abrirMenu() {
        System.out.println("================ MENU ================");
        System.out.println("Está ligado? " + this.getLigado());
        System.out.println("Está tocando? " + this.getTocando());
        System.out.print("Volume: " + this.getVolume() + "=");
        for(int i = 0; i <= this.getVolume(); i += 10){
            System.out.print("|");
        }
        System.out.println("");
    }

    @Override
    public void fecharMenu() {
        System.out.println("Fechando Menu ...");
    }

    @Override
    public void maisVolume(int v) {
        if(this.getLigado()){
            for(int i = 0; i < v; i++) {
                this.setVolume((this.getVolume() + 5));
            }
        }else{
            System.out.println("Impossivel aumentar volume. Aparelho desligado.");
        }
    }

    @Override
    public void menosVolume(int v) {
        if(this.getLigado()){
            for(int i = 0; i < v; i++) {
                this.setVolume((this.getVolume() - 5));
            }
        }else{
            System.out.println("Impossivel diminuir volume. Aparelho desligado.");
        }
    }

    @Override
    public void ligarMudo() {
        if(this.getLigado() && this.getVolume() > 0){
            this.setVolume(0);
        }
    }

    @Override
    public void desligarMudo() {
        if(this.getLigado() && this.getVolume() == 0){
            this.setVolume(50);
        }
    }

    @Override
    public void play() {
        if(this.getLigado() && !(this.getTocando())){
            this.setTocando(true);
        }else{
            System.out.println("Não consegui reproduzir.");
        }
    }

    @Override
    public void pause() {
        if(this.getLigado() && this.getTocando()){
            this.setTocando(false);
        }else{
            System.out.println("Não consegui pausar.");
        }
    }
}
