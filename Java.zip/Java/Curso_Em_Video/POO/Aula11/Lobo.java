package POO_Java.Curso_Em_Video.Aula11;

public class Lobo extends Mamifero {
    @Override
    public void emitirSom(){
        System.out.println("Auuuuuuuuuuuuuuu!");
    }
}
