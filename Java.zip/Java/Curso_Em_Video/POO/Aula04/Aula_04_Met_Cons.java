package POO_Java.Curso_Em_Video.Aula04;

public class Aula_04_Met_Cons {
    public static void main(String[] args) {

        System.out.println("============== CANETA 1 ==============");


        Caneta_Get_Set_Cons c1 = new Caneta_Get_Set_Cons("NIC", "Amarela", 0.4f);
        c1.status();

        System.out.println("============== CANETA 2 ==============");

        Caneta_Get_Set_Cons c2 = new Caneta_Get_Set_Cons("KKK", "Verde", 1.0f);
        c2.status();

    }
}
