package POO_Java.Curso_Em_Video.Aula04;

public class Aula_04 {
    public static void main(String[] args) {

        Caneta_Get_Set_Cons c1 = new Caneta_Get_Set_Cons("NIC", "Amarela", 0.4f );
        c1.setModelo("BIC");
        //c1.modelo = "BIC"; //MÉTODO PUBLICO

        c1.setPonta(0.5f);
        //c1.Ponta = (float)0.5; //MÉTODO PRIVADO
        c1.status();

        System.out.println("Tenho uma caneta " + c1.getModelo() + " de ponta " + c1.getPonta());
    }
}
