package POO_Java.Curso_Em_Video.Aula02;

import POO_Java.Curso_Em_Video.Aula04.Caneta;

public class Aula_02 {
    public static void main(String[] args) {

        Caneta c1 = new Caneta();
        c1.cor = "Azul";
        //c1.ponta = (float)0.5;
        c1.destampar();
        c1.status();
        c1.rabiscar();
    }
}
