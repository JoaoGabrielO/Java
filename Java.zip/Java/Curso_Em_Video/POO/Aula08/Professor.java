package POO_Java.Curso_Em_Video.Aula08;

public class Professor extends Pessoa {
    private String especializado;
    private float salario;

    public void receberAumen(float aumento){
        setSalario(+ aumento);
    }

    public String getEspecializado() {
        return especializado;
    }

    public void setEspecializado(String especializado) {
        this.especializado = especializado;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

}
