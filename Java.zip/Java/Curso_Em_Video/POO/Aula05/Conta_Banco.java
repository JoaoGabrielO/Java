package POO_Java.Curso_Em_Video.Aula05;

public class Conta_Banco {

    public int numCont;
    protected String tipo;
    private String dono;
    private float saldo;
    private boolean status;

    public void estadoAtual(){
        System.out.println("=============================");
        System.out.println("Conta: " + this.getNumCont());
        System.out.println("Tipo: " + this.getTipo());
        System.out.println("Dono: " + this.getDono());
        System.out.println("Saldo: " + this.getSaldo());
        System.out.println("Status: " + this.getStatus());
    }
    public Conta_Banco() {
        this.status = false;
        this.saldo = 0.0f;
    }

    public int getNumCont() {
        return numCont;
    }
    public void setNumCont(int nC) {
        this.numCont = nC;
    }

    public String getTipo(){
        return tipo;
    }
    public void setTipo(String t){
        this.tipo = t;
    }

    public String getDono(){
        return this.dono;
    }
    public void setDono(String d){
        this.dono = d;
    }

    public float getSaldo(){
        return this.saldo;
    }
    public void setSaldo(float s){
        this.saldo = s;
    }

    public boolean getStatus() {
        return status;
    }
    public void setStatus(boolean st) {
        this.status = st;
    }

    public void abrirConta(String t){
        setTipo(t);
        setStatus(true);
        System.out.println(this.tipo);

        if(t.equalsIgnoreCase("cc")){
            setSaldo(50.0f);

        } else if (t.equalsIgnoreCase("cp")) {
            setSaldo(150.0f);
        }
        System.out.println("Conta aberta com sucesso !");
    }

    public void fecharConta(){
        if(getSaldo() > 0.0) {
            System.out.println("Conta com dinheiro. ");

        }else if(getSaldo() < 0){
            System.out.println("A conta esta em débito. ");

        } else{
            setStatus(false);
            System.out.println("Conta fechada com sucesso !");

        }
    }

    public void depositar(float v){
        if(this.getStatus() == true){
            //this.saldo = this.saldo + v;
            this.setSaldo(getSaldo() + v);
            System.out.println("Déposito realizado com sucesso ! Na comta de " + this.getDono());

        }else{
            System.out.println("Impossivel depositar em uma conta fechada. ");

        }
    }

    public void sacar(float v){
        if(this.getStatus() == true ){
            if(getSaldo() >= v){
                setSaldo(this.getSaldo() - v);
                System.out.println("Saque realizado na conta de " + this.getDono());

            }else{
                System.out.println("Saldo insuficiente. ");

            }
        }else{
            System.out.println("Impossivel sacar. Conta foi aberta. ");

        }
    }

    public void pagarMensal(){
        float v = 0;

        if(this.getTipo().equalsIgnoreCase("cc")){
            v = 12.0f;

        }else if(this.getTipo().equalsIgnoreCase("cp")){
            v = 20.0f;

        }
        if(this.getStatus() == true) {
            if(getSaldo() > v) {
                this.setSaldo(this.getSaldo() - v);
                System.out.println("Mensalidade paga com sucesso por " + this.getDono());

            }
        }else{
            System.out.println("Impossivel pagar. Sem conta aberta. ");
            
        }
    }
}
