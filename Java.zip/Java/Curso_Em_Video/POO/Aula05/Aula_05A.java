package POO_Java.Curso_Em_Video.Aula05;

import java.util.Scanner;

public class Aula_05A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Conta_Banco p1 = new Conta_Banco();
        p1.setNumCont(1111);
        p1.setDono("Jubileu");
        p1.abrirConta("cc");

        Conta_Banco p2 = new Conta_Banco();
        p2.setNumCont(2222);
        p2.setDono("Creuza");
        p2.abrirConta("cp");

        p1.depositar(100);
        p2.depositar(500);
        p2.sacar(100);

        p1.estadoAtual();
        p2.estadoAtual();



    }
}
