package POO_Java.Curso_Em_Video;

import java.util.Scanner;

public class teste {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um número: ");
        int numero = sc.nextInt();

        recursividade(numero);
    }
    public static int recursividade (int numero){
        if(numero > 50){
            return 0;
        }
        System.out.println(numero);
     return recursividade(numero +1);
    }
}
