package POO_Java.Curso_Em_Video.Aula03;

import POO_Java.Curso_Em_Video.Aula04.Caneta;

public class Aula_03 {
    public static void main(String[] args) {

        Caneta c1 = new Caneta();
        c1.modelo = "BIC cristal";
        c1.cor = "Azul";
        //c1.ponta = (float)0.5;
        c1.carga = 80;
        //c1.tampada = true;
        c1.destampar();
        c1.status();
    }
}
