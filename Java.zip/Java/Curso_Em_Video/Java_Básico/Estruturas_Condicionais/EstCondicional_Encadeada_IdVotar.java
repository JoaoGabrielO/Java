package Java_CursoEmvideo;

import javax.swing.*;
import java.util.Scanner;

public class EstCondicional_Encadeada_IdVotar {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

       int Id = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade"));

        if(Id < 16) {
            JOptionPane.showMessageDialog(null, "Nao vota");

        }else if(Id >=16 && Id < 18 || Id > 70){
            JOptionPane.showMessageDialog(null, "Voto opcional ");

        }else {
            JOptionPane.showMessageDialog(null, "Voto obrigatório");

        }
    }
}
