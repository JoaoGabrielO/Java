package Java_CursoEmvideo;

import java.util.Scanner;

public class EstruturaCondicional_Media_Aluno {
    public static void main(String[] args){

        float n1, n2, m;

        Scanner sc = new Scanner(System.in);
        System.out.println("Primeira nota: ");
        n1 = sc.nextFloat();
        System.out.println("Segunda nota: ");
        n2 = sc.nextFloat();

        m = (n1 + n2) /2;
        System.out.println("A média do aluno é de: " + m);

        if (m >= 7){
            System.out.println("Aluno APROVADO !!");

        } else if (m >= 5 && m <7){
            System.err.println("Aluno em RECUPERAÇÃO !!");

        } else {
            System.err.println("Aluno REPROVADO !!");

        }
    }
}
