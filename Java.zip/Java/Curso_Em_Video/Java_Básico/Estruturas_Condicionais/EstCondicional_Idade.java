package Java_CursoEmvideo;

import java.util.Scanner;

public class EstCondicional_Idade {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o seu ano de nascimento ");
        float Ann = sc.nextFloat();
        System.out.print("Digite o ano atual: ");
        float AnA = sc.nextFloat();
        float Id = AnA - Ann;
        System.out.println("Sua idade é: " + Id);

        if(Id >= 18){
            System.out.println("Voce é maior de idade !!!");

        } else {
            System.out.println("Voce é menor de idade !!!");
        }
    }
}
