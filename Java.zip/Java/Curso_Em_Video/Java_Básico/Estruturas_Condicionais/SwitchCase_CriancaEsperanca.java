package Java_CursoEmvideo;

import java.util.Scanner;

public class SwitchCase_CriancaEsperanca {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int D;
        float Valor = 0;

        System.err.println("-----------------------");
        System.err.println("   CRIANÇA ESPERANÇA   ");
        System.err.println("-----------------------");
        System.err.println(" Muito obrigado por ajudar ");
        System.out.println(" [1] para doar R$10 ");
        System.out.println(" [2] para doar R$25 ");
        System.out.println(" [3] para doar R$50 ");
        System.out.println(" [4] para doar outros valores ");
        System.out.println(" [5] para cancelar ");

        D = sc.nextInt();

        switch (D) {

            case 1:
                Valor = 10;
                break;

            case 2:
                Valor = 25;
                break;

            case 3:
                Valor = 50;
                break;

            case 4:
                System.out.println("Qual o valor da doação ? R$");
                Valor = sc.nextFloat();
                break;

            case 5:
                Valor = 0;
                break;

        }

        System.err.println("-----------------------");
        System.err.println(" SUA DOAÇÃO FOI DE R$ " + Valor);
        System.err.println(" MUITO OBRIGADO !! ");
        System.err.println("-----------------------");

    }
}
