package Java_CursoEmvideo;

import javax.swing.*;

public class EstCondicional_Switch_comMetodo {
    static void Qtpernas(){

        int pernas = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de pernas do animal "));
        String a = null;

        switch(pernas) {

            case 1:
                a = "Saci";
                break;

            case 2:
                a = "Bipede";
                break;

            case 3:
                a = "Tripé";

            case 4:
                a = "Quadrúpede";
                break;

            case 6, 8:
                a = "Aranha";
            break;

            default:
                a = "ET";
                break;

    }
        JOptionPane.showMessageDialog(null, "Tipo: " + a);

    }
public static void main(String[] args){

        Qtpernas();

    }
}
