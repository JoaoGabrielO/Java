package Java_CursoEmvideo;

public class Operadores_Aritmeticos {
    public static void main(String[] args){

        int numero =5;
        int valor = 5 + numero ++ ;
        System.out.println("Valor: " + valor);

        int y = 4;
        int x = 4;
        int z = 4;

        x += 2; // X = X + 2
        y *= 2; // Y = Y * 2
        z %= 2; // Z = Z % 2
        System.out.println("X: " + x);
        System.out.println("Y: " + y);
        System.out.println("Z: " + z);
    }
}
