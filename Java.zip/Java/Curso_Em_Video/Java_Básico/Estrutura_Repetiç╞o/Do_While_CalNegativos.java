package Java_CursoEmvideo;

import java.util.Scanner;

public class Do_While_CalNegativos {
    public static void main(String[] args){

        int C, TotN;

        Scanner sc = new Scanner(System.in);
        C = 1;
        TotN = 0;

        do {
            System.out.println("Digite um número: ");
            int N = sc.nextInt();

            if (N < 0){
                TotN = TotN + 1;
            }
            C = C+1;

       }while (C < 6);

        System.out.println("Foram digitados " + TotN + " valores negativos ");
    }
}
