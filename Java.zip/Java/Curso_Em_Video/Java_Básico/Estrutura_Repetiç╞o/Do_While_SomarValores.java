package Java_CursoEmvideo;

import java.util.Scanner;

public class Do_While_SomarValores {
    public static void main(String[] args) {

        int S = 0;
        Scanner sc = new Scanner(System.in);

        String resp;
        do {
            System.out.println("Digite o valor ");
            int N = sc.nextInt();
            S = S + N;
            System.out.println("Voce quer continuar ? [S/N]");
            resp = sc.next();

        } while (resp.equalsIgnoreCase("S") );
        System.out.println("A soma de todos os valores digitados é: " + S);
    }
}