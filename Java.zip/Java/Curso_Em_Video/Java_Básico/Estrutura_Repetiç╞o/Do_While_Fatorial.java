package Java_CursoEmvideo;

import java.util.Scanner;

public class Do_While_Fatorial {
    public static void main(String[] args) {
        int F = 1;
        int C;
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um número: ");
        int N = sc.nextInt();
        C = N;

        do {
            System.out.println(C + " x ");
            F = F * C;
            C = C - 1;

        }while (C > 1);
        System.out.println("O valor fatorial de " + N + " é igual a " + F);

    }
}

