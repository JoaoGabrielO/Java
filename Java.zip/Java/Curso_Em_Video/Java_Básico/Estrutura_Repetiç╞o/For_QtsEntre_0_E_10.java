package Java_CursoEmvideo;

import java.util.Scanner;

public class For_QtsEntre_0_E_10{

    public static void main(String[] args) {

        int C, V, Tot010 = 0, SImp = 0;
        Scanner sc = new Scanner(System.in);

        for (C = 1; C < 7; C++ ) {
            System.out.println("Digite um valor: ");
            V = sc.nextInt();

            if (V >= 0 & V <= 10) {
                Tot010 = Tot010 + 1;

                if (V % 2 == 1) {
                    SImp = SImp + V;
                }
            }
        }
        System.out.println("Ao todo foram " + Tot010 + " valores entre 0 e 10 ");
        System.out.println("Nesse intervalo, a soma de impares foi: " + SImp);
    }
}
