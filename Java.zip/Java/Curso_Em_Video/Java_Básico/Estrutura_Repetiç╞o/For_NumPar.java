package Java_CursoEmvideo;

import java.util.Scanner;

public class For_NumPar {

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);
        int CONT , V;

        System.out.println("Digite um valor: ");
        V = sc.nextInt();

        if (V % 2 == 1) {
            V = V-1;
        }

        for (CONT = V; CONT > 0;) {
            System.out.println(CONT);
            CONT = CONT -2;
        }
    }
}
