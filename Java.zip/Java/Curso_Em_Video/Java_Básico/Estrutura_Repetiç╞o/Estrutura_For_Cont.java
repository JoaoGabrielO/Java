package Java_CursoEmvideo;

import java.util.Scanner;

public class Estrutura_For_Cont {
    static int cont(int ini, int fim, int pass){

        for(int i = ini;i <= fim; i += pass){
            System.out.println(i);

        }

        return ini;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o valor de inicio: ");
        int i = sc.nextInt();
        System.out.println("Digite o valor do fim: ");
        int fim = sc.nextInt();
        System.out.println("Digite o valor do passo: ");
        int pass = sc.nextInt();

        cont(i, fim, pass);

    }
}
