package Java_CursoEmvideo;

import java.util.Scanner;

public class While_SomarValores {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        int cont = 1;
        int S = 0;
        int maior = 0;
        int menor = 0;

        while (cont <= 5) {

            System.out.println("Digite o " + cont + "º. valor: ");
            int N = sc.nextInt();

            if (N > maior) {
                maior = N;
            }
            if (cont == 1) {
                menor = N;
            }
            else if (N < menor) {
                menor = N;
            }

            S = S + N;
            cont = cont +1;
            System.out.println("Soma dos número: " + S );
            System.out.println(menor);
        }
        System.out.println("A soma de todos os valores foi " + S);
        System.out.println("Maior número digitado " + maior);
        System.out.println("Menor número digitado " + menor);


    }
}
