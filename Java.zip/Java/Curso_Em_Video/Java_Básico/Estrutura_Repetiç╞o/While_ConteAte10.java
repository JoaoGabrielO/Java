package Java_CursoEmvideo;

import java.util.Scanner;

public class While_ConteAte10 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite até quanto quer contar ");
        int contador = sc.nextInt();
        System.out.println("Qual será o valor do salto ?");
        int salto = sc.nextInt();

        int valor = 0;

        while (valor <= contador) {
            System.out.println(valor);
            valor = valor + salto ;
        }
        System.err.println("Terminei de contar !!");
    }
}
