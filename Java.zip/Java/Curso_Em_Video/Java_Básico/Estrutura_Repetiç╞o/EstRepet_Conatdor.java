package Java_CursoEmvideo;

import javax.swing.*;

public class EstRepet_Conatdor {
    static void Cambalhotas(){

        int cc = 0;

        while (cc < 10) {
            cc ++;
            if (cc == 5 || cc == 7 || cc == 9){
                continue; //SEMPRE QUE O CONATADOR FOR 5 OU 7, ELE NÃO VAI MOSTRAR NA TELA,VAI VOLTA PRO WHILE
                          //PARECIDO COM O BREAK, MAS O BREAK JOGA PRA FORA DO LAÇO
            }
            JOptionPane.showMessageDialog(null, "Cambalhota " + (cc));
        }
    }

public static void main(String[] args){
        Cambalhotas();

    }
}
