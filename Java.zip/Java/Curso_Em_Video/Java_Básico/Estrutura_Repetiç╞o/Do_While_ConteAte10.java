package Java_CursoEmvideo;

public class Do_While_ConteAte10 {
    public static void main(String[] args){
        int R;
        int cont = 1;
        int N = 7;
        do {
        R = N * cont;
            System.out.println(N + " x " + cont + " = " + R);
            cont = cont +1;
        }while (cont <11);

    }
}

