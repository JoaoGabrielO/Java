package Java_CursoEmvideo;

public class For_Combinacoes {
    public static void main(String[] args){

        int C1, C2;

        for (C1 = 1; C1 <= 3; C1++) {

            for (C2 = 1; C2 <= 3; C2++) {
                System.out.println(C1 + "" + C2);

            }
        }
    }
}
