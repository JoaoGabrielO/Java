package Java_CursoEmvideo;

import java.util.Scanner;

public class ClasseMath {
    public static void main(String[] args){

        float raiz, PI, pot, raizC;
        double random = Math.random();
        int M = (int) ( 0 + random * (10-0));

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um valor para N ");
        int N = sc.nextInt();
        System.out.println("Digite um valor para o numerador ");
        int Num = sc.nextInt();
        System.out.println("Digite um valor para o denominador ");
        int D = sc.nextInt();

        raiz = (float) Math.sqrt(N);
        PI = (float) Math.PI;
        pot = (float) Math.pow(Num, D);
        raizC = (float) Math.cbrt(N);

        System.out.println("O produto de " + Num + " elevado a " + D + " é: " + pot);
        System.out.println("\nRaiz quadrada de " + N + " é: " + raiz);
        System.out.println("\nValor de PI é: " + PI);
        System.out.println("\nRaiz cúbica de " + N + " é: " + raizC);
        System.out.println("Número aleatório entre 0 e 10: " + M);



    }
}
