package Java_CursoEmvideo;

import java.util.Arrays;

public class Vetor_03_ForIt_ArraysSearch {
    public static void main(String[] args){

        int vetor[] = {3, 2, 4, 5};
        for (int i : vetor) {
            System.out.println(i);

        }
        System.out.println("");
        int p = Arrays.binarySearch(vetor, 0);
        System.out.println("Encontrei o valor na posição " + p);
    }
}

