package Java_CursoEmvideo;

import java.util.Scanner;

public class Vetor_01_Ano {
    public static void main(String []args){

        Scanner sc = new Scanner(System.in);

        String mes[] = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        int tot[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        System.out.println("Digite o ano atual: ");
        int ano = sc.nextInt();

        if(ano %4 == 0) {
            System.out.println("Esse ano é bissexto. Então Fevereiro terá um dia a mais");
            tot[1] = 29;

        }
        for(int i = 0; i < mes.length; ++i) {
            System.out.println("O mês de " + mes[i] + " tem " + tot[i] + " dias ao todo");

        }
    }
}
