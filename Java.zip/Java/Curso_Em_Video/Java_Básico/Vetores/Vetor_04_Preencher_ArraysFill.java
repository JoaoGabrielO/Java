package Java_CursoEmvideo;

import java.util.Arrays;

public class Vetor_04_Preencher_ArraysFill {
    public static void main(String[] args){

        int vetor[] = new int[20];
        Arrays.fill(vetor, 5);

        for(int i : vetor) {
            System.out.print(i + " ");
        }
    }
}
