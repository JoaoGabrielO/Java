package Java_CursoEmvideo;

import java.util.Arrays;

public class Vetor_02_ForIt_ArraysSort {
    public static void main(String[] args){

        double vetor[] = {3.5, 2.75, 4.10, -5};
        Arrays.sort(vetor);

        for (double valor: vetor) {
            System.out.println(valor + "");

        }
    }
}
