package Java_CursoEmvideo;

public class Teste_Tipos {
    public static void main(String[] arsg){

        /*int idade = 30;
        String valor = Integer.toString(idade);

        System.out.println(valor);
         */
        String valor = "30";
        int idade = Integer.parseInt(valor);
        float Idade = Float.parseFloat(valor);

        System.out.println(idade);
        System.out.printf("%.3f ", Idade);
    }
}
