package Teste_Funcao_03;

public class Operacoes {

    public static String contador(int i, int f) {
        String s = "";
        for (int c = i; c <= f; ++c){
            s += c + " ";
        }
    return s;
    }
}
