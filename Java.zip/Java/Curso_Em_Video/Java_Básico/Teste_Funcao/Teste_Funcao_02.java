public class Teste_Funcao_02 {
    static int soma(int a, int b){

        int s = a + b;

        return s;
    }
    public static void main(String[] args){
        int sm = soma(5, 5);
        System.out.println(sm);
        System.out.println(soma(10,10));

    }
}
