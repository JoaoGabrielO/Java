public class Teste_Funcao_01 {
    static void soma(int a, int b){
        int s = a + b;
        System.out.println("A soma é: " + s);
    }

    public static void main(String[] args){
        soma(5, 5);

    }
}
