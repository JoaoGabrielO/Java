package Java_CursoEmvideo;

import java.util.Scanner;

public class Tipos_Primitivos {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Digite o nome do aluno ");
        String nome = teclado.nextLine();
        System.out.println("Digite a nota do aluno ");
        float nota = teclado.nextFloat();

        System.out.print("Sua nota é: " + nota);

        System.out.println("\nSua nota é: " + nota);

        System.out.format("A nota é %f ", nota); //PRINT FORMATADO

        System.out.printf("\nA nota de %s é %.2f ",nome ,nota); //PRINT FORMATADO

    }
}
