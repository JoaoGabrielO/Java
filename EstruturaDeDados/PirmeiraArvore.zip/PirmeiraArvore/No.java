package EstruturaDeDados.PirmeiraArvore;

public class No {
    int info;
    No direita, esquerda;

    public No() {
    }
    public No(int info) {
        this.info = info;
        this.esquerda = null;
        this.direita = null;
    }

}
