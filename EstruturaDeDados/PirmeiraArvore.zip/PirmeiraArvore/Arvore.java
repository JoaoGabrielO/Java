package EstruturaDeDados.PirmeiraArvore;

public class Arvore {
    No root = null;

    public void insert(int info, No place){
        if(place == null){
            root = new No(info);
            System.out.println("" + info);
        } else if (info < place.info) {
            if(place.esquerda == null){
                place.esquerda = new No(info);
                System.out.println("" + info);
            }else{
                insert(info, place.esquerda);
            }
        } else if (info > place.info) {
            if(place.direita == null){
                place.direita = new No(info);
                System.out.println("" + info);
            }else{
                insert(info, place.direita);
            }
        }
    }
    public void preOrder(No place){
        System.out.println("" + place.info);
        if(place.esquerda != null){
            preOrder(place.esquerda);
        }
        if(place.direita != null){
            preOrder(place.direita);
        }
    }
    public void inOrder(No place){
        if(place.esquerda != null){
            inOrder(place.esquerda);
        }
        System.out.println("" + place.info);
        if(place.direita != null){
            inOrder(place.direita);
        }
    }
    public void postOrder(No place){
        if(place.esquerda != null){
            postOrder(place.esquerda);
        }
        if(place.direita != null){
            postOrder(place.direita);
        }
        System.out.println("" + place.info);
    }
}
